#!/usr/bin/env python3
"""یک‌بار مصرف: رشته‌های فارسی داخل js رو با Tr("...") و Trt`...` می‌پوشونه و کلیدها رو لیست می‌کنه."""
import re, sys, json
PER = re.compile('[؀-ۿ]')
KEYS = []

def scan_template(s, i):
    """s[i] == '`' ؛ برمی‌گردونه (j بعد از بسته‌شدن, parts[(static|expr)])"""
    j = i + 1; parts = []; cur = ''
    while j < len(s):
        c = s[j]
        if c == '\\': cur += s[j:j+2]; j += 2; continue
        if c == '`': parts.append(('s', cur)); return j + 1, parts
        if c == '$' and s[j+1] == '{':
            parts.append(('s', cur)); cur = ''
            depth = 1; k = j + 2; st = k
            while depth:
                ch = s[k]
                if ch in '"\'':
                    q = ch; k += 1
                    while s[k] != q:
                        k += 2 if s[k] == '\\' else 1
                elif ch == '`':
                    k, _ = scan_template(s, k); continue
                elif ch == '{': depth += 1
                elif ch == '}': depth -= 1
                k += 1
            parts.append(('e', s[st:k-1])); j = k; continue
        cur += c; j += 1
    raise ValueError('unterminated template')

def runs(text):
    return [r.strip() for r in re.findall(r'[؀-ۿ][؀-ۿ‌\s·،؟!:\-\(\)«»…\.۰-۹]*', text) if r.strip()]

def tr(s):
    out = []; i = 0; n = len(s); prev = ''
    while i < n:
        c = s[i]
        if s.startswith('//', i):
            j = s.find('\n', i); j = n if j < 0 else j; out.append(s[i:j]); i = j; continue
        if s.startswith('/*', i):
            j = s.find('*/', i) + 2; out.append(s[i:j]); i = j; continue
        if c in '"\'':
            j = i + 1
            while s[j] != c: j += 2 if s[j] == '\\' else 1
            lit = s[i:j+1]
            if PER.search(lit):
                # کلید آبجکت یا import؟
                after = s[j+1:j+4].lstrip()
                if after.startswith(':') and prev in '{,':
                    out.append(lit)
                else:
                    KEYS.extend(runs(lit)); out.append('Tr(' + lit + ')')
            else: out.append(lit)
            i = j + 1; prev = ')'; continue
        if c == '`':
            j, parts = scan_template(s, i)
            statics = ''.join(p for k, p in parts if k == 's')
            body = ''.join(p if k == 's' else '${' + tr(p) + '}' for k, p in parts)
            if PER.search(statics):
                KEYS.extend(runs(statics)); out.append('Trt`' + body + '`')
            else: out.append('`' + body + '`')
            i = j; prev = ')'; continue
        if c == '/' and prev in '(,=:[!&|?{};' + '':
            j = i + 1; cls = False
            while True:
                ch = s[j]
                if ch == '\\': j += 2; continue
                if ch == '[': cls = True
                elif ch == ']': cls = False
                elif ch == '/' and not cls: break
                j += 1
            j += 1
            while j < n and s[j].isalpha(): j += 1
            out.append(s[i:j]); i = j; prev = ')'; continue
        out.append(c)
        if not c.isspace(): prev = c
        i += 1
    return ''.join(out)

for f in sys.argv[1:]:
    src = open(f, encoding='utf8').read()
    new = tr(src)
    if new != src:
        uses = [n for n in ('Tr', 'Trt') if re.search(r'\b' + n + r'\b', new)]
        imp = 'import { ' + ', '.join(uses) + ' } from "./i18n.js";\n'
        # بعد از آخرین import
        m = list(re.finditer(r'^import .*;\n', new, re.M))
        pos = m[-1].end() if m else 0
        new = new[:pos] + imp + new[pos:]
        open(f, 'w', encoding='utf8').write(new)
json.dump(sorted(set(KEYS)), open('/tmp/i18n_keys.json', 'w'), ensure_ascii=False, indent=1)
print(len(set(KEYS)), 'keys')
