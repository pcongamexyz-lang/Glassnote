#!/usr/bin/env python3
"""ساخت آیکون‌های اندروید (لانچر، آداپتیو و اعلان) بدون هیچ گرادیانت.
اجرا:  pip install pillow && python tools/make_icons.py
خروجی در resources/android/res ذخیره می‌شه و ورک‌فلو موقع بیلد اون رو توی پروژه‌ی اندروید کپی می‌کنه."""
import os
from PIL import Image, ImageDraw

BG = (11, 16, 32)        # رنگ پس‌زمینه‌ی آیکون (همون آبی تأکید برنامه)
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "resources", "android", "res")
SS = 4  # سوپرسمپلینگ برای لبه‌های نرم

def art(size, with_bg=False, mono=False):
    """نقش آیکون: کارت شیشه‌ای مات روی هاله‌ی آبی بلورشده (بلور واقعی، بدون گرادیان).
    همه‌چیز در ۶۰٪ مرکز بوم می‌مونه تا برش آداپتیو اذیتش نکنه."""
    from PIL import ImageFilter
    s = size * SS
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    u = s / 108.0
    if mono:
        d = ImageDraw.Draw(im)
        d.rounded_rectangle((33 * u, 27 * u, 75 * u, 81 * u), radius=9 * u, fill=(255, 255, 255, 255))
        for i, w in enumerate((26, 26, 16)):
            yy = (47 + i * 10) * u
            d.rounded_rectangle((67 * u - w * u, yy, 67 * u, yy + 3.6 * u), radius=1.8 * u, fill=(0, 0, 0, 0))
        return im
    # هاله‌ها (دایره‌ی تخت که بعد بلور می‌شه)
    glow = Image.new("RGBA", (s, s), (0, 0, 0, 0)); g = ImageDraw.Draw(glow)
    g.ellipse((22 * u, 16 * u, 66 * u, 60 * u), fill=(60, 140, 255, 255))
    g.ellipse((46 * u, 48 * u, 88 * u, 90 * u), fill=(160, 100, 255, 245))
    im.alpha_composite(glow.filter(ImageFilter.GaussianBlur(8 * u)))
    # کارت شیشه‌ای
    x0, y0, x1, y1, r = 31 * u, 25 * u, 77 * u, 83 * u, 11 * u
    card = Image.new("RGBA", (s, s), (0, 0, 0, 0)); c = ImageDraw.Draw(card)
    c.rounded_rectangle((x0, y0, x1, y1), radius=r, fill=(255, 255, 255, 58), outline=(255, 255, 255, 215), width=max(1, int(1.7 * u)))
    c.rounded_rectangle((x0 + 2 * u, y0 + 2 * u, x1 - 2 * u, y1 - 2 * u), radius=r - 2 * u, outline=(255, 255, 255, 40), width=max(1, int(1 * u)))
    # درخشش لبه‌ی بالا (بازتاب)
    c.rounded_rectangle((x0 + 7 * u, y0 + 3.2 * u, x0 + 26 * u, y0 + 5 * u), radius=u, fill=(255, 255, 255, 190))
    im.alpha_composite(card)
    d = ImageDraw.Draw(im)
    lw = 4 * u
    for i, w in enumerate((28, 28, 17)):
        yy = (44 + i * 10.5) * u
        xr = 69 * u
        d.rounded_rectangle((xr - w * u, yy, xr, yy + lw), radius=lw / 2, fill=(255, 255, 255, 245))
    # قطره‌ی شیشه‌ای پایین
    rr = 8.5 * u; cx, cy = 66 * u, 77 * u
    d.ellipse((cx - rr, cy - rr, cx + rr, cy + rr), fill=(255, 255, 255, 120), outline=(255, 255, 255, 245), width=max(1, int(1.5 * u)))
    d.ellipse((cx - 4.5 * u, cy - 5.5 * u, cx - 1.5 * u, cy - 2.5 * u), fill=(255, 255, 255, 230))
    return im

def finish(im, size):
    return im.resize((size, size), Image.LANCZOS)

def launcher(px, round_=False):
    s = px * SS
    base = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(base)
    if round_:
        d.ellipse((0, 0, s - 1, s - 1), fill=BG + (255,))
    else:
        d.rounded_rectangle((0, 0, s - 1, s - 1), radius=int(s * 0.22), fill=BG + (255,))
    a = art(px).resize((s, s), Image.LANCZOS)
    base.alpha_composite(a)
    return finish(base, px)

def save(img, *parts):
    p = os.path.join(OUT, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

dens = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
for name, k in dens.items():
    save(launcher(round(48 * k)), f"mipmap-{name}", "ic_launcher.png")
    save(launcher(round(48 * k), True), f"mipmap-{name}", "ic_launcher_round.png")
    fg = round(108 * k)
    save(finish(art(fg), fg), f"mipmap-{name}", "ic_launcher_foreground.png")
    # آیکون اعلان: سایه‌روشن سفید روی شفاف
    n = round(24 * k)
    ns = n * SS
    m = Image.new("RGBA", (ns, ns), (0, 0, 0, 0)); dm = ImageDraw.Draw(m); u = ns / 24.0
    dm.rounded_rectangle((5 * u, 3 * u, 19 * u, 21 * u), radius=2.4 * u, fill=(255, 255, 255, 255))
    for i, w in enumerate((8, 8, 5)):
        yy = (9 + i * 3.4) * u
        dm.rounded_rectangle((15 * u - w * u, yy, 15 * u, yy + 1.5 * u), radius=0.75 * u, fill=(0, 0, 0, 0))
    save(finish(m, n), f"drawable-{name}", "ic_stat_notify.png")

xml = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
'''
for f in ("ic_launcher.xml", "ic_launcher_round.xml"):
    p = os.path.join(OUT, "mipmap-anydpi-v26", f); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(xml)
p = os.path.join(OUT, "values", "ic_launcher_background.xml"); os.makedirs(os.path.dirname(p), exist_ok=True)
open(p, "w").write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B1020</color>\n</resources>\n')
# پیش‌نمایش برای README
launcher(512).save(os.path.join(os.path.dirname(OUT), "..", "icon-preview.png"))
print("آیکون‌ها ساخته شد:", OUT)
