#!/usr/bin/env python3
"""ساخت آیکون‌های اندروید (لانچر، آداپتیو و اعلان) بدون هیچ گرادیانت.
اجرا:  pip install pillow && python tools/make_icons.py
خروجی در resources/android/res ذخیره می‌شه و ورک‌فلو موقع بیلد اون رو توی پروژه‌ی اندروید کپی می‌کنه."""
import os
from PIL import Image, ImageDraw

BG = (118, 118, 124)        # رنگ پس‌زمینه‌ی آیکون (همون آبی تأکید برنامه)
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "resources", "android", "res")
SS = 4  # سوپرسمپلینگ برای لبه‌های نرم

def art(size, with_bg=False, mono=False):
    """نقش آیکون: مینیمال سیاه‌وسفید؛ برگه‌ی سفید با گوشه‌ی برش‌خورده و سه خط. بدون گرادیان.
    همه‌چیز در ۶۰٪ مرکز بوم می‌مونه تا برش آداپتیو اذیتش نکنه."""
    s = size * SS
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    u = s / 108.0
    x0, y0, x1, y1, r = 32 * u, 24 * u, 76 * u, 84 * u, 9 * u
    d.rounded_rectangle((x0, y0, x1, y1), radius=r, fill=(255, 255, 255, 255) if mono else (10, 10, 12, 255))
    c = 15 * u  # گوشه‌ی بالا-راست بریده می‌شه
    d.polygon([(x1 - c, y0 - 1), (x1 + 1, y0 - 1), (x1 + 1, y0 + c)], fill=(0, 0, 0, 0))
    d.polygon([(x1 - c, y0), (x1 - c, y0 + c - 2 * u), (x1 - 2 * u, y0 + c)] if False else [(x1 - c, y0 + 1), (x1 - c, y0 + c), (x1 - 1, y0 + c)], fill=(60, 60, 64, 255) if not mono else (0, 0, 0, 0))
    ink = (0, 0, 0, 0) if mono else (118, 118, 124, 255)
    lw = 4.2 * u
    for i, w in enumerate((26, 26, 15)):
        yy = (46 + i * 10.5) * u
        d.rounded_rectangle((40 * u, yy, 40 * u + w * u, yy + lw), radius=lw / 2, fill=ink)
    return im

def finish(im, size):
    return im.resize((size, size), Image.LANCZOS)

def launcher(px, round_=False):
    s = px * SS
    base = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(base)
    if round_:
        d.ellipse((0, 0, s - 1, s - 1), fill=BG + (255,))
    else:
        d.rounded_rectangle((0, 0, s - 1, s - 1), radius=int(s * 0.22), fill=BG + (255,))
    a = art(px).resize((s, s), Image.LANCZOS)
    base.alpha_composite(a)
    return finish(base, px)

def save(img, *parts):
    p = os.path.join(OUT, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

dens = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
for name, k in dens.items():
    save(launcher(round(48 * k)), f"mipmap-{name}", "ic_launcher.png")
    save(launcher(round(48 * k), True), f"mipmap-{name}", "ic_launcher_round.png")
    fg = round(108 * k)
    save(finish(art(fg), fg), f"mipmap-{name}", "ic_launcher_foreground.png")
    # آیکون اعلان: سایه‌روشن سفید روی شفاف
    n = round(24 * k)
    ns = n * SS
    m = Image.new("RGBA", (ns, ns), (0, 0, 0, 0)); dm = ImageDraw.Draw(m); u = ns / 24.0
    dm.rounded_rectangle((5 * u, 3 * u, 19 * u, 21 * u), radius=2.4 * u, fill=(255, 255, 255, 255))
    for i, w in enumerate((8, 8, 5)):
        yy = (9 + i * 3.4) * u
        dm.rounded_rectangle((15 * u - w * u, yy, 15 * u, yy + 1.5 * u), radius=0.75 * u, fill=(0, 0, 0, 0))
    save(finish(m, n), f"drawable-{name}", "ic_stat_notify.png")

xml = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
'''
for f in ("ic_launcher.xml", "ic_launcher_round.xml"):
    p = os.path.join(OUT, "mipmap-anydpi-v26", f); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(xml)
p = os.path.join(OUT, "values", "ic_launcher_background.xml"); os.makedirs(os.path.dirname(p), exist_ok=True)
open(p, "w").write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#76767C</color>\n</resources>\n')
# پیش‌نمایش برای README
launcher(512).save(os.path.join(os.path.dirname(OUT), "..", "icon-preview.png"))
print("آیکون‌ها ساخته شد:", OUT)
