#!/usr/bin/env python3
"""ساخت آیکون‌های اندروید (لانچر، آداپتیو و اعلان) بدون هیچ گرادیانت.
اجرا:  pip install pillow && python tools/make_icons.py
خروجی در resources/android/res ذخیره می‌شه و ورک‌فلو موقع بیلد اون رو توی پروژه‌ی اندروید کپی می‌کنه."""
import os
from PIL import Image, ImageDraw

BG = (47, 124, 246)        # رنگ پس‌زمینه‌ی آیکون (همون آبی تأکید برنامه)
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "resources", "android", "res")
SS = 4  # سوپرسمپلینگ برای لبه‌های نرم

def art(size, with_bg=False, mono=False):
    """نقش آیکون روی بوم مربعی. نقش در ۶۰٪ مرکز بوم می‌مونه تا برش آداپتیو اذیتش نکنه."""
    s = size * SS
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    u = s / 108.0                      # واحد: ۱۰۸dp
    white = (255, 255, 255, 255)
    ink = (255, 255, 255, 255) if mono else BG + (255,)
    # برگه‌ی یادداشت
    x0, y0, x1, y1 = 33 * u, 27 * u, 75 * u, 81 * u
    d.rounded_rectangle((x0, y0, x1, y1), radius=7 * u, fill=white)
    # گوشه‌ی تاخورده (برش گوشه‌ی بالا-چپ)
    c = 12 * u
    d.polygon([(x0, y0), (x0 + c, y0), (x0, y0 + c)], fill=(0, 0, 0, 0))
    if not mono:
        d.polygon([(x0 + c, y0), (x0 + c, y0 + c), (x0, y0 + c)], fill=(205, 222, 252, 255))
        d.polygon([(x0 + c, y0), (x0 + c, y0 + c), (x0, y0 + c)], outline=None)
    # خط‌های متن
    lw = 3.6 * u
    for i, w in enumerate((26, 26, 16)):
        yy = (47 + i * 10) * u
        xr = 67 * u
        d.rounded_rectangle((xr - w * u, yy, xr, yy + lw), radius=lw / 2, fill=ink if not mono else (0, 0, 0, 0))
    # نقطه‌ی «شیشه‌ای» گوشه‌ی پایین
    if not mono:
        r = 11 * u
        cx, cy = 69 * u, 76 * u
        d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(255, 255, 255, 120), outline=(255, 255, 255, 235), width=int(1.6 * u))
    return im

def finish(im, size):
    return im.resize((size, size), Image.LANCZOS)

def launcher(px, round_=False):
    s = px * SS
    base = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(base)
    if round_:
        d.ellipse((0, 0, s - 1, s - 1), fill=BG + (255,))
    else:
        d.rounded_rectangle((0, 0, s - 1, s - 1), radius=int(s * 0.22), fill=BG + (255,))
    a = art(px).resize((s, s), Image.LANCZOS)
    base.alpha_composite(a)
    return finish(base, px)

def save(img, *parts):
    p = os.path.join(OUT, *parts)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    img.save(p)

dens = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
for name, k in dens.items():
    save(launcher(round(48 * k)), f"mipmap-{name}", "ic_launcher.png")
    save(launcher(round(48 * k), True), f"mipmap-{name}", "ic_launcher_round.png")
    fg = round(108 * k)
    save(finish(art(fg), fg), f"mipmap-{name}", "ic_launcher_foreground.png")
    # آیکون اعلان: سایه‌روشن سفید روی شفاف
    n = round(24 * k)
    ns = n * SS
    m = Image.new("RGBA", (ns, ns), (0, 0, 0, 0)); dm = ImageDraw.Draw(m); u = ns / 24.0
    dm.rounded_rectangle((5 * u, 3 * u, 19 * u, 21 * u), radius=2.4 * u, fill=(255, 255, 255, 255))
    for i, w in enumerate((8, 8, 5)):
        yy = (9 + i * 3.4) * u
        dm.rounded_rectangle((15 * u - w * u, yy, 15 * u, yy + 1.5 * u), radius=0.75 * u, fill=(0, 0, 0, 0))
    save(finish(m, n), f"drawable-{name}", "ic_stat_notify.png")

xml = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
'''
for f in ("ic_launcher.xml", "ic_launcher_round.xml"):
    p = os.path.join(OUT, "mipmap-anydpi-v26", f); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w").write(xml)
p = os.path.join(OUT, "values", "ic_launcher_background.xml"); os.makedirs(os.path.dirname(p), exist_ok=True)
open(p, "w").write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#2F7CF6</color>\n</resources>\n')
# پیش‌نمایش برای README
launcher(512).save(os.path.join(os.path.dirname(OUT), "..", "icon-preview.png"))
print("آیکون‌ها ساخته شد:", OUT)
