// نسخه‌ی Compose: بعد از patch-android.mjs اجرا می‌شه.
// داک پایین (لیکویید گلس واقعی با کتابخانه‌ی Backdrop) به‌صورت بومی روی WebView ساخته می‌شه.
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const android = path.join(root, "android");
const app = path.join(android, "app");
const rd = (p) => fs.readFileSync(p, "utf8");
const wr = (p, s) => fs.writeFileSync(p, s);

const KOTLIN = "2.1.21", AGP = "8.7.3", GRADLE = "8.9", BACKDROP = "2.0.1", BOM = "2025.06.01";

// ---------- 1) گریدل ----------
let p = path.join(android, "build.gradle");
let g = rd(p);
g = g.replace(/com\.android\.tools\.build:gradle:[\d.]+/, `com.android.tools.build:gradle:${AGP}`);
if (!g.includes("kotlin-gradle-plugin")) {
  g = g.replace(/(classpath\s+['"]com\.android\.tools\.build:gradle:[\d.]+['"])/, `$1\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:${KOTLIN}'\n        classpath 'org.jetbrains.kotlin:compose-compiler-gradle-plugin:${KOTLIN}'`);
}
wr(p, g);

p = path.join(android, "gradle", "wrapper", "gradle-wrapper.properties");
wr(p, rd(p).replace(/gradle-[\d.]+-(all|bin)\.zip/, `gradle-${GRADLE}-all.zip`));

p = path.join(android, "variables.gradle");
wr(p, rd(p).replace(/compileSdkVersion\s*=\s*\d+/, "compileSdkVersion = 35"));

p = path.join(app, "build.gradle");
g = rd(p);
if (!g.includes("org.jetbrains.kotlin.android")) {
  g = g.replace(/apply plugin: ['"]com\.android\.application['"]/, `apply plugin: 'com.android.application'\napply plugin: 'org.jetbrains.kotlin.android'\napply plugin: 'org.jetbrains.kotlin.plugin.compose'`);
  g = g.replace(/android\s*\{/, "android {\n    kotlinOptions { jvmTarget = '17' }");
  g = g.replace(/dependencies\s*\{/, `dependencies {
    implementation platform("androidx.compose:compose-bom:${BOM}")
    implementation "androidx.compose.ui:ui"
    implementation "androidx.compose.ui:ui-graphics"
    implementation "androidx.compose.foundation:foundation"
    implementation "io.github.kyant0:backdrop:${BACKDROP}"`);
}
wr(p, g);
console.log("✓ گریدل برای Compose آماده شد");

// ---------- 2) آیکون‌ها از utils.js به مسیرهای Kotlin ----------
const utils = rd(path.join(root, "www", "js", "utils.js"));
function svgToPaths(svg) {
  const out = [];
  for (const m of svg.matchAll(/<(path|circle|rect)\b([^>]*)\/?>/g)) {
    const at = (n) => { const r = new RegExp(`\\b${n}="([^"]*)"`).exec(m[2]); return r ? r[1] : null; };
    if (m[1] === "path") out.push(at("d"));
    else if (m[1] === "circle") { const cx = +at("cx"), cy = +at("cy"), r = +at("r"); out.push(`M${cx - r} ${cy}a${r} ${r} 0 1 0 ${2 * r} 0a${r} ${r} 0 1 0 ${-2 * r} 0z`); }
    else { const x = +at("x"), y = +at("y"), w = +at("width"), h = +at("height"), r = +(at("rx") || 0);
      out.push(`M${x + r} ${y}h${w - 2 * r}a${r} ${r} 0 0 1 ${r} ${r}v${h - 2 * r}a${r} ${r} 0 0 1 ${-r} ${r}h${-(w - 2 * r)}a${r} ${r} 0 0 1 ${-r} ${-r}v${-(h - 2 * r)}a${r} ${r} 0 0 1 ${r} ${-r}z`); }
  }
  return out.filter(Boolean);
}
const icons = {};
for (const k of ["note", "archive", "trash", "settings", "plus"]) {
  const m = new RegExp(`\\n\\s*${k}: '(.*?)',?\\n`).exec(utils);
  if (!m) { console.error("آیکون پیدا نشد:", k); process.exit(1); }
  icons[k] = svgToPaths(m[1]);
}
const kIcons = "val GLASS_ICONS: Map<String, List<String>> = mapOf(\n" + Object.entries(icons).map(([k, v]) => `    "${k}" to listOf(${v.map((s) => JSON.stringify(s)).join(", ")})`).join(",\n") + "\n)\n";

// ---------- 3) کد Kotlin ----------
function findFile(dir, name) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const q = path.join(dir, e.name);
    if (e.isDirectory()) { const r = findFile(q, name); if (r) return r; } else if (e.name === name) return q;
  }
  return null;
}
const mainPath = findFile(path.join(app, "src", "main", "java"), "MainActivity.java");
const pkg = (/package\s+([\w.]+);/.exec(rd(mainPath)) || [])[1];
const tpl = rd(path.join(root, "scripts", "GlassDock.kt.tpl")).replace("__PKG__", pkg).replace("__ICONS__", kIcons);
wr(path.join(path.dirname(mainPath), "GlassDock.kt"), tpl);

// ---------- 4) MainActivity: WebView رو داخل Compose میزبانی می‌کنیم ----------
let j = rd(mainPath);
if (!j.includes("GlassDock.attach")) {
  j = j.replace('web.addJavascriptInterface(new Bars(), "GlassBars");', 'web.addJavascriptInterface(new Bars(), "GlassBars");\n        GlassDock.attach(this, web);');
  j = j.replace("lastInsets = top", "GlassDock.setInsets(bottom);\n                lastInsets = top");
  wr(mainPath, j);
}
console.log("✓ Compose فعال شد (GlassDock.kt در", path.dirname(mainPath) + ")");
