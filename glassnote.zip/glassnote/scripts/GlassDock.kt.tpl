package __PKG__

import android.app.Activity
import android.os.Build
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.roundToInt

__ICONS__

private val KEYS = listOf("notes", "archive", "trash", "settings")
private val ICON_OF = mapOf("notes" to "note", "archive" to "archive", "trash" to "trash", "settings" to "settings")

object GlassDockState {
    var view by mutableStateOf("notes")
    var hide by mutableStateOf(false)
    var open by mutableStateOf(false)
    var labels by mutableStateOf(listOf("Notes", "Archive", "Trash", "Settings"))
    var dark by mutableStateOf(true)
    var accent by mutableStateOf(Color(0xFF2F7CF6))
    var bg by mutableStateOf(Color(0xFF121212))
    var bottomInset by mutableFloatStateOf(0f) // dp
}

class DockBridge(private val act: Activity) {
    @JavascriptInterface
    fun setState(json: String) {
        act.runOnUiThread {
            try {
                val o = JSONObject(json)
                GlassDockState.view = o.optString("view", "notes")
                GlassDockState.hide = o.optBoolean("hide", false)
                GlassDockState.open = o.optBoolean("open", false)
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun setLabels(json: String) {
        act.runOnUiThread {
            try {
                val a = JSONArray(json)
                GlassDockState.labels = (0 until a.length()).map { a.getString(it) }
            } catch (e: Exception) { }
        }
    }

    @JavascriptInterface
    fun setTheme(json: String) {
        act.runOnUiThread {
            try {
                val o = JSONObject(json)
                GlassDockState.dark = o.optBoolean("dark", true)
                val acc = o.optString("accent", "47,124,246").split(",").map { it.trim().toInt() }
                GlassDockState.accent = Color(acc[0], acc[1], acc[2])
                val bg = android.graphics.Color.parseColor(o.optString("bg", "#14161A"))
                GlassDockState.bg = Color(bg)
            } catch (e: Exception) { }
        }
    }
}

object GlassDock {
    @JvmStatic
    fun setInsets(bottomDp: Int) {
        GlassDockState.bottomInset = bottomDp.toFloat()
    }

    @JvmStatic
    fun attach(act: Activity, web: WebView) {
        web.addJavascriptInterface(DockBridge(act), "GlassDock")
        (web.parent as? ViewGroup)?.removeView(web)
        val cv = ComposeView(act)
        cv.setContent { GlassRoot(web) }
        act.setContentView(cv)
    }
}

private fun DrawScope.drawGlassIcon(key: String, color: Color, sizePx: Float) {
    val paths = GLASS_ICONS[key] ?: return
    withTransform({ scale(sizePx / 24f, sizePx / 24f, pivot = Offset.Zero) }) {
        for (d in paths) {
            val path = PathParser().parsePathString(d).toPath()
            drawPath(path, color, style = Stroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

@Composable
private fun GlassRoot(web: WebView) {
    val st = GlassDockState
    val backdrop = rememberLayerBackdrop {
        drawRect(st.bg)
        drawContent()
    }
    val barBackdrop = rememberLayerBackdrop()
    val density = LocalDensity.current
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    val scope = rememberCoroutineScope()
    val textColor = if (st.dark) Color.White else Color(0xFF121212)
    val hintColor = if (st.dark) Color(0xFFB4B9C3) else Color(0xFF5C626E)
    val surface = if (st.dark) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.5f)
    val api33 = Build.VERSION.SDK_INT >= 33
    val api31 = Build.VERSION.SDK_INT >= 31

    fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }

    var barW by remember { mutableIntStateOf(0) }
    val itemW = if (barW > 0) barW / 4f else 0f
    fun xFor(i: Int): Float = if (rtl) barW - (i + 1) * itemW else i * itemW
    fun indexAt(centerX: Float): Int {
        val li = (centerX / (if (itemW > 0f) itemW else 1f)).toInt().coerceIn(0, 3)
        return if (rtl) 3 - li else li
    }
    val pos = remember { Animatable(0f) }
    var dragging by remember { mutableStateOf(false) }
    var stretchT by remember { mutableFloatStateOf(0f) }
    var kick by remember { mutableIntStateOf(0) }
    val stretch by animateFloatAsState(stretchT, spring(dampingRatio = 0.8f, stiffness = 260f), label = "stretch")
    val press by animateFloatAsState(if (dragging) 1.12f else 1f, spring(dampingRatio = 0.8f, stiffness = 260f), label = "press")
    val hideP by animateFloatAsState(if (st.hide) 1f else 0f, spring(dampingRatio = 0.95f, stiffness = 200f), label = "hide")
    val viewIdx = KEYS.indexOf(st.view).coerceAtLeast(0)

    androidx.compose.runtime.LaunchedEffect(viewIdx, barW, rtl, dragging) {
        if (barW > 0 && !dragging) pos.animateTo(xFor(viewIdx), spring(dampingRatio = 0.85f, stiffness = 200f))
    }
    androidx.compose.runtime.LaunchedEffect(kick) {
        if (kick > 0) { delay(70); stretchT = 0f }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { (web.parent as? ViewGroup)?.removeView(web); web },
            modifier = Modifier.fillMaxSize().layerBackdrop(backdrop)
        )

        if (hideP < 0.98f) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, bottom = (GlassDockState.bottomInset + 12f).dp)
                    .graphicsLayer { translationY = hideP * 170.dp.toPx(); alpha = 1f - hideP },
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // ----- داک -----
                Box(
                    Modifier
                        .weight(1f)
                        .height(64.dp)
                        .onSizeChanged { barW = it.width }
                        .drawBackdrop(
                            backdrop = backdrop,
                            shape = { RoundedCornerShape(32.dp) },
                            effects = {
                                vibrancy()
                                if (api31) blur(10.dp.toPx())
                                if (api33) lens(14.dp.toPx(), 28.dp.toPx())
                            },
                            exportedBackdrop = barBackdrop,
                            onDrawSurface = { drawRect(surface) }
                        )
                        .pointerInput(barW, rtl) {
                            detectDragGestures(
                                onDragStart = { dragging = true },
                                onDragEnd = {
                                    dragging = false
                                    val i = indexAt(pos.value + itemW / 2f)
                                    st.view = KEYS[i]
                                    js("window.__dock&&window.__dock.go('${KEYS[i]}')")
                                },
                                onDragCancel = { dragging = false },
                                onDrag = { change, amount ->
                                    change.consume()
                                    val lo = minOf(xFor(0), xFor(3)); val hi = maxOf(xFor(0), xFor(3))
                                    scope.launch { pos.snapTo((pos.value + amount.x).coerceIn(lo, hi)) }
                                    stretchT = (abs(amount.x) / 14f * 0.5f).coerceAtMost(0.5f)
                                    kick++
                                }
                            )
                        }
                ) {
                    Row(Modifier.fillMaxSize()) {
                        KEYS.forEachIndexed { i, key ->
                            val on = i == viewIdx
                            Column(
                                Modifier
                                    .weight(1f)
                                    .fillMaxSize()
                                    .clickable(interactionSource = null, indication = null) {
                                        st.view = key
                                        js("window.__dock&&window.__dock.go('$key')")
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                val c = if (on) st.accent else hintColor
                                Canvas(Modifier.size(22.dp)) { drawGlassIcon(ICON_OF[key] ?: key, c, size.width) }
                                BasicText(
                                    st.labels.getOrElse(i) { key },
                                    style = TextStyle(color = c, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                )
                            }
                        }
                    }
                    // نشانگر شیشه‌ای که لغزیده و آیکون‌های زیرش رو خم می‌کنه
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Box(Modifier.fillMaxSize()) {
                            val wDp = with(density) { (itemW - 8.dp.toPx()).coerceAtLeast(10f).toDp() }
                            Box(
                                Modifier
                                    .absoluteOffset { IntOffset((pos.value + 4.dp.toPx()).roundToInt(), 6.dp.roundToPx()) }
                                    .width(wDp)
                                    .height(52.dp)
                                    .drawBackdrop(
                                        backdrop = barBackdrop,
                                        shape = { RoundedCornerShape(26.dp) },
                                        effects = { if (api33) lens(14.dp.toPx(), 26.dp.toPx(), true) },
                                        layerBlock = {
                                            scaleX = press * (1f + stretch)
                                            scaleY = press * (1f - stretch * 0.35f)
                                        },
                                        onDrawSurface = { drawRect(Color.White.copy(alpha = if (st.dark) 0.06f else 0.35f)) }
                                    )
                            )
                        }
                    }
                }

                // ----- دکمه‌ی + -----
                val rot by animateFloatAsState(if (st.open) 45f else 0f, spring(dampingRatio = 0.8f, stiffness = 260f), label = "rot")
                Box(
                    Modifier
                        .size(64.dp)
                        .drawBackdrop(
                            backdrop = backdrop,
                            shape = { CircleShape },
                            effects = {
                                vibrancy()
                                if (api31) blur(6.dp.toPx())
                                if (api33) lens(14.dp.toPx(), 28.dp.toPx())
                            },
                            onDrawSurface = { drawRect(st.accent.copy(alpha = 0.82f)) }
                        )
                        .clickable(interactionSource = null, indication = null) { js("window.__dock&&window.__dock.fab()") },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.size(28.dp).graphicsLayer { rotationZ = rot }) { drawGlassIcon("plus", Color.White, size.width) }
                }
            }
        }
    }
}
