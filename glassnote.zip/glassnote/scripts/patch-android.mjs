// بعد از `npx cap add android` اجرا می‌شه و پروژه‌ی اندروید رو شخصی‌سازی می‌کنه.
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const android = path.join(root, "android");
const app = path.join(android, "app");
if (!fs.existsSync(app)) { console.error("پوشه‌ی android پیدا نشد. اول `npx cap add android` رو بزن."); process.exit(1); }

// 1) آیکون‌ها
const src = path.join(root, "resources", "android", "res");
const dst = path.join(app, "src", "main", "res");
function copyDir(a, b) {
  for (const e of fs.readdirSync(a, { withFileTypes: true })) {
    const pa = path.join(a, e.name), pb = path.join(b, e.name);
    if (e.isDirectory()) { fs.mkdirSync(pb, { recursive: true }); copyDir(pa, pb); }
    else { fs.mkdirSync(path.dirname(pb), { recursive: true }); fs.copyFileSync(pa, pb); }
  }
}
if (fs.existsSync(src)) {
  // آیکون‌های پیش‌فرض (webp/png/xml قدیمی) رو پاک می‌کنیم تا با آیکون ما تداخل نکنن
  for (const d of fs.readdirSync(dst)) {
    if (!d.startsWith("mipmap-")) continue;
    for (const f of fs.readdirSync(path.join(dst, d))) {
      if (f.startsWith("ic_launcher")) fs.rmSync(path.join(dst, d, f), { force: true });
    }
  }
  copyDir(src, dst);
  console.log("✓ آیکون‌ها کپی شد");
}

// 2) مانیفست
const mfPath = path.join(app, "src", "main", "AndroidManifest.xml");
let mf = fs.readFileSync(mfPath, "utf8");
const perms = [
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.SCHEDULE_EXACT_ALARM",
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.VIBRATE",
];
for (const p of perms) {
  if (!mf.includes(p)) mf = mf.replace("</manifest>", `    <uses-permission android:name="${p}" />\n</manifest>`);
}
if (!/windowSoftInputMode/.test(mf)) mf = mf.replace("<activity", '<activity\n            android:windowSoftInputMode="adjustResize"');
else mf = mf.replace(/android:windowSoftInputMode="[^"]*"/, 'android:windowSoftInputMode="adjustResize"');
fs.writeFileSync(mfPath, mf);
console.log("✓ مانیفست آپدیت شد");

// 3) نسخه و امضا
const gPath = path.join(app, "build.gradle");
let g = fs.readFileSync(gPath, "utf8");
const vc = process.env.VERSION_CODE || "1";
const vn = process.env.VERSION_NAME || "1.0.0";
g = g.replace(/versionCode\s+\d+/, `versionCode ${vc}`).replace(/versionName\s+"[^"]*"/, `versionName "${vn}"`);

if (process.env.KEYSTORE_FILE && fs.existsSync(process.env.KEYSTORE_FILE) && !g.includes("signingConfigs")) {
  const block = `
    signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_FILE"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
`;
  g = g.replace(/android\s*\{/, (m) => m + block);
  g = g.replace(/buildTypes\s*\{\s*release\s*\{/, (m) => m + "\n            signingConfig signingConfigs.release");
  console.log("✓ امضای release فعال شد");
}
fs.writeFileSync(gPath, g);
console.log("✓ نسخه:", vn, `(${vc})`);
