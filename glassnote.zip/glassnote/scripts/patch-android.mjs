// بعد از `npx cap add android` اجرا می‌شه و پروژه‌ی اندروید رو شخصی‌سازی می‌کنه.
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const android = path.join(root, "android");
const app = path.join(android, "app");
if (!fs.existsSync(app)) { console.error("پوشه‌ی android پیدا نشد. اول `npx cap add android` رو بزن."); process.exit(1); }

// 1) آیکون‌ها
const src = path.join(root, "resources", "android", "res");
const dst = path.join(app, "src", "main", "res");
function copyDir(a, b) {
  for (const e of fs.readdirSync(a, { withFileTypes: true })) {
    const pa = path.join(a, e.name), pb = path.join(b, e.name);
    if (e.isDirectory()) { fs.mkdirSync(pb, { recursive: true }); copyDir(pa, pb); }
    else { fs.mkdirSync(path.dirname(pb), { recursive: true }); fs.copyFileSync(pa, pb); }
  }
}
if (fs.existsSync(src)) {
  // آیکون‌های پیش‌فرض (webp/png/xml قدیمی) رو پاک می‌کنیم تا با آیکون ما تداخل نکنن
  for (const d of fs.readdirSync(dst)) {
    if (!d.startsWith("mipmap-")) continue;
    for (const f of fs.readdirSync(path.join(dst, d))) {
      if (f.startsWith("ic_launcher")) fs.rmSync(path.join(dst, d, f), { force: true });
    }
  }
  copyDir(src, dst);
  console.log("✓ آیکون‌ها کپی شد");
}

// 1b) MainActivity: برنامه لبه‌به‌لبه می‌شه، نوار وضعیت/ناوبری شفاف می‌شن و فاصله‌های امن به صفحه داده می‌شه
const javaRoot = path.join(app, "src", "main", "java");
function findFile(dir, name) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { const r = findFile(p, name); if (r) return r; }
    else if (e.name === name) return p;
  }
  return null;
}
const mainPath = findFile(javaRoot, "MainActivity.java");
if (mainPath) {
  const pkg = (/package\s+([\w.]+);/.exec(fs.readFileSync(mainPath, "utf8")) || [])[1] || "com.glassnote.app";
  fs.writeFileSync(mainPath, `package ${pkg};

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private String lastInsets = "0,0,0,0";

    private class Bars {
        @JavascriptInterface
        public String insets() { return lastInsets; }

        @JavascriptInterface
        public void setLight(final boolean light) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Window w = getWindow();
                    WindowInsetsControllerCompat c = WindowCompat.getInsetsController(w, w.getDecorView());
                    c.setAppearanceLightStatusBars(light);
                    c.setAppearanceLightNavigationBars(light);
                }
            });
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Window window = getWindow();
        WindowCompat.setDecorFitsSystemWindows(window, false);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
        }

        final WebView web = getBridge().getWebView();
        web.addJavascriptInterface(new Bars(), "GlassBars");

        final View content = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(window.getDecorView(), new androidx.core.view.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsetsCompat onApplyWindowInsets(View v, WindowInsetsCompat insets) {
                Insets sys = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
                boolean imeOn = insets.isVisible(WindowInsetsCompat.Type.ime());
                int imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
                content.setPadding(0, 0, 0, imeOn ? imeBottom : 0);
                float d = getResources().getDisplayMetrics().density;
                int top = Math.round(sys.top / d);
                int right = Math.round(sys.right / d);
                int bottom = imeOn ? 0 : Math.round(sys.bottom / d);
                int left = Math.round(sys.left / d);
                lastInsets = top + "," + right + "," + bottom + "," + left;
                web.post(new Runnable() {
                    @Override
                    public void run() {
                        web.evaluateJavascript("window.__insets&&window.__insets(" + lastInsets + ")", null);
                    }
                });
                return WindowInsetsCompat.CONSUMED;
            }
        });
        ViewCompat.requestApplyInsets(window.getDecorView());
    }
}
`);
  console.log("✓ MainActivity (لبه‌به‌لبه) نوشته شد");
}

// 1c) اسپلش ساده با رنگ زمینه (به‌جای لوگوی پیش‌فرض Capacitor)
const resDir = path.join(app, "src", "main", "res");
for (const d of fs.readdirSync(resDir)) {
  if (!d.startsWith("drawable")) continue;
  for (const f of fs.readdirSync(path.join(resDir, d))) if (/^splash\.(png|jpg|webp)$/.test(f)) fs.rmSync(path.join(resDir, d, f), { force: true });
}
fs.mkdirSync(path.join(resDir, "drawable"), { recursive: true });
fs.writeFileSync(path.join(resDir, "drawable", "splash.xml"), `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="#F5F6F8"/>
</shape>
`);
console.log("✓ اسپلش ساده شد");

// 2) مانیفست
const mfPath = path.join(app, "src", "main", "AndroidManifest.xml");
let mf = fs.readFileSync(mfPath, "utf8");
const perms = [
  "android.permission.POST_NOTIFICATIONS",
  "android.permission.SCHEDULE_EXACT_ALARM",
  "android.permission.RECEIVE_BOOT_COMPLETED",
  "android.permission.VIBRATE",
];
for (const p of perms) {
  if (!mf.includes(p)) mf = mf.replace("</manifest>", `    <uses-permission android:name="${p}" />\n</manifest>`);
}
if (!/windowSoftInputMode/.test(mf)) mf = mf.replace("<activity", '<activity\n            android:windowSoftInputMode="adjustResize"');
else mf = mf.replace(/android:windowSoftInputMode="[^"]*"/, 'android:windowSoftInputMode="adjustResize"');
fs.writeFileSync(mfPath, mf);
console.log("✓ مانیفست آپدیت شد");

// 3) نسخه و امضا
const gPath = path.join(app, "build.gradle");
let g = fs.readFileSync(gPath, "utf8");
const vc = process.env.VERSION_CODE || "1";
const vn = process.env.VERSION_NAME || "1.0.0";
g = g.replace(/versionCode\s+\d+/, `versionCode ${vc}`).replace(/versionName\s+"[^"]*"/, `versionName "${vn}"`);

if (process.env.KEYSTORE_FILE && fs.existsSync(process.env.KEYSTORE_FILE) && !g.includes("signingConfigs")) {
  const block = `
    signingConfigs {
        release {
            storeFile file(System.getenv("KEYSTORE_FILE"))
            storePassword System.getenv("KEYSTORE_PASSWORD")
            keyAlias System.getenv("KEY_ALIAS")
            keyPassword System.getenv("KEY_PASSWORD")
        }
    }
`;
  g = g.replace(/android\s*\{/, (m) => m + block);
  g = g.replace(/buildTypes\s*\{\s*release\s*\{/, (m) => m + "\n            signingConfig signingConfigs.release");
  console.log("✓ امضای release فعال شد");
}
fs.writeFileSync(gPath, g);
console.log("✓ نسخه:", vn, `(${vc})`);
