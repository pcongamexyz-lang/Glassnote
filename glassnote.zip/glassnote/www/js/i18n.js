// چندزبانگی: زبان از تنظیمات یا زبان گوشی خونده می‌شه. کلیدها همون متن فارسی‌ان.
import { EN } from "./lang-en.js";

const RTL = new Set(["fa", "ar", "he", "ur"]);
function pick() {
  let pref = "auto";
  try { pref = (JSON.parse(localStorage.getItem("gn.settings.v1") || "{}").lang) || "auto"; } catch (e) {}
  if (pref !== "auto") return pref;
  const l = ((navigator.languages && navigator.languages[0]) || navigator.language || "fa").toLowerCase();
  return l.startsWith("fa") ? "fa" : "en";
}
export const lang = pick();
export const dir = RTL.has(lang) ? "rtl" : "ltr";
export const locale = lang === "fa" ? "fa-IR" : ((navigator.languages && navigator.languages[0]) || "en-US");

const RUN = /[؀-ۿ][؀-ۿ‌\s·،؟!:\-()«»….۰-۹]*/g;
const cache = new Map();
export function Tr(s) {
  if (lang === "fa") return s;
  let r = cache.get(s);
  if (r !== undefined) return r;
  r = EN[s];
  if (r === undefined) {
    r = s.replace(RUN, (m) => {
      const k = m.trim();
      const v = EN[k];
      if (v === undefined) { (window.__missing = window.__missing || new Set()).add(k); return m; }
      return m.replace(k, v);
    });
  }
  r = r.replace(/«/g, "“").replace(/»/g, "”").replace(/؟/g, "?").replace(/،/g, ",").replace(/؛/g, ";");
  cache.set(s, r);
  return r;
}
// تگ برای رشته‌های قالبی: هر تکه جدا ترجمه می‌شه
export function Trt(strings, ...v) {
  if (lang === "fa") return strings.reduce((a, s, i) => a + s + (i < v.length ? v[i] : ""), "");
  return strings.reduce((a, s, i) => a + Tr(s) + (i < v.length ? v[i] : ""), "");
}
document.documentElement.lang = lang;
document.documentElement.dir = dir;
