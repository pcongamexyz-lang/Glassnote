// ادیتور متن غنی (WYSIWYG): پررنگ، کج، زیرخط، رنگ، لیست، چک‌لیست، لینک، تیتر، نقل‌قول، کد و ...
import { el, txt, icon, toast, fa, esc, toFaDigits, toEnDigits, fixArabicChars, fmtDateFa, fmtDateEn, fmtTime } from "./utils.js";
import { openSheet, menuSheet } from "./sheets.js";
import { Tr, Trt } from "./i18n.js";
import { sanitize, wrapLoose, addDirs } from "./html.js";

const TEXT_COLORS = ["#E5484D", "#F2994A", "#D9A400", "#30A46C", "#2F7CF6", "#8E4EC6", "#E93D82", "#7A808B"];
const HILITES = ["#FFE66D", "#B9F0BC", "#BFE3FF", "#FFC9DE", "#E4D2FF", "#FFD6A8"];
const BLOCK_SEL = "div,p,li,h1,h2,h3,blockquote,pre";

export function mount(host, note, api) {
  const root = el("div", "rte");
  root.contentEditable = "true"; root.spellcheck = false;
  root.setAttribute("role", "textbox"); root.setAttribute("aria-multiline", "true");
  root.setAttribute("autocapitalize", "sentences");
  root.dataset.ph = Tr("بنویس…");
  const empty = '<div dir="auto"><br></div>';
  root.innerHTML = note.body ? sanitize(note.body) || empty : empty;
  host.append(root);
  try { document.execCommand("defaultParagraphSeparator", false, "div"); } catch (e) {}

  let touched = false;
  const isBlank = () => !root.textContent.trim() && !root.querySelector("hr");
  const html = () => (isBlank() ? "" : root.innerHTML);
  const blank = () => root.classList.toggle("blank", !root.textContent && !root.querySelector("hr,li"));
  blank();

  /* ---------- انتخاب ---------- */
  let saved = null, raf = 0;
  const inRoot = (n) => n && root.contains(n);
  const sel = () => getSelection();
  function onSel() {
    const s = sel();
    if (s && s.rangeCount && inRoot(s.anchorNode)) { saved = s.getRangeAt(0).cloneRange(); updateState(); }
  }
  document.addEventListener("selectionchange", onSel);
  function restore() {
    const s = sel();
    if (document.activeElement === root && s.rangeCount && inRoot(s.anchorNode)) return;
    root.focus({ preventScroll: true });
    if (saved) { s.removeAllRanges(); s.addRange(saved); }
  }
  function anchorEl() { const s = sel(); const n = s.rangeCount ? s.anchorNode : null; return n && inRoot(n) ? (n.nodeType === 1 ? n : n.parentElement) : null; }
  const up = (tag) => { const e = anchorEl(); return e ? e.closest(tag) : null; };
  const within = (e) => e && root.contains(e) && e !== root ? e : null;

  const cleanChrome = () => root.querySelectorAll("span[style]").forEach((e) => { e.style.removeProperty("font-size"); e.style.removeProperty("font-family"); if (!e.getAttribute("style")) { e.removeAttribute("style"); if (!e.className) { while (e.firstChild) e.parentNode.insertBefore(e.firstChild, e); e.remove(); } } });
  const after = () => { touched = true; cleanChrome(); addDirs(root); api.onChange(html()); blank(); updateState(); };
  // بعضی فرمان‌های بلوکی (لیست، تیتر، ...) مکان‌نما رو به اول خط می‌برن؛ اینجا سر جاش برمی‌گردونیم
  function caretOffset() {
    const s = sel();
    if (!s.rangeCount || !s.isCollapsed || !inRoot(s.anchorNode)) return -1;
    const r = document.createRange(); r.selectNodeContents(root); r.setEnd(s.anchorNode, s.anchorOffset);
    return r.toString().length;
  }
  function setCaretAt(off) {
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n, acc = 0;
    while ((n = w.nextNode())) {
      const l = n.nodeValue.length;
      if (acc + l >= off) {
        const r = document.createRange(); r.setStart(n, off - acc); r.collapse(true);
        const s = sel(); s.removeAllRanges(); s.addRange(r); return;
      }
      acc += l;
    }
  }
  function keep(fn) {
    const before = caretOffset();
    fn();
    if (before >= 0 && caretOffset() !== before) setCaretAt(before);
  }
  function ex(cmd, val = null, css = false, keepCaret = false) {
    restore();
    try { document.execCommand("styleWithCSS", false, css); } catch (e) {}
    if (keepCaret) keep(() => document.execCommand(cmd, false, val)); else document.execCommand(cmd, false, val);
    after();
  }

  /* ---------- رویدادها ---------- */
  root.addEventListener("input", (e) => {
    if (!root.firstChild) { root.innerHTML = empty; const r = document.createRange(); r.setStart(root.firstChild, 0); r.collapse(true); const s = sel(); s.removeAllRanges(); s.addRange(r); }
    else if (root.firstChild.nodeType === 3 || (root.firstChild.nodeType === 1 && !/^(DIV|P|H1|H2|H3|UL|OL|BLOCKQUOTE|PRE|HR)$/.test(root.firstChild.tagName))) {
      wrapLoose(root);
      const d = root.firstChild, r = document.createRange(); r.selectNodeContents(d); r.collapse(false);
      const s = sel(); s.removeAllRanges(); s.addRange(r);
    }
    if (e.inputType === "insertParagraph") { const li = up("li"); if (li) li.classList.remove("done"); addDirs(root); }
    touched = true; api.onChange(html()); blank();
  });
  root.addEventListener("paste", (e) => {
    e.preventDefault();
    const cd = e.clipboardData;
    if (!cd) return;
    const h = cd.getData("text/html"), t = cd.getData("text/plain");
    if (h) document.execCommand("insertHTML", false, sanitize(h));
    else if (t) document.execCommand("insertText", false, t);
    after();
  });
  root.addEventListener("drop", (e) => e.preventDefault());
  root.addEventListener("click", (e) => {
    const li = e.target.closest && e.target.closest("li");
    if (!li || !li.parentElement.classList.contains("todo")) return;
    const r = li.getBoundingClientRect(), rtl = getComputedStyle(li).direction === "rtl";
    if (rtl ? e.clientX > r.right - 38 : e.clientX < r.left + 38) {
      e.preventDefault();
      li.classList.toggle("done");
      if (api.haptic) api.haptic();
      touched = true; api.onChange(html());
    }
  });

  /* ---------- نوار ابزار ---------- */
  const tb = el("div", "rich-tb");
  const row1 = el("div", "dt-row"), row2 = el("div", "dt-row");
  tb.append(row1, row2);
  const btns = {};
  function add(row, key, ic, label, fn) {
    const b = el("button", "tb", icon(ic)); b.setAttribute("aria-label", label); b.tabIndex = -1;
    b.addEventListener("pointerdown", (e) => e.preventDefault());
    b.addEventListener("mousedown", (e) => e.preventDefault());
    b.onclick = () => { fn(); };
    btns[key] = b; row.append(b);
  }
  add(row1, "undo", "undo", Tr("برگردان"), () => ex("undo"));
  add(row1, "redo", "redo", Tr("جلو"), () => ex("redo"));
  add(row1, "bold", "bold", Tr("پررنگ"), () => ex("bold"));
  add(row1, "italic", "italic", Tr("کج"), () => ex("italic"));
  add(row1, "underline", "underline", Tr("زیرخط"), () => ex("underline"));
  add(row1, "strike", "strike", Tr("خط‌خورده"), () => ex("strikeThrough"));
  add(row1, "code", "code", Tr("کد"), toggleCode);
  add(row1, "color", "textcolor", Tr("رنگ متن"), openColor);
  add(row1, "hilite", "hl", Tr("هایلایت متن"), openHilite);
  add(row1, "link", "link", Tr("لینک"), openLink);
  add(row2, "style", "aa", Tr("سبک متن"), openStyle);
  add(row2, "ul", "list", Tr("فهرست"), () => toList("ul"));
  add(row2, "ol", "ol", Tr("فهرست شماره‌دار"), () => toList("ol"));
  add(row2, "todo", "checklist", Tr("چک‌باکس"), () => toList("todo"));
  add(row2, "align", "align", Tr("تراز"), openAlign);
  add(row2, "outdent", "outdent", Tr("تورفتگی کمتر"), () => indent(-1));
  add(row2, "indent", "indent", Tr("تورفتگی بیشتر"), () => indent(1));
  add(row2, "dir", "dirflip", Tr("جهت متن"), flipDir);
  add(row2, "clear", "clearfmt", Tr("پاک‌کردن قالب"), clearFormat);
  add(row2, "tools", "wand", Tr("ابزارهای متن"), openTools);

  function q(cmd) { try { return document.queryCommandState(cmd); } catch (e) { return false; } }
  function updateState() {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      const on = (k, v) => btns[k] && btns[k].classList.toggle("on", !!v);
      const inEd = document.activeElement === root;
      on("bold", inEd && q("bold")); on("italic", inEd && q("italic")); on("underline", inEd && q("underline")); on("strike", inEd && q("strikeThrough"));
      const todo = inEd && up("ul.todo");
      on("todo", todo); on("ul", inEd && q("insertUnorderedList") && !todo); on("ol", inEd && q("insertOrderedList"));
      on("code", inEd && up("code")); on("link", inEd && up("a"));
      const blk = inEd ? up("h1,h2,h3,blockquote,pre") : null;
      on("style", blk);
    });
  }

  /* ---------- فرمان‌ها ---------- */
  // کد: روی متن انتخاب‌شده‌ی یک خط → کد درون‌خطی؛ روی چند خط یا خط خالی → بلوک کد؛ دوباره زدن → برگشت.
  // (با DOM مستقیم ساخته می‌شه چون insertHTML کروم تگ code رو به span با استایل‌های جعلی تبدیل می‌کنه)
  const blockOf = (nd) => { const e = nd && (nd.nodeType === 1 ? nd : nd.parentElement); return e && root.contains(e) ? e.closest("div,p,li,h1,h2,h3,blockquote,pre") : null; };
  const topOf = (nd, off) => { if (nd === root) { const k = root.children; return k.length ? k[Math.min(Math.max((off || 0) - (off && off >= k.length ? 1 : 0), 0), k.length - 1)] : null; } let e = nd && (nd.nodeType === 1 ? nd : nd.parentElement); while (e && e.parentElement !== root) e = e.parentElement; return e && e.parentElement === root ? e : null; };
  function caretTo(node, end) { const r = document.createRange(); r.selectNodeContents(node); r.collapse(!end); const s = sel(); s.removeAllRanges(); s.addRange(r); }
  function unwrapEl(e) {
    const parent = e.parentNode; let last = null;
    while (e.firstChild) { last = e.firstChild; parent.insertBefore(last, e); }
    e.remove();
    if (last) { const r = document.createRange(); r.setStartAfter(last); r.collapse(true); const s = sel(); s.removeAllRanges(); s.addRange(r); }
  }
  function linesOf(el) {
    const out = [];
    const cur = [""];
    (function walk(n) {
      for (const c of n.childNodes) {
        if (c.nodeType === 3) cur[cur.length - 1] += c.nodeValue;
        else if (c.nodeType === 1) {
          if (c.tagName === "BR") cur.push("");
          else { const blk = /^(DIV|P|LI|H1|H2|H3|BLOCKQUOTE|PRE|UL|OL)$/.test(c.tagName); if (blk && cur[cur.length - 1] !== "") cur.push(""); walk(c); if (blk) cur.push(""); }
        }
      }
    })(el);
    while (cur.length > 1 && cur[cur.length - 1] === "") cur.pop();
    return cur.map((x) => x.replace(/[\u200b]/g, ""));
  }
  function makePre() {
    const s = sel();
    if (!root.firstElementChild) { const d = document.createElement("div"); d.setAttribute("dir", "auto"); while (root.firstChild) d.append(root.firstChild); if (!d.firstChild) d.innerHTML = "<br>"; root.append(d); caretTo(d, false); }
    else if (![...root.childNodes].every((c) => c.nodeType === 1)) { const d = document.createElement("div"); d.setAttribute("dir", "auto"); [...root.childNodes].filter((c) => c.nodeType === 3 || c.nodeName === "BR").forEach((c) => d.append(c)); if (d.firstChild) { root.prepend(d); caretTo(d, true); } }
    const a = topOf(s.anchorNode, s.anchorOffset), f = topOf(s.focusNode, s.focusOffset);
    if (!a) return;
    let tops = [a];
    if (f && f !== a) { const all = [...root.children], i = all.indexOf(a), j = all.indexOf(f); tops = all.slice(Math.min(i, j), Math.max(i, j) + 1); }
    const pre = document.createElement("pre"); pre.setAttribute("dir", "ltr");
    const lines = tops.flatMap(linesOf);
    lines.forEach((l, i) => { if (i) pre.append(document.createElement("br")); if (l) pre.append(document.createTextNode(l)); });
    if (!pre.firstChild) pre.append(document.createElement("br"));
    tops[0].before(pre); tops.forEach((t) => t.remove());
    if (!pre.nextElementSibling) { const d = document.createElement("div"); d.setAttribute("dir", "auto"); d.innerHTML = "<br>"; pre.after(d); }
    caretTo(pre, true);
  }
  function preToDiv(pre) {
    const d = document.createElement("div"); d.setAttribute("dir", "auto");
    while (pre.firstChild) d.append(pre.firstChild);
    if (!d.firstChild) d.innerHTML = "<br>";
    pre.replaceWith(d); caretTo(d, true);
  }
  function toggleCode() {
    restore();
    const s = sel();
    const pre = within(up("pre"));
    if (pre) { preToDiv(pre); after(); return; }
    const code = within(up("code"));
    if (code) { unwrapEl(code); after(); return; }
    if (s.rangeCount && !s.isCollapsed && inRoot(s.anchorNode)) {
      const a = blockOf(s.anchorNode), f = blockOf(s.focusNode);
      if (a && a === f && s.toString().length < a.textContent.length) {
        const r = s.getRangeAt(0), frag = r.extractContents();
        frag.querySelectorAll("code,pre").forEach((e) => unwrapEl(e));
        const c = document.createElement("code"); c.append(frag);
        r.insertNode(c);
        const r2 = document.createRange(); r2.selectNodeContents(c); s.removeAllRanges(); s.addRange(r2);
      } else makePre();
    } else makePre();
    after();
  }
  // Enter داخل بلوک کد: خط جدید؛ Enter روی خط خالیِ آخر: خروج از بلوک
  root.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" || e.shiftKey) return;
    const pre = within(up("pre"));
    if (!pre) return;
    e.preventDefault();
    const s = sel(), r = s.getRangeAt(0);
    const atEnd = (() => { const t = document.createRange(); t.selectNodeContents(pre); t.setStart(r.endContainer, r.endOffset); return !t.toString().length; })();
    const last = pre.lastChild;
    if (atEnd && last && last.nodeName === "BR" && last.previousSibling && last.previousSibling.nodeName === "BR") {
      last.remove();
      let nx = pre.nextElementSibling;
      if (!nx) { nx = document.createElement("div"); nx.setAttribute("dir", "auto"); nx.innerHTML = "<br>"; pre.after(nx); }
      caretTo(nx, false); after(); return;
    }
    document.execCommand("insertLineBreak");
    if (atEnd) document.execCommand("insertLineBreak"); // خط آخر دیده بشه
    if (atEnd) { const t = pre.lastChild; if (t && t.nodeName === "BR") { const rr = document.createRange(); rr.setStartBefore(t); rr.collapse(true); s.removeAllRanges(); s.addRange(rr); } }
    after();
  });

  function toList(kind) {
    restore();
    keep(() => {
      const ul = up("ul"), ol = up("ol");
      if (kind === "todo") {
        if (ul && ul.classList.contains("todo")) { document.execCommand("insertUnorderedList"); ul.classList.remove("todo"); }
        else if (ul) ul.classList.add("todo");
        else { document.execCommand("insertUnorderedList"); const u = up("ul"); if (u) u.classList.add("todo"); }
      } else if (kind === "ul") {
        if (ul && ul.classList.contains("todo")) ul.classList.remove("todo");
        else document.execCommand("insertUnorderedList");
      } else {
        if (ul && ul.classList.contains("todo")) ul.classList.remove("todo");
        document.execCommand("insertOrderedList");
      }
    });
    after();
  }
  function blocksInSel() {
    const s = sel();
    if (!s.rangeCount) return [];
    const r = s.getRangeAt(0);
    return [...root.children].filter((c) => r.intersectsNode(c));
  }
  function indent(d) {
    restore();
    if (up("li")) { ex(d > 0 ? "indent" : "outdent", null, false, true); return; }
    blocksInSel().forEach((b) => {
      const m = /ind([1-3])/.exec(b.className), cur = m ? +m[1] : 0, nx = Math.max(0, Math.min(3, cur + d));
      b.className = b.className.replace(/\bind[1-3]\b/g, "").trim();
      if (nx) b.classList.add("ind" + nx);
      if (!b.className) b.removeAttribute("class");
    });
    after();
  }
  function flipDir() {
    restore();
    const li = up("li");
    const targets = li ? [li] : blocksInSel();
    targets.forEach((b) => b.setAttribute("dir", getComputedStyle(b).direction === "rtl" ? "ltr" : "rtl"));
    after();
  }
  function clearFormat() {
    restore();
    try { document.execCommand("styleWithCSS", false, false); } catch (e) {}
    document.execCommand("removeFormat"); document.execCommand("unlink");
    if (up("h1,h2,h3,blockquote,pre")) keep(() => document.execCommand("formatBlock", false, "div"));
    after();
  }
  function setColor(kind, c) {
    restore();
    try { document.execCommand("styleWithCSS", false, true); } catch (e) {}
    if (c) document.execCommand(kind === "fore" ? "foreColor" : "hiliteColor", false, c);
    else {
      // برداشتن رنگ: استایل رنگ از المان‌های درون انتخاب پاک می‌شه
      const s = sel(); const r = s.rangeCount ? s.getRangeAt(0) : null;
      if (r) root.querySelectorAll("[style]").forEach((e) => {
        if (!r.intersectsNode(e)) return;
        if (kind === "fore") e.style.removeProperty("color"); else e.style.removeProperty("background-color");
        if (!e.getAttribute("style")) { e.removeAttribute("style"); if (e.tagName === "SPAN" && !e.className) { while (e.firstChild) e.parentNode.insertBefore(e.firstChild, e); e.remove(); } }
      });
    }
    try { document.execCommand("styleWithCSS", false, false); } catch (e) {}
    after();
  }
  function colorSheet(title, colors, kind) {
    openSheet({
      title,
      build(b, sh) {
        const sw = el("div", "swatches");
        const none = el("button", "sw none", icon("x")); none.setAttribute("aria-label", Tr("بدون رنگ"));
        none.onclick = () => { sh.close(); setTimeout(() => setColor(kind, null), 30); };
        sw.append(none);
        colors.forEach((c) => {
          const s = el("button", "sw"); s.style.background = c; s.setAttribute("aria-label", c);
          s.onclick = () => { sh.close(); setTimeout(() => setColor(kind, c), 30); };
          sw.append(s);
        });
        b.append(sw);
      },
    });
  }
  function openColor() { colorSheet(Tr("رنگ متن"), TEXT_COLORS, "fore"); }
  function openHilite() { colorSheet(Tr("هایلایت متن"), HILITES, "back"); }

  function openAlign() {
    const cmd = (c) => () => setTimeout(() => ex(c, null, false, true), 30);
    menuSheet({ title: Tr("تراز"), items: [
      { icon: "align", label: Tr("چپ"), onClick: cmd("justifyLeft") },
      { icon: "align", label: Tr("وسط"), onClick: cmd("justifyCenter") },
      { icon: "align", label: Tr("راست"), onClick: cmd("justifyRight") },
      { icon: "align", label: Tr("دوطرفه"), onClick: cmd("justifyFull") },
    ] });
  }

  function openStyle() {
    const cur = (document.queryCommandValue ? String(document.queryCommandValue("formatBlock") || "") : "").toLowerCase().replace(/[<>]/g, "");
    const fb = (tag) => () => setTimeout(() => { restore(); keep(() => document.execCommand("formatBlock", false, tag)); after(); }, 30);
    const fs = (n) => () => setTimeout(() => { restore(); try { document.execCommand("styleWithCSS", false, false); } catch (e) {} document.execCommand("fontSize", false, n); after(); }, 30);
    menuSheet({ title: Tr("سبک متن"), items: [
      { icon: "text", label: Tr("متن معمولی"), check: cur === "div" || cur === "p" || cur === "", onClick: fb("div") },
      { icon: "heading", label: Tr("تیتر بزرگ"), check: cur === "h1", onClick: fb("h1") },
      { icon: "heading", label: Tr("تیتر"), check: cur === "h2", onClick: fb("h2") },
      { icon: "heading", label: Tr("زیرتیتر"), check: cur === "h3", onClick: fb("h3") },
      { icon: "quote", label: Tr("نقل‌قول"), check: cur === "blockquote", onClick: fb("blockquote") },
      { icon: "code", label: Tr("بلوک کد"), check: cur === "pre", onClick: () => setTimeout(() => { restore(); const pr = within(up("pre")); if (pr) preToDiv(pr); else makePre(); after(); }, 30) },
      { icon: "type", label: Tr("اندازه‌ی کوچک"), onClick: fs("2") },
      { icon: "type", label: Tr("اندازه‌ی معمولی"), onClick: fs("3") },
      { icon: "type", label: Tr("اندازه‌ی بزرگ"), onClick: fs("5") },
      { icon: "type", label: Tr("اندازه‌ی خیلی بزرگ"), onClick: fs("6") },
    ] });
  }

  function openLink() {
    const a = within(up("a")), s = sel();
    const hadSel = s.rangeCount && !s.isCollapsed;
    openSheet({
      title: Tr("لینک"),
      build(b, sh) {
        const inp = el("input", "field"); inp.type = "url"; inp.placeholder = "https://"; inp.dir = "ltr"; inp.inputMode = "url"; inp.autocapitalize = "off";
        inp.value = a ? a.getAttribute("href") || "" : "";
        const col = el("div", "btn-col");
        const ok = txt("button", "btn primary", Tr("ذخیره"));
        ok.onclick = () => {
          let u = inp.value.trim();
          if (!u) { sh.close(); return; }
          if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = "https://" + u;
          if (!/^(https?:|mailto:|tel:)/i.test(u)) { toast(Tr("آدرس معتبر نیست")); return; }
          sh.close();
          setTimeout(() => {
            if (a) { a.setAttribute("href", u); after(); }
            else if (hadSel) ex("createLink", u);
            else ex("insertHTML", `<a href="${esc(u)}">${esc(u)}</a>`);
          }, 30);
        };
        col.append(ok);
        if (a) {
          const op = txt("button", "btn", Tr("باز کردن لینک")); op.onclick = () => window.open(a.getAttribute("href"), "_blank");
          const rm = txt("button", "btn ghost-btn", Tr("حذف لینک"));
          rm.onclick = () => { sh.close(); setTimeout(() => { const r = document.createRange(); r.selectNodeContents(a); saved = r; ex("unlink"); }, 30); };
          col.append(op, rm);
        }
        b.append(inp, col);
        setTimeout(() => inp.focus(), 260);
      },
    });
  }

  /* ---------- ابزارهای متن ---------- */
  function mapText(d, fn) {
    const w = document.createTreeWalker(d, NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (w.nextNode()) nodes.push(w.currentNode);
    nodes.forEach((n) => { n.nodeValue = fn(n.nodeValue); });
  }
  function selectAll() { const r = document.createRange(); r.selectNodeContents(root); const s = sel(); s.removeAllRanges(); s.addRange(r); }
  function transform(fn, msg) {
    restore();
    const s = sel(), hasSel = s.rangeCount && !s.isCollapsed && inRoot(s.anchorNode);
    const d = document.createElement("div");
    if (hasSel) d.append(s.getRangeAt(0).cloneContents()); else { d.innerHTML = root.innerHTML; selectAll(); }
    fn(d);
    document.execCommand("insertHTML", false, d.innerHTML);
    after();
    toast(msg + (hasSel ? Tr(" (روی متن انتخاب‌شده)") : ""));
  }
  const linesHost = (d) => (d.children.length === 1 && /^(UL|OL)$/.test(d.firstElementChild.tagName) ? d.firstElementChild : d);
  function openTools() {
    saveNow();
    menuSheet({
      title: Tr("ابزارهای متن"), items: [
        { icon: "calendar", label: Tr("افزودن تاریخ شمسی"), sub: fmtDateFa(), onClick: () => setTimeout(() => ex("insertText", fmtDateFa()), 30) },
        { icon: "calendar", label: Tr("افزودن تاریخ میلادی"), sub: fmtDateEn(), onClick: () => setTimeout(() => ex("insertText", fmtDateEn()), 30) },
        { icon: "clock", label: Tr("افزودن ساعت"), sub: fmtTime(), onClick: () => setTimeout(() => ex("insertText", fmtTime()), 30) },
        { icon: "hr", label: Tr("خط جداکننده"), onClick: () => setTimeout(() => ex("insertHorizontalRule"), 30) },
        { icon: "swap", label: Tr("ارقام به فارسی"), onClick: () => setTimeout(() => transform((d) => mapText(d, toFaDigits), Tr("ارقام فارسی شد")), 30) },
        { icon: "swap", label: Tr("ارقام به انگلیسی"), onClick: () => setTimeout(() => transform((d) => mapText(d, toEnDigits), Tr("ارقام انگلیسی شد")), 30) },
        { icon: "type", label: Tr("اصلاح «ي» و «ك» عربی"), sub: Tr("به «ی» و «ک» فارسی"), onClick: () => setTimeout(() => transform((d) => mapText(d, fixArabicChars), Tr("حروف اصلاح شد")), 30) },
        { icon: "wand", label: Tr("پاک‌سازی فاصله‌ها و خطوط خالی"), onClick: () => setTimeout(() => transform((d) => {
          mapText(d, (t) => t.replace(/[ \t ]+/g, " "));
          const h = linesHost(d); let prevEmpty = true;
          [...h.children].forEach((c) => { const e = !c.textContent.trim() && !c.querySelector("hr"); if (e && prevEmpty) c.remove(); prevEmpty = e; });
          while (h.lastElementChild && !h.lastElementChild.textContent.trim() && !h.lastElementChild.querySelector("hr")) h.lastElementChild.remove();
        }, Tr("پاک‌سازی شد")), 30) },
        { icon: "sort", label: Tr("مرتب‌سازی الفبایی خطوط"), onClick: () => setTimeout(() => transform((d) => {
          const h = linesHost(d), items = [...h.children].sort((a, b) => a.textContent.localeCompare(b.textContent, "fa"));
          items.forEach((c) => h.append(c));
        }, Tr("مرتب شد")), 30) },
        { icon: "dup", label: Tr("حذف خطوط تکراری"), onClick: () => setTimeout(() => transform((d) => {
          const seen = new Set();
          [...linesHost(d).children].forEach((c) => { const k = c.textContent.trim(); if (!k) return; if (seen.has(k)) c.remove(); else seen.add(k); });
        }, Tr("تکراری‌ها حذف شد")), 30) },
        { icon: "search", label: Tr("جستجو و جایگزینی"), onClick: () => setTimeout(openReplace, 30) },
      ],
    });
  }
  function countIn(d, q) { let c = 0; const w = document.createTreeWalker(d, NodeFilter.SHOW_TEXT); while (w.nextNode()) c += w.currentNode.nodeValue.split(q).length - 1; return c; }
  function openReplace() {
    openSheet({
      title: Tr("جستجو و جایگزینی"),
      build(b, sh) {
        const f = el("input", "field"), r = el("input", "field"), info = txt("div", "hint-text", "");
        f.placeholder = Tr("عبارت جستجو"); r.placeholder = Tr("جایگزین (می‌تونه خالی باشه)"); f.dir = r.dir = "auto";
        f.oninput = () => { info.textContent = f.value ? Trt`${fa(countIn(root, f.value))} مورد پیدا شد` : ""; };
        const go = txt("button", "btn primary", Tr("جایگزینی همه"));
        go.onclick = () => {
          if (!f.value) return;
          const c = countIn(root, f.value);
          if (!c) { toast(Tr("چیزی پیدا نشد")); return; }
          sh.close();
          setTimeout(() => { selectAll(); const d = document.createElement("div"); d.innerHTML = root.innerHTML; mapText(d, (t) => t.split(f.value).join(r.value)); document.execCommand("insertHTML", false, d.innerHTML); after(); toast(Trt`${fa(c)} مورد جایگزین شد`); }, 30);
        };
        b.append(f, r, info, go);
        setTimeout(() => f.focus(), 260);
      },
    });
  }
  function saveNow() { const s = sel(); if (s.rangeCount && inRoot(s.anchorNode)) saved = s.getRangeAt(0).cloneRange(); }

  updateState();
  return {
    toolbar: tb,
    focus() {
      root.focus({ preventScroll: true });
      const r = document.createRange(); r.selectNodeContents(root); r.collapse(false);
      const s = sel(); s.removeAllRanges(); s.addRange(r);
    },
    flush: () => { if (touched) api.onChange(isBlank() ? "" : sanitize(root.innerHTML)); },
    text: () => root.innerText,
    openTools,
    destroy(save = true) {
      document.removeEventListener("selectionchange", onSel);
      if (raf) cancelAnimationFrame(raf);
      if (save && touched) api.onChange(isBlank() ? "" : sanitize(root.innerHTML));
      root.remove();
    },
  };
}
