// پل بین اپ و اندروید (Capacitor). اگه روی مرورگر باشیم همه‌چیز با جایگزین وب کار می‌کنه.
import { hash32 } from "./utils.js";
import { Tr } from "./i18n.js";

const C = window.Capacitor;
export const isNative = !!(C && C.isNativePlatform && C.isNativePlatform());
const P = (n) => (C && C.Plugins && C.Plugins[n]) || null;

export async function haptic(kind = "light") {
  if (window.__noHaptic) return;
  try {
    const H = P("Haptics");
    if (H) {
      if (kind === "success" || kind === "warning" || kind === "error") await H.notification({ type: kind.toUpperCase() });
      else await H.impact({ style: kind === "heavy" ? "HEAVY" : kind === "medium" ? "MEDIUM" : "LIGHT" });
    } else if (navigator.vibrate) navigator.vibrate(kind === "light" ? 8 : 16);
  } catch (e) {}
}

export async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch (e) {}
  try {
    const a = document.createElement("textarea"); a.value = t; a.style.cssText = "position:fixed;opacity:0";
    document.body.append(a); a.select(); const ok = document.execCommand("copy"); a.remove(); return ok;
  } catch (e) { return false; }
}

export async function shareText(title, text) {
  const S = P("Share");
  try {
    if (S) { await S.share({ title, text, dialogTitle: Tr("اشتراک‌گذاری") }); return "shared"; }
    if (navigator.share) { await navigator.share({ title, text }); return "shared"; }
  } catch (e) { if (e && /cancel|abort/i.test(String(e.message || e.name))) return "cancel"; }
  return (await copyText(text)) ? "copied" : "fail";
}

// ذخیره‌ی فایل و اشتراک‌گذاری (اندروید) یا دانلود (مرورگر)
export async function shareFile(name, content, mime = "text/plain") {
  const FS = P("Filesystem"), S = P("Share");
  if (FS && S) {
    try {
      await FS.writeFile({ path: name, data: content, directory: "CACHE", encoding: "utf8" });
      const u = await FS.getUri({ path: name, directory: "CACHE" });
      await S.share({ title: name, url: u.uri, dialogTitle: Tr("ذخیره یا ارسال فایل") });
      return true;
    } catch (e) { if (e && /cancel|abort/i.test(String(e.message || e))) return false; }
  }
  const url = URL.createObjectURL(new Blob([content], { type: mime + ";charset=utf-8" }));
  const a = document.createElement("a"); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 20000);
  return true;
}

export async function shareImage(name, dataUrl) {
  const FS = P("Filesystem"), S = P("Share");
  if (FS && S) {
    try {
      await FS.writeFile({ path: name, data: dataUrl.split(",")[1], directory: "CACHE" });
      const u = await FS.getUri({ path: name, directory: "CACHE" });
      await S.share({ title: name, url: u.uri, dialogTitle: Tr("ذخیره یا ارسال تصویر") });
      return true;
    } catch (e) { if (e && /cancel|abort/i.test(String(e.message || e))) return false; }
  }
  const a = document.createElement("a"); a.href = dataUrl; a.download = name; document.body.append(a); a.click(); a.remove();
  return true;
}

// نوار وضعیت و نوار ناوبری اندروید: برنامه لبه‌به‌لبه کشیده می‌شه و فاصله‌ی امن (inset) از سمت بومی میاد
export function initSystemBars() {
  const apply = (t, r, b, l) => {
    const st = document.documentElement.style;
    st.setProperty("--sat", t + "px"); st.setProperty("--sar", r + "px"); st.setProperty("--sab", b + "px"); st.setProperty("--sal", l + "px");
  };
  window.__insets = apply;
  const pull = () => {
    const B = window.GlassBars;
    if (B) { try { const v = String(B.insets()).split(",").map(Number); if (v.length === 4 && v.every(Number.isFinite)) apply(...v); } catch (e) {} }
  };
  pull();
  // اگه بار اول مقدار نرسید (ترتیب بالا اومدن صفحه)، چند بار دوباره می‌پرسیم
  [150, 500, 1200, 3000].forEach((t) => setTimeout(pull, t));
  window.addEventListener("resize", pull);
  document.addEventListener("visibilitychange", pull);
}
export function setSystemBars(lightTheme, bgHex) {
  const B = window.GlassBars;
  if (!B) return;
  try { B.setLight(!!lightTheme); } catch (e) {}
  // رنگ پشت نوارهای سیستم هم‌رنگ برنامه می‌شه تا هیچ نوار جدایی دیده نشه
  if (bgHex && /^#[0-9a-f]{6}$/i.test(bgHex)) { try { B.setBg(bgHex); } catch (e) {} }
}

export function onBackButton(cb) { const A = P("App"); if (A) A.addListener("backButton", cb); }
export function onAppActive(cb) { const A = P("App"); if (A) A.addListener("appStateChange", (s) => cb(!!s.isActive)); }
export function exitApp() { const A = P("App"); if (A && A.exitApp) A.exitApp(); }

/* ---------- یادآورها ---------- */
const LN = () => P("LocalNotifications");
export const notifId = (note) => hash32(note.id);

export async function initNotifications(onTap) {
  const L = LN();
  if (!L) return;
  try {
    await L.createChannel({ id: "reminders", name: Tr("یادآورها"), description: Tr("یادآوری یادداشت‌ها"), importance: 4, visibility: 1, vibration: true });
  } catch (e) {}
  try {
    L.addListener("localNotificationActionPerformed", (e) => {
      const id = e && e.notification && e.notification.extra && e.notification.extra.noteId;
      if (id) onTap(id);
    });
  } catch (e) {}
}

export async function ensureNotifPermission() {
  const L = LN();
  try {
    if (L) {
      const s = await L.checkPermissions();
      if (s.display === "granted") return true;
      const r = await L.requestPermissions();
      return r.display === "granted";
    }
    if ("Notification" in window) {
      if (Notification.permission === "granted") return true;
      return (await Notification.requestPermission()) === "granted";
    }
  } catch (e) {}
  return false;
}

export async function scheduleReminder(note, bodyText) {
  const L = LN();
  if (!L || !note.reminder) return;
  const r = note.reminder, at = new Date(r.at);
  if (at.getTime() <= Date.now() && r.repeat === "none") return;
  const schedule = { at, allowWhileIdle: true };
  if (r.repeat === "day" || r.repeat === "week") { schedule.repeats = true; schedule.every = r.repeat; }
  try {
    await L.cancel({ notifications: [{ id: notifId(note) }] });
    await L.schedule({ notifications: [{ id: notifId(note), title: Tr("یادآوری"), body: bodyText || Tr("یک یادداشت منتظر توئه"), schedule, channelId: "reminders", extra: { noteId: note.id } }] });
  } catch (e) { console.warn("schedule failed", e); }
}

export async function cancelReminder(note) {
  const L = LN();
  if (!L) return;
  try { await L.cancel({ notifications: [{ id: notifId(note) }] }); } catch (e) {}
}
