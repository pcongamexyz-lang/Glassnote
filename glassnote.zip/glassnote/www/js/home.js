// صفحه‌ی اصلی: نوار بالا، لیست یادداشت‌ها، دوک پایین
import { $, el, txt, icon, toast, fa, fmtWhen, fmtReminder, normalize, debounce } from "./utils.js";
import * as store from "./store.js";
import { openSheet, menuSheet, confirmDialog, promptDialog, closeTopSheet } from "./sheets.js";
import { openEditor } from "./editor.js";
import { thumb } from "./draw.js";
import { renderSettings } from "./settings.js";
import * as native from "./native.js";
import * as vault from "./crypto.js";
import { Tr, Trt } from "./i18n.js";

let anim = true; // انیمیشن ورود کارت‌ها فقط وقتی صفحه عوض می‌شه
export const ui = { view: "notes", label: null, filter: null, search: "", searching: false, sel: new Set(), dial: false };
const main = $("#main"), bar = $("#topbar"), dock = $("#dock"), dial = $("#dial"), dialScrim = $("#dial-scrim");

const TITLES = { notes: Tr("یادداشت‌ها"), archive: Tr("بایگانی"), trash: Tr("سطل زباله"), settings: Tr("تنظیمات") };

export function init() {
  store.subscribe(render);
  bindCards();
  dialScrim.onclick = () => setDial(false);
  render();
}

export function render() {
  renderBar();
  renderMain();
  renderDock();
  anim = false;
}

export function go(view) {
  anim = true;
  ui.view = view; ui.label = null; ui.filter = null; ui.search = ""; ui.searching = false; ui.sel.clear(); setDial(false);
  render();
  window.scrollTo(0, 0);
}

// برمی‌گرده true اگه چیزی بسته شد
export function handleBack() {
  if (ui.dial) { setDial(false); return true; }
  if (ui.sel.size) { ui.sel.clear(); render(); return true; }
  if (ui.searching) { ui.searching = false; ui.search = ""; render(); return true; }
  if (ui.view !== "notes" || ui.label || ui.filter) { go("notes"); return true; }
  return false;
}

/* ---------- باز کردن یادداشت (با پرسیدن رمز اگه قفل باشه) ---------- */
export async function openNote(id, opts = {}) {
  const note = store.getNote(id);
  if (!note) return;
  if (note.lock && !note._key) {
    native.haptic("light");
    const r = await promptDialog({ title: Tr("یادداشت قفل‌شده"), fields: [{ type: "password", placeholder: Tr("رمز") }], ok: Tr("باز کن") });
    if (!r) return;
    try {
      const { key, data } = await vault.unlock(note.lock, r[0]);
      note._key = key; note.title = data.title || ""; note.body = data.body || ""; note.items = data.items || [];
    } catch (e) { toast(e.message || Tr("باز نشد")); native.haptic("error"); return; }
  }
  openEditor(note, opts);
}

export function newNote(type) {
  const n = store.createNote(type);
  if (ui.label) n.labels = [ui.label];
  setDial(false);
  openEditor(n, { focus: true });
}

/* ---------- نوار بالا ---------- */
function renderBar() {
  bar.innerHTML = "";
  bar.classList.remove("selecting");
  if (ui.sel.size) return renderSelBar();
  if (ui.searching) {
    const b = el("button", "icon-btn", icon("back")); b.setAttribute("aria-label", Tr("بستن جستجو"));
    b.onclick = () => { ui.searching = false; ui.search = ""; render(); };
    const inp = el("input", "bar-search"); inp.placeholder = Tr("جستجو در یادداشت‌ها…"); inp.value = ui.search; inp.dir = "auto"; inp.type = "search"; inp.enterKeyHint = "search";
    const run = debounce(() => renderMain(), 120);
    inp.oninput = () => { ui.search = inp.value; run(); };
    bar.append(b, inp);
    setTimeout(() => inp.focus(), 30);
    return;
  }
  const title = ui.label ? store.labelName(ui.label) : TITLES[ui.view];
  bar.append(txt("div", "bar-title", title));
  if (ui.view === "settings") return;
  const actions = el("div", "bar-actions");
  const s = el("button", "icon-btn", icon("search")); s.setAttribute("aria-label", Tr("جستجو"));
  s.onclick = () => { ui.searching = true; render(); };
  const l = el("button", "icon-btn", icon(store.state.settings.layout === "grid" ? "list" : "grid")); l.setAttribute("aria-label", Tr("تغییر چیدمان"));
  l.onclick = () => { store.state.settings.layout = store.state.settings.layout === "grid" ? "list" : "grid"; store.saveSettings(); };
  const m = el("button", "icon-btn", icon("sort")); m.setAttribute("aria-label", Tr("مرتب‌سازی"));
  m.onclick = openSort;
  actions.append(s, l, m);
  bar.append(actions);
}

function openSort() {
  const cur = store.state.settings.sort;
  const set = (v) => () => { store.state.settings.sort = v; store.saveSettings(); };
  menuSheet({ title: Tr("مرتب‌سازی"), items: [
    { icon: "edit", label: Tr("آخرین ویرایش"), check: cur === "updated", onClick: set("updated") },
    { icon: "calendar", label: Tr("تاریخ ساخت"), check: cur === "created", onClick: set("created") },
    { icon: "type", label: Tr("عنوان (الفبایی)"), check: cur === "title", onClick: set("title") },
  ] });
}

function renderSelBar() {
  bar.classList.add("selecting");
  const x = el("button", "icon-btn", icon("x")); x.setAttribute("aria-label", Tr("لغو انتخاب"));
  x.onclick = () => { ui.sel.clear(); render(); };
  bar.append(x, txt("div", "bar-title sel-title", Trt`${fa(ui.sel.size)} انتخاب`));
  const a = el("div", "bar-actions");
  const mk = (ic, label, fn) => { const b = el("button", "icon-btn", icon(ic)); b.setAttribute("aria-label", label); b.onclick = fn; a.append(b); };
  const notes = [...ui.sel].map(store.getNote).filter(Boolean);
  if (ui.view === "trash") {
    mk("restore", Tr("بازیابی"), () => bulk(notes, (n) => { n.trashedAt = null; }, Tr("بازیابی شد")));
    mk("trash", Tr("حذف دائمی"), async () => {
      if (await confirmDialog({ title: Tr("حذف دائمی؟"), message: Trt`${fa(notes.length)} یادداشت برای همیشه پاک می‌شه.`, ok: Tr("حذف"), danger: true })) {
        notes.forEach((n) => { native.cancelReminder(n); store.state.notes = store.state.notes.filter((x) => x !== n); });
        ui.sel.clear(); store.save(); store.emit(); toast(Tr("حذف شد"));
      }
    });
  } else {
    const allPinned = notes.every((n) => n.pinned);
    mk("pin", allPinned ? Tr("برداشتن سنجاق") : Tr("سنجاق"), () => bulk(notes, (n) => { n.pinned = !allPinned; }, allPinned ? Tr("سنجاق برداشته شد") : Tr("سنجاق شد")));
    mk("palette", Tr("رنگ"), () => bulkColor(notes));
    mk("archive", ui.view === "archive" ? Tr("خروج از بایگانی") : Tr("بایگانی"), () => bulk(notes, (n) => { n.archived = ui.view !== "archive"; if (n.archived) n.pinned = false; }, ui.view === "archive" ? Tr("از بایگانی بیرون اومد") : Tr("بایگانی شد")));
    mk("trash", Tr("سطل زباله"), () => bulk(notes, (n) => { n.trashedAt = Date.now(); n.pinned = false; native.cancelReminder(n); }, Tr("به سطل زباله رفت")));
  }
  bar.append(a);
}

function bulk(notes, fn, msg) {
  const prev = notes.map((n) => ({ n, s: { pinned: n.pinned, archived: n.archived, trashedAt: n.trashedAt, color: n.color } }));
  notes.forEach((n) => { fn(n); n.updated = Date.now(); });
  ui.sel.clear(); store.save(); store.emit();
  native.haptic("light");
  toast(msg, { action: Tr("بازگردانی"), onAction: () => { prev.forEach(({ n, s }) => Object.assign(n, s)); store.save(); store.emit(); } });
}
function bulkColor(notes) {
  openSheet({ title: Tr("رنگ"), build(b, api) {
    const sw = el("div", "swatches");
    for (let c = 0; c < store.COLORS; c++) {
      const s = el("button", "sw" + (c === 0 ? " none" : ""), c === 0 ? icon("x") : ""); if (c) s.style.background = `var(--c${c})`;
      s.onclick = () => { notes.forEach((n) => { n.color = c; }); ui.sel.clear(); store.save(); store.emit(); api.close(); };
      sw.append(s);
    }
    b.append(sw);
  } });
}

/* ---------- محتوا ---------- */
function renderMain() {
  main.innerHTML = "";
  main.className = "";
  if (ui.view === "settings") { renderSettings(main); return; }
  renderChips();

  const list = store.query({ view: ui.view, label: ui.label, filter: ui.filter, search: ui.search });
  if (ui.view === "trash") {
    const info = el("div", "note-info", icon("info") + Tr("<span>یادداشت‌های سطل زباله بعد از ۳۰ روز برای همیشه پاک می‌شن.</span>"));
    main.append(info);
    if (list.length) {
      const b = txt("button", "btn small danger-soft", Tr("خالی کردن سطل زباله"));
      b.onclick = async () => {
        if (await confirmDialog({ title: Tr("خالی کردن سطل زباله؟"), message: Tr("این کار قابل بازگشت نیست."), ok: Tr("خالی کن"), danger: true })) {
          store.wipeTrash().forEach((n) => native.cancelReminder(n)); toast(Tr("سطل زباله خالی شد"));
        }
      };
      main.append(b);
    }
  }
  if (!list.length) { main.append(emptyState()); return; }

  const showSections = ui.view === "notes" && !ui.search && list.some((n) => n.pinned) && list.some((n) => !n.pinned);
  if (showSections) {
    main.append(txt("div", "section-label", Tr("سنجاق‌شده")), cards(list.filter((n) => n.pinned)));
    main.append(txt("div", "section-label", Tr("بقیه")), cards(list.filter((n) => !n.pinned)));
  } else main.append(cards(list));
}

function renderChips() {
  const row = el("div", "chips scroll");
  const mk = (label, active, fn, ic) => {
    const c = el("button", "chip" + (active ? " on" : ""), ic ? icon(ic) : "");
    c.append(txt("span", "", label)); c.onclick = fn; row.append(c);
  };
  mk(Tr("همه"), !ui.label && !ui.filter, () => { ui.label = null; ui.filter = null; render(); });
  store.state.labels.forEach((l) => mk(l.name, ui.label === l.id, () => { ui.label = ui.label === l.id ? null : l.id; ui.filter = null; render(); }, "tag"));
  const live = store.state.notes.filter((n) => !n.trashedAt && (ui.view === "archive" ? n.archived : !n.archived));
  if (live.some((n) => n.reminder)) mk(Tr("یادآور"), ui.filter === "reminder", () => { ui.filter = ui.filter === "reminder" ? null : "reminder"; ui.label = null; render(); }, "bell");
  if (live.some((n) => n.type === "list")) mk(Tr("چک‌لیست"), ui.filter === "list", () => { ui.filter = ui.filter === "list" ? null : "list"; ui.label = null; render(); }, "checklist");
  if (live.some((n) => n.type === "draw")) mk(Tr("نقاشی"), ui.filter === "draw", () => { ui.filter = ui.filter === "draw" ? null : "draw"; ui.label = null; render(); }, "pencil");
  if (live.some((n) => n.lock)) mk(Tr("قفل‌شده"), ui.filter === "locked", () => { ui.filter = ui.filter === "locked" ? null : "locked"; ui.label = null; render(); }, "lock");
  if (row.children.length > 1) main.append(row);
}

function emptyState() {
  const e = el("div", "empty");
  const msgs = {
    notes: ["note", ui.search ? Tr("چیزی پیدا نشد") : Tr("هنوز یادداشتی نداری"), ui.search ? Tr("عبارت دیگه‌ای امتحان کن") : Tr("با دکمه‌ی + اولین یادداشتت رو بساز")],
    archive: ["archive", Tr("بایگانی خالیه"), Tr("یادداشت‌هایی که فعلاً لازمشون نداری اینجا می‌شینن")],
    trash: ["trash", Tr("سطل زباله خالیه"), ""],
  };
  const [ic, t, s] = msgs[ui.view] || msgs.notes;
  e.innerHTML = `<div class="empty-ic">${icon(ic)}</div>`;
  e.append(txt("b", "", t));
  if (s) e.append(txt("p", "", s));
  return e;
}

function cards(list) {
  const wrap = el("div", "cards " + (store.state.settings.layout === "list" ? "as-list" : "as-grid"));
  list.forEach((n, i) => {
    const c = card(n);
    if (anim && i < 12) { c.classList.add("in"); c.style.setProperty("--i", i); }
    wrap.append(c);
  });
  return wrap;
}

function card(n) {
  const c = el("article", "card c" + n.color + (ui.sel.has(n.id) ? " sel" : ""));
  c.dataset.id = n.id;
  c.tabIndex = 0;
  if (n.pinned && ui.view === "notes") c.append(el("span", "card-pin", icon("pin")));
  c.append(el("span", "card-check", icon("check")));
  if (n.lock && !n._key) {
    c.append(el("div", "card-lock", icon("lock") + Tr("<span>یادداشت قفل‌شده</span>")));
  } else {
    if (n.title.trim()) c.append(txt("h3", "card-title", n.title));
    if (n.type === "draw") {
      const t = thumb(n);
      if (t) { const im = el("img", "card-draw"); im.src = t.url; im.width = t.w; im.height = t.h; im.alt = ""; im.decoding = "async"; c.append(im); }
    } else if (n.type === "list") {
      const items = store.preview(n);
      const box = el("div", "card-items");
      items.slice(0, 6).forEach((it) => { const r = el("div", "ci" + (it.done ? " done" : ""), `<span class="cb mini">${it.done ? icon("check") : ""}</span>`); r.append(txt("span", "", it.text)); box.append(r); });
      if (items.length > 6) box.append(txt("div", "card-more", Trt`+${fa(items.length - 6)} مورد دیگه`));
      if (items.length) c.append(box);
    } else if (store.plain(n).trim()) {
      c.append(txt("p", "card-body", store.plain(n).trim().slice(0, 420)));
    }
    if (!n.title.trim() && !(n.type === "list" ? n.items.some((i) => i.text.trim()) : n.type === "draw" ? n.body : store.plain(n).trim())) c.append(txt("p", "card-body hint-text", Tr("خالی")));
  }
  const meta = el("div", "card-meta");
  n.labels.slice(0, 2).forEach((id) => { const nm = store.labelName(id); if (nm) meta.append(txt("span", "tagchip", nm)); });
  if (n.labels.length > 2) meta.append(txt("span", "tagchip", `+${fa(n.labels.length - 2)}`));
  if (n.reminder) { const over = n.reminder.at < Date.now() && n.reminder.repeat === "none"; const r = el("span", "tagchip rem" + (over ? " warn" : ""), icon("bell")); r.append(txt("span", "", fmtReminder(n.reminder.at))); meta.append(r); }
  if (n.lock && n._key) meta.append(el("span", "tagchip", icon("lock")));
  if (ui.view === "trash" && n.trashedAt) meta.append(txt("span", "tagchip", Trt`${fa(Math.max(0, 30 - Math.floor((Date.now() - n.trashedAt) / 86400000)))} روز مونده`));
  if (meta.children.length) c.append(meta);
  return c;
}

/* ---------- تعامل کارت‌ها ---------- */
function bindCards() {
  let timer = null, fired = false, sx = 0, sy = 0;
  const stop = () => { clearTimeout(timer); timer = null; };
  main.addEventListener("pointerdown", (e) => {
    const c = e.target.closest(".card");
    if (!c) return;
    fired = false; sx = e.clientX; sy = e.clientY;
    timer = setTimeout(() => { fired = true; toggleSel(c.dataset.id); native.haptic("medium"); }, 450);
  });
  main.addEventListener("pointermove", (e) => { if (timer && (Math.abs(e.clientX - sx) > 8 || Math.abs(e.clientY - sy) > 8)) stop(); });
  ["pointerup", "pointercancel", "pointerleave"].forEach((t) => main.addEventListener(t, stop));
  main.addEventListener("contextmenu", (e) => { if (e.target.closest(".card")) e.preventDefault(); });
  main.addEventListener("click", (e) => {
    const c = e.target.closest(".card");
    if (!c) return;
    if (fired) { fired = false; return; }
    const id = c.dataset.id;
    if (ui.sel.size) return toggleSel(id);
    onTap(id);
  });
  main.addEventListener("keydown", (e) => { if (e.key === "Enter" && e.target.classList.contains("card")) onTap(e.target.dataset.id); });
}
function toggleSel(id) { ui.sel.has(id) ? ui.sel.delete(id) : ui.sel.add(id); render(); }
function onTap(id) {
  const n = store.getNote(id);
  if (!n) return;
  if (n.trashedAt) {
    menuSheet({ title: Tr("یادداشت حذف‌شده"), items: [
      { icon: "restore", label: Tr("بازیابی"), onClick: () => { n.trashedAt = null; store.commit(n); toast(Tr("بازیابی شد")); } },
      { icon: "trash", label: Tr("حذف دائمی"), danger: true, onClick: () => { native.cancelReminder(n); store.removeNote(n); toast(Tr("حذف شد")); } },
    ] });
    return;
  }
  openNote(id);
}

/* ---------- دوک پایین ---------- */
let lens = null, lensIdx = -1;
function renderDock() {
  if (!lens) { lens = el("span", "dock-lens"); }
  [...dock.children].forEach((c) => { if (c !== lens) c.remove(); });
  dock.classList.toggle("hide", ui.sel.size > 0 || ui.searching);
  const mk = (view, ic, label) => {
    const b = el("button", "nav" + (ui.view === view ? " on" : ""), `<span class="nav-ic">${icon(ic)}</span><span class="nav-l">${label}</span>`);
    b.setAttribute("aria-label", label); b.dataset.view = view;
    b.onclick = () => { native.haptic("light"); go(view); };
    return b;
  };
  const fab = el("button", "fab" + (ui.dial ? " open" : ""), icon("plus"));
  fab.setAttribute("aria-label", Tr("یادداشت جدید"));
  fab.onclick = () => { native.haptic("light"); setDial(!ui.dial); };
  dock.append(lens, mk("notes", "note", Tr("یادداشت‌ها")), mk("archive", "archive", Tr("بایگانی")), fab, mk("trash", "trash", Tr("سطل")), mk("settings", "settings", Tr("تنظیمات")));
  placeLens();
}
// نشانگر شیشه‌ای که مثل iOS 26 بین زبانه‌ها می‌لغزه
function placeLens() {
  const on = dock.querySelector(".nav.on");
  if (!on || !lens) { if (lens) lens.style.opacity = 0; return; }
  const idx = [...dock.querySelectorAll(".nav")].indexOf(on);
  const x = on.offsetLeft + on.offsetWidth / 2 - lens.offsetWidth / 2, first = lensIdx < 0;
  if (first) lens.style.transition = "none";
  lens.style.opacity = 1;
  lens.style.transform = `translate3d(${x}px,0,0)`;
  if (first) { void lens.offsetWidth; lens.style.transition = ""; }
  else if (idx !== lensIdx) { lens.classList.remove("go"); void lens.offsetWidth; lens.classList.add("go"); }
  lensIdx = idx;
}
window.addEventListener("resize", () => { lensIdx = -2; placeLens(); });

function setDial(on) {
  ui.dial = on;
  dial.hidden = !on; dialScrim.hidden = !on;
  const f = $(".fab", dock); if (f) f.classList.toggle("open", on);
  if (on) {
    dial.innerHTML = "";
    const a = el("button", "dial-btn glass", icon("checklist") + Tr("<span>چک‌لیست</span>")), b = el("button", "dial-btn glass", icon("note") + Tr("<span>یادداشت</span>")), d = el("button", "dial-btn glass", icon("pencil") + Tr("<span>نقاشی</span>"));
    a.onclick = () => newNote("list"); b.onclick = () => newNote("text"); d.onclick = () => newNote("draw");
    dial.append(a, b, d);
  }
}
