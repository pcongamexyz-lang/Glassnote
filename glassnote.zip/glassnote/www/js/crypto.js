import { Tr } from "./i18n.js";
// رمزگذاری یادداشت‌های قفل‌شده (AES-GCM با کلید PBKDF2) و قفل برنامه (PIN)
const enc = new TextEncoder(), dec = new TextDecoder();
const subtle = () => {
  if (!window.crypto || !crypto.subtle) throw new Error(Tr("رمزنگاری روی این دستگاه در دسترس نیست"));
  return crypto.subtle;
};
const b64 = (buf) => { let s = ""; new Uint8Array(buf).forEach((b) => (s += String.fromCharCode(b))); return btoa(s); };
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const ITER = 150000;

export const randomSalt = () => crypto.getRandomValues(new Uint8Array(16));

export async function deriveKey(password, salt) {
  const base = await subtle().importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveKey"]);
  return subtle().deriveKey({ name: "PBKDF2", salt, iterations: ITER, hash: "SHA-256" }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}

// رمز جدید: salt و کلید می‌سازه
export async function newLock(password) {
  const salt = randomSalt();
  return { key: await deriveKey(password, salt), salt: b64(salt) };
}

export async function encryptWith(key, saltB64, obj) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await subtle().encrypt({ name: "AES-GCM", iv }, key, enc.encode(JSON.stringify(obj)));
  return { v: 1, salt: saltB64, iv: b64(iv), ct: b64(ct) };
}

// با رمز باز می‌کنه؛ اگه رمز غلط باشه خطا می‌ده
export async function unlock(lock, password) {
  const key = await deriveKey(password, unb64(lock.salt));
  try {
    const pt = await subtle().decrypt({ name: "AES-GCM", iv: unb64(lock.iv) }, key, unb64(lock.ct));
    return { key, data: JSON.parse(dec.decode(pt)) };
  } catch (e) {
    throw new Error(Tr("رمز اشتباهه"));
  }
}

/* ---------- PIN برنامه ---------- */
async function pinHash(pin, salt) {
  const base = await subtle().importKey("raw", enc.encode(pin), "PBKDF2", false, ["deriveBits"]);
  return b64(await subtle().deriveBits({ name: "PBKDF2", salt, iterations: ITER, hash: "SHA-256" }, base, 256));
}
export async function makePin(pin) {
  const salt = randomSalt();
  return { salt: b64(salt), hash: await pinHash(pin, salt) };
}
export async function checkPin(pin, rec) {
  return (await pinHash(pin, unb64(rec.salt))) === rec.hash;
}
