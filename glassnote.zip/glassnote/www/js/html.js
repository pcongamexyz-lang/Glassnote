// ابزارهای HTML یادداشت: پاک‌سازی امن، تبدیل به متن/مارک‌داون و برعکس
import { renderMarkdown } from "./md.js";
import { esc } from "./utils.js";

const ALLOW = new Set(["B", "I", "U", "S", "MARK", "SUB", "SUP", "CODE", "PRE", "H1", "H2", "H3", "P", "DIV", "BR", "UL", "OL", "LI", "BLOCKQUOTE", "A", "HR", "SPAN"]);
const DROP = new Set(["SCRIPT", "STYLE", "IFRAME", "OBJECT", "EMBED", "LINK", "META", "SVG", "MATH", "TEMPLATE", "NOSCRIPT", "TEXTAREA", "SELECT", "BUTTON", "INPUT", "FORM", "IMG", "VIDEO", "AUDIO", "CANVAS", "HEAD", "TITLE"]);
const MAP = { STRONG: "B", EM: "I", STRIKE: "S", DEL: "S", INS: "U", H4: "H3", H5: "H3", H6: "H3" };
const BLOCKS = new Set(["P", "DIV", "H1", "H2", "H3", "LI", "UL", "OL", "BLOCKQUOTE", "PRE", "HR"]);
const CLASSES = new Set(["todo", "done", "fs-sm", "fs-lg", "fs-xl"]);
const SIZE_CLASS = { 1: "fs-sm", 2: "fs-sm", 4: "fs-lg", 5: "fs-lg", 6: "fs-xl", 7: "fs-xl" };
const okColor = (v) => /^(#[0-9a-f]{3,8}|rgba?\(\s*[\d.]+\s*,\s*[\d.]+\s*,\s*[\d.]+\s*(,\s*[\d.]+\s*)?\)|[a-z]{3,20})$/i.test((v || "").trim()) && !/^(inherit|initial|unset|currentcolor|transparent)$/i.test(v.trim());
const isBlock = (n) => n.nodeType === 1 && BLOCKS.has(n.tagName);

function parseBody(html) {
  return new DOMParser().parseFromString("<body>" + (html || "") + "</body>", "text/html").body;
}

// اگه استایل‌های پررنگ/کج/زیرخط‌دار باشن (از چسباندن از جاهای دیگه)، به تگ‌های خودمون تبدیلشون می‌کنیم
function wrapStyles(c, e) {
  const st = c.style;
  if (!st) return e;
  let inner = e;
  const add = (tag) => { const t = document.createElement(tag); inner.append(t); inner = t; };
  const fw = st.fontWeight;
  if (fw === "bold" || fw === "bolder" || +fw >= 600) add("b");
  if (st.fontStyle === "italic") add("i");
  const td = st.textDecorationLine || st.textDecoration || "";
  if (/underline/.test(td)) add("u");
  if (/line-through/.test(td)) add("s");
  return inner;
}

function walk(from, to) {
  for (const c of [...from.childNodes]) {
    if (c.nodeType === 3) { to.append(document.createTextNode(c.nodeValue)); continue; }
    if (c.nodeType !== 1) continue;
    let tag = c.tagName;
    if (DROP.has(tag)) continue;
    if (tag === "FONT") {
      const sp = document.createElement("span");
      const col = c.getAttribute("color"); if (col && okColor(col)) sp.style.color = col;
      const cl = SIZE_CLASS[c.getAttribute("size")]; if (cl) sp.className = cl;
      walk(c, sp); to.append(sp); continue;
    }
    tag = MAP[tag] || tag;
    if (!ALLOW.has(tag)) { walk(c, to); continue; }
    const e = document.createElement(tag);
    if (tag === "A") {
      const h = (c.getAttribute("href") || "").trim();
      if (/^(https?:|mailto:|tel:)/i.test(h)) { e.setAttribute("href", h); e.setAttribute("rel", "noopener noreferrer"); e.setAttribute("target", "_blank"); }
    }
    const st = c.style;
    if (st) {
      if (st.color && okColor(st.color)) e.style.color = st.color;
      if (st.backgroundColor && okColor(st.backgroundColor)) e.style.backgroundColor = st.backgroundColor;
      if (BLOCKS.has(tag) && /^(left|right|center|justify)$/.test(st.textAlign)) e.style.textAlign = st.textAlign;
    }
    if (BLOCKS.has(tag) || tag === "SPAN") {
      const d = c.getAttribute("dir"); if (d && /^(rtl|ltr|auto)$/.test(d)) e.setAttribute("dir", d);
    }
    const cls = (c.getAttribute("class") || "").split(/\s+/).filter((x) => CLASSES.has(x));
    if (cls.length) e.className = cls.join(" ");
    if (!e.getAttribute("style")) e.removeAttribute("style");
    const target = tag === "SPAN" || tag === "DIV" || tag === "P" || tag === "LI" ? wrapStyles(c, e) : e;
    walk(c, target);
    // spanهای خالی و بی‌استایل رو باز می‌کنیم
    if (tag === "SPAN" && !e.getAttribute("style") && !e.className && !e.getAttribute("dir")) { while (e.firstChild) to.append(e.firstChild); }
    else to.append(e);
  }
}

// متن‌های بدون بلوک رو داخل div می‌ذاره تا هر خط جهت خودش رو داشته باشه
export function wrapLoose(root) {
  let run = null;
  for (const c of [...root.childNodes]) {
    if (isBlock(c)) { run = null; continue; }
    if (c.nodeType === 3 && !c.nodeValue.trim() && !run) { c.remove(); continue; }
    if (!run) { run = document.createElement("div"); root.insertBefore(run, c); }
    run.append(c);
  }
}
export function addDirs(root) {
  root.querySelectorAll("div,p,li,h1,h2,h3,blockquote,pre,ul,ol").forEach((e) => { if (!e.hasAttribute("dir")) e.setAttribute("dir", "auto"); });
}

export function sanitize(html) {
  const src = parseBody(html), dst = document.createElement("div");
  walk(src, dst);
  wrapLoose(dst);
  addDirs(dst);
  return dst.innerHTML;
}

/* ---------- HTML ← متن ساده / مارک‌داون ---------- */
export function textToHtml(text) {
  return String(text || "").split("\n").map((l) => (l.trim() ? `<div dir="auto">${esc(l)}</div>` : '<div dir="auto"><br></div>')).join("");
}
export function mdToHtml(md) {
  if (!md || !md.trim()) return "";
  const body = parseBody(renderMarkdown(md));
  body.querySelectorAll("ul.tasks").forEach((ul) => { ul.className = "todo"; ul.querySelectorAll(".box").forEach((b) => b.remove()); });
  return sanitize(body.innerHTML);
}

/* ---------- متن ساده و مارک‌داون ← HTML ---------- */
function kids(n, md, ctx) {
  let acc = "";
  for (const c of n.childNodes) {
    const s = R(c, md, ctx);
    if (isBlock(c) && acc && !acc.endsWith("\n")) acc += "\n";
    acc += s;
  }
  return acc;
}
const nlEnd = (s) => (s.endsWith("\n") ? s : s + "\n");
function R(n, md, ctx) {
  if (n.nodeType === 3) return n.nodeValue.replace(/ /g, " ");
  if (n.nodeType !== 1) return "";
  const t = n.tagName;
  if (t === "BR") return "\n";
  if (t === "HR") return "\n---\n";
  if (t === "UL" || t === "OL") {
    let i = 0, out = "";
    const todo = n.classList.contains("todo");
    for (const li of n.children) {
      if (li.tagName !== "LI") continue;
      i++;
      const prefix = todo ? (li.classList.contains("done") ? "- [x] " : "- [ ] ") : t === "OL" ? i + ". " : "- ";
      out += prefix + kids(li, md, ctx).replace(/\n+$/, "").replace(/\n/g, "\n  ") + "\n";
    }
    return out;
  }
  const inner = kids(n, md, ctx);
  if (md) {
    const wrapM = (m) => (inner.trim() ? m + inner + m : inner);
    if (t === "B") return wrapM("**");
    if (t === "I") return wrapM("*");
    if (t === "S") return wrapM("~~");
    if (t === "CODE") return wrapM("`");
    if (t === "A") return n.getAttribute("href") ? `[${inner}](${n.getAttribute("href")})` : inner;
    if (t === "H1" || t === "H2" || t === "H3") return nlEnd("#".repeat(+t[1]) + " " + inner.trim());
    if (t === "BLOCKQUOTE") return nlEnd(nlEnd(inner).replace(/^(?=.)/gm, "> "));
    if (t === "PRE") return "```\n" + nlEnd(inner) + "```\n";
  }
  if (BLOCKS.has(t)) return nlEnd(inner);
  return inner;
}
export function htmlToText(html) {
  if (!html) return "";
  return kids(parseBody(html), false, {}).replace(/\n+$/, "");
}
export function htmlToMd(html) {
  if (!html) return "";
  return kids(parseBody(html), true, {}).replace(/\n{3,}/g, "\n\n").replace(/\n+$/, "");
}
