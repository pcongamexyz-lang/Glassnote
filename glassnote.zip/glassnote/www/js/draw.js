// نقاشی: بوم برداری. به‌جای پیکسل، خط‌ها (stroke) ذخیره می‌شن؛ پس کم‌حجمه و با هر اندازه‌ی صفحه‌ای شفافه.
import { el, icon } from "./utils.js";
import { Tr } from "./i18n.js";

export const W = 1000;               // عرض منطقی صفحه (واحد)
const MIN_H = 1800, MAX_H = 9000;
const TOOLS = {
  pencil: { w: 3.2, a: 0.82, cap: "round" },
  pen: { w: 5, a: 1, cap: "round" },
  marker: { w: 15, a: 1, cap: "round" },
  hl: { w: 36, a: 0.38, cap: "butt" },
};
const ORDER = ["pencil", "pen", "marker", "hl", "eraser"];
const SIZE_F = [0.6, 1, 1.8];
const ERASE_R = [8, 14, 24]; // px
export const PALETTE = ["ink", "#E5484D", "#F2994A", "#F5C518", "#30A46C", "#2F7CF6", "#8E4EC6", "#E93D82"];
export const PAPERS = ["plain", "grid", "lines", "dots"];

/* ---------- ترجیحات ---------- */
const PREF_KEY = "gn.draw.v1";
const defaults = () => ({ tool: "pen", pencil: { c: "ink", s: 1 }, pen: { c: "ink", s: 1 }, marker: { c: "#E5484D", s: 1 }, hl: { c: "#F5C518", s: 1 }, eraser: { s: 1 } });
function loadPrefs() {
  const d = defaults();
  try {
    const p = JSON.parse(localStorage.getItem(PREF_KEY) || "{}");
    for (const k of Object.keys(d)) if (p[k] !== undefined) d[k] = k === "tool" ? (ORDER.includes(p[k]) ? p[k] : "pen") : { ...d[k], ...p[k] };
  } catch (e) {}
  return d;
}
const savePrefs = (p) => { try { localStorage.setItem(PREF_KEY, JSON.stringify(p)); } catch (e) {} };

/* ---------- سند ---------- */
const validStroke = (s) => s && TOOLS[s.t] && Array.isArray(s.p) && s.p.length >= 2 && s.p.length % 2 === 0 && typeof s.w === "number";
export function parse(body) {
  try {
    const d = JSON.parse(body);
    if (d && Array.isArray(d.s)) return { h: Math.min(MAX_H, Math.max(MIN_H, +d.h || MIN_H)), s: d.s.filter(validStroke) };
  } catch (e) {}
  return { h: MIN_H, s: [] };
}
export const stringify = (doc) => (doc.s.length ? JSON.stringify({ v: 1, h: doc.h, s: doc.s }) : "");
const r1 = (v) => Math.round(v * 10) / 10;

const BB = new WeakMap();
function bb(s) {
  let b = BB.get(s);
  if (b) return b;
  const p = s.p, h = s.w / 2 + 1;
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (let i = 0; i < p.length; i += 2) { const x = p[i], y = p[i + 1]; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  b = [x0 - h, y0 - h, x1 + h, y1 + h];
  BB.set(s, b);
  return b;
}

// ساده‌سازی مسیر (Ramer–Douglas–Peucker) تا حجم ذخیره کم بشه
function simplify(p, eps) {
  const n = p.length >> 1;
  if (n < 3) return p;
  const keep = new Uint8Array(n); keep[0] = keep[n - 1] = 1;
  const st = [[0, n - 1]];
  while (st.length) {
    const [a, b] = st.pop();
    const ax = p[2 * a], ay = p[2 * a + 1], dx = p[2 * b] - ax, dy = p[2 * b + 1] - ay, L = dx * dx + dy * dy;
    let md = 0, mi = -1;
    for (let i = a + 1; i < b; i++) {
      const px = p[2 * i], py = p[2 * i + 1];
      let d;
      if (!L) d = Math.hypot(px - ax, py - ay);
      else { let t = ((px - ax) * dx + (py - ay) * dy) / L; t = t < 0 ? 0 : t > 1 ? 1 : t; d = Math.hypot(px - (ax + t * dx), py - (ay + t * dy)); }
      if (d > md) { md = d; mi = i; }
    }
    if (mi > 0 && md > eps) { keep[mi] = 1; st.push([a, mi], [mi, b]); }
  }
  const out = [];
  for (let i = 0; i < n; i++) if (keep[i]) out.push(p[2 * i], p[2 * i + 1]);
  return out;
}

function hits(s, x, y, r) {
  const b = bb(s);
  if (x < b[0] - r || x > b[2] + r || y < b[1] - r || y > b[3] + r) return false;
  const p = s.p, rr = r + s.w / 2;
  if (p.length === 2) return Math.hypot(p[0] - x, p[1] - y) <= rr;
  for (let i = 0; i < p.length - 2; i += 2) {
    const ax = p[i], ay = p[i + 1], dx = p[i + 2] - ax, dy = p[i + 3] - ay, L = dx * dx + dy * dy;
    let t = L ? ((x - ax) * dx + (y - ay) * dy) / L : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    if (Math.hypot(x - (ax + t * dx), y - (ay + t * dy)) <= rr) return true;
  }
  return false;
}

/* ---------- رسم ---------- */
const cssVar = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const inkNow = () => cssVar("--text") || "#1d1f23";

// ctx باید از قبل scale شده باشه تا هر واحد = یک واحد منطقی
function stroke(ctx, s, ink, minW) {
  const t = TOOLS[s.t], p = s.p, n = p.length >> 1;
  ctx.globalAlpha = t.a;
  ctx.strokeStyle = ctx.fillStyle = s.c === "ink" ? ink : s.c;
  ctx.lineWidth = Math.max(s.w, minW);
  ctx.lineCap = t.cap; ctx.lineJoin = "round";
  ctx.beginPath();
  if (n === 1) { ctx.arc(p[0], p[1], ctx.lineWidth / 2, 0, 6.2832); ctx.fill(); return; }
  ctx.moveTo(p[0], p[1]);
  if (n === 2) ctx.lineTo(p[2], p[3]);
  else {
    for (let i = 1; i < n - 1; i++) ctx.quadraticCurveTo(p[2 * i], p[2 * i + 1], (p[2 * i] + p[2 * i + 2]) / 2, (p[2 * i + 1] + p[2 * i + 3]) / 2);
    ctx.lineTo(p[2 * n - 2], p[2 * n - 1]);
  }
  ctx.stroke();
}
function paint(ctx, strokes, ink, minW) { for (const s of strokes) stroke(ctx, s, ink, minW); ctx.globalAlpha = 1; }

function paperLines(ctx, kind, w, h) {
  if (kind === "plain") return;
  ctx.save();
  ctx.strokeStyle = "rgba(128,128,128,.28)"; ctx.fillStyle = "rgba(128,128,128,.45)"; ctx.lineWidth = 1.2;
  ctx.beginPath();
  if (kind === "grid") { for (let x = 50; x < w; x += 50) { ctx.moveTo(x, 0); ctx.lineTo(x, h); } for (let y = 50; y < h; y += 50) { ctx.moveTo(0, y); ctx.lineTo(w, y); } ctx.stroke(); }
  else if (kind === "lines") { for (let y = 60; y < h; y += 60) { ctx.moveTo(0, y); ctx.lineTo(w, y); } ctx.stroke(); }
  else for (let y = 25; y < h; y += 50) for (let x = 25; x < w; x += 50) { ctx.beginPath(); ctx.arc(x, y, 2.2, 0, 6.2832); ctx.fill(); }
  ctx.restore();
}

/* ---------- تصویر کوچک برای کارت‌ها ---------- */
const tcache = new Map();
export function thumb(note) {
  const doc = parse(note.body);
  if (!doc.s.length) return null;
  const key = note.id + "|" + note.updated + "|" + document.documentElement.dataset.mode + "|" + note.body.length;
  if (tcache.has(key)) return tcache.get(key);
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const s of doc.s) { const b = bb(s); if (b[0] < x0) x0 = b[0]; if (b[1] < y0) y0 = b[1]; if (b[2] > x1) x1 = b[2]; if (b[3] > y1) y1 = b[3]; }
  x0 = Math.max(0, x0 - 24); y0 = Math.max(0, y0 - 24); x1 = Math.min(W, x1 + 24); y1 += 24;
  const rw = Math.max(x1 - x0, 160), rh = Math.max(y1 - y0, 100);
  const sc = Math.min(360 / rw, 260 / rh);
  const cw = Math.max(1, Math.ceil(rw * sc)), ch = Math.max(1, Math.ceil(rh * sc));
  const c = document.createElement("canvas"); c.width = cw; c.height = ch;
  const ctx = c.getContext("2d");
  ctx.setTransform(sc, 0, 0, sc, -x0 * sc, -y0 * sc);
  paint(ctx, doc.s, inkNow(), 1.1 / sc);
  const res = { url: c.toDataURL("image/webp", 0.8), w: cw, h: ch };
  if (tcache.size > 80) tcache.delete(tcache.keys().next().value);
  tcache.set(key, res);
  return res;
}

/* ---------- خروجی تصویر (همیشه روی زمینه‌ی روشن) ---------- */
export function exportImage(body, paperKind) {
  const doc = parse(body);
  let maxY = 0;
  for (const s of doc.s) maxY = Math.max(maxY, bb(s)[3]);
  const H = Math.ceil(Math.min(doc.h, Math.max(900, maxY + 80)));
  const sc = Math.min(1.6, 8000 / H);
  const c = document.createElement("canvas"); c.width = Math.round(W * sc); c.height = Math.round(H * sc);
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, c.width, c.height);
  ctx.setTransform(sc, 0, 0, sc, 0, 0);
  paperLines(ctx, paperKind || "plain", W, H);
  paint(ctx, doc.s, "#1d1f23", 1 / sc);
  return c.toDataURL("image/png");
}

/* ---------- بوم و نوار ابزار ---------- */
export function mount(host, note, api) {
  const doc = parse(note.body), prefs = loadPrefs();
  let tool = prefs.tool, handOn = false;
  const hist = [], redoStack = [];
  let k = 1, dpr = 1, cssW = 0, inkC = inkNow(), cur = null, pan = null, penMode = false, ring = null, rq = 0, syncT = 0;
  const touches = new Set();

  const paper = el("div", "paper"); paper.dataset.paper = note.paper || "plain";
  const base = el("canvas", "dc"), live = el("canvas", "dc live");
  paper.append(base, live); host.append(paper);
  const bctx = base.getContext("2d"), lctx = live.getContext("2d");

  function layout() {
    const w = paper.clientWidth;
    if (!w) return;
    cssW = w; k = w / W; dpr = Math.min(window.devicePixelRatio || 1, 2); inkC = inkNow();
    const cssH = Math.round(doc.h * k);
    paper.style.height = cssH + "px"; paper.style.setProperty("--k", String(k));
    for (const c of [base, live]) { c.width = Math.round(w * dpr); c.height = Math.round(cssH * dpr); c.style.width = w + "px"; c.style.height = cssH + "px"; }
    redraw();
  }
  function redraw() {
    if (!cssW) return;
    bctx.setTransform(1, 0, 0, 1, 0, 0); bctx.clearRect(0, 0, base.width, base.height);
    bctx.setTransform(dpr * k, 0, 0, dpr * k, 0, 0);
    paint(bctx, doc.s, inkC, 0.8 / k);
  }
  const redrawSoon = () => { if (!rq) rq = requestAnimationFrame(() => { rq = 0; redraw(); }); };
  const ro = new ResizeObserver(() => { if (paper.clientWidth !== cssW) layout(); });
  ro.observe(paper);
  layout();

  const pos = (e) => { const r = paper.getBoundingClientRect(); return [(e.clientX - r.left) / k, (e.clientY - r.top) / k]; };

  /* --- تاریخچه --- */
  const pushOp = (op) => { hist.push(op); if (hist.length > 150) hist.shift(); redoStack.length = 0; changed(); };
  function changed() {
    clearTimeout(syncT); syncT = setTimeout(sync, 250);
    refreshTb();
  }
  function sync() { clearTimeout(syncT); syncT = 0; api.onChange(stringify(doc)); }
  function undo() {
    const op = hist.pop(); if (!op) return;
    if (op.add) { const i = doc.s.lastIndexOf(op.add); if (i >= 0) doc.s.splice(i, 1); }
    else op.del.forEach(({ i, s }) => doc.s.splice(Math.min(i, doc.s.length), 0, s));
    redoStack.push(op); redraw(); changed();
  }
  function redo() {
    const op = redoStack.pop(); if (!op) return;
    if (op.add) doc.s.push(op.add);
    else { const set = new Set(op.del.map((d) => d.s)); doc.s = doc.s.filter((s) => !set.has(s)); }
    hist.push(op); redraw(); changed();
  }
  function clearAll() {
    if (!doc.s.length) return false;
    pushOp({ del: doc.s.map((s, i) => ({ i, s })) });
    doc.s = []; redraw();
    return true;
  }

  /* --- ورودی --- */
  function liveSetup(c, w, cap) {
    lctx.setTransform(dpr * k, 0, 0, dpr * k, 0, 0);
    lctx.strokeStyle = lctx.fillStyle = c === "ink" ? inkC : c;
    lctx.lineWidth = Math.max(w, 0.8 / k); lctx.lineCap = cap; lctx.lineJoin = "round"; lctx.globalAlpha = 1;
  }
  function begin(e) {
    const [x, y] = pos(e);
    if (tool === "eraser") {
      cur = { id: e.pointerId, erase: true, before: doc.s.slice() };
      live.style.opacity = "1";
      eraseAt(x, y);
      return;
    }
    const pr = prefs[tool], T = TOOLS[tool], w = r1(T.w * SIZE_F[pr.s]);
    cur = { id: e.pointerId, s: { t: tool, c: pr.c, w, p: [r1(x), r1(y)] }, lx: x, ly: y, mx: x, my: y };
    live.style.opacity = String(T.a);
    liveSetup(pr.c, w, T.cap);
    if (T.cap === "round") { lctx.beginPath(); lctx.arc(x, y, lctx.lineWidth / 2, 0, 6.2832); lctx.fill(); }
  }
  function add(ev) {
    const [x, y] = pos(ev);
    if (cur.erase) { eraseAt(x, y); return; }
    const dx = x - cur.lx, dy = y - cur.ly, m = 0.9 / k;
    if (dx * dx + dy * dy < m * m) return;
    const mx = (cur.lx + x) / 2, my = (cur.ly + y) / 2;
    lctx.beginPath(); lctx.moveTo(cur.mx, cur.my); lctx.quadraticCurveTo(cur.lx, cur.ly, mx, my); lctx.stroke();
    cur.mx = mx; cur.my = my; cur.lx = x; cur.ly = y; cur.s.p.push(r1(x), r1(y));
  }
  function clearLive() { lctx.setTransform(1, 0, 0, 1, 0, 0); lctx.clearRect(0, 0, live.width, live.height); ring = null; }
  function finish() {
    const c = cur; cur = null;
    if (c.erase) {
      clearRing();
      const left = new Set(doc.s), removed = [];
      c.before.forEach((s, i) => { if (!left.has(s)) removed.push({ i, s }); });
      if (removed.length) pushOp({ del: removed });
      return;
    }
    const s = c.s;
    s.p = simplify(s.p, 0.5 / k);
    doc.s.push(s);
    bctx.setTransform(dpr * k, 0, 0, dpr * k, 0, 0);
    stroke(bctx, s, inkC, 0.8 / k); bctx.globalAlpha = 1;
    clearLive();
    const b = bb(s);
    if (b[3] > doc.h - 500 && doc.h < MAX_H) { doc.h = Math.min(MAX_H, Math.ceil(b[3] + 1000)); layout(); }
    pushOp({ add: s });
  }
  function cancelStroke() {
    if (!cur) return;
    if (cur.erase) { finish(); return; }
    cur = null; clearLive();
  }
  function eraseAt(x, y) {
    const r = ERASE_R[prefs.eraser.s] / k;
    drawRing(x, y, r);
    let any = false;
    for (let i = doc.s.length - 1; i >= 0; i--) if (hits(doc.s[i], x, y, r)) { doc.s.splice(i, 1); any = true; }
    if (any) redrawSoon();
  }
  function clearRing() {
    if (!ring) return;
    lctx.setTransform(dpr * k, 0, 0, dpr * k, 0, 0);
    const m = ring.r + 4 / k;
    lctx.clearRect(ring.x - m, ring.y - m, 2 * m, 2 * m);
    ring = null;
  }
  function drawRing(x, y, r) {
    clearRing();
    lctx.setTransform(dpr * k, 0, 0, dpr * k, 0, 0);
    lctx.globalAlpha = 1; lctx.lineWidth = 1.6 / k; lctx.strokeStyle = "rgba(128,128,128,.95)"; lctx.fillStyle = "rgba(128,128,128,.12)";
    lctx.beginPath(); lctx.arc(x, y, r, 0, 6.2832); lctx.fill(); lctx.stroke();
    ring = { x, y, r };
  }

  paper.addEventListener("pointerdown", (e) => {
    if (handOn) return;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    if (e.pointerType === "pen") penMode = true;
    if (e.pointerType === "touch") {
      touches.add(e.pointerId);
      if (penMode || touches.size > 1) {
        cancelStroke();
        pan = { id: e.pointerId, y: e.clientY };
        try { paper.setPointerCapture(e.pointerId); } catch (_) {}
        return;
      }
    }
    if (cur) return;
    e.preventDefault();
    try { paper.setPointerCapture(e.pointerId); } catch (_) {}
    begin(e);
  });
  paper.addEventListener("pointermove", (e) => {
    if (pan && pan.id === e.pointerId) { api.scroller.scrollTop -= e.clientY - pan.y; pan.y = e.clientY; return; }
    if (!cur || cur.id !== e.pointerId) return;
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : null;
    for (const ev of evs && evs.length ? evs : [e]) add(ev);
  });
  const end = (e) => {
    touches.delete(e.pointerId);
    if (pan && pan.id === e.pointerId) { pan = null; return; }
    if (cur && cur.id === e.pointerId) { e.type === "pointercancel" ? cancelStroke() : finish(); }
  };
  paper.addEventListener("pointerup", end);
  paper.addEventListener("pointercancel", end);
  paper.addEventListener("contextmenu", (e) => e.preventDefault());

  /* --- نوار ابزار --- */
  const tb = el("div", "draw-tb");
  const row1 = el("div", "dt-row"), row2 = el("div", "dt-row opts");
  tb.append(row1, row2);
  const LABEL = { pencil: Tr("مداد"), pen: Tr("خودکار"), marker: Tr("ماژیک"), hl: Tr("هایلایت"), eraser: Tr("پاک‌کن") };
  const tbtn = (ic, label, fn) => { const b = el("button", "tb", icon(ic)); b.setAttribute("aria-label", label); b.onclick = fn; return b; };
  const toolBtns = {};
  ORDER.forEach((t) => { toolBtns[t] = tbtn(t, LABEL[t], () => setTool(t)); row1.append(toolBtns[t]); });
  const handBtn = tbtn("hand", Tr("جابه‌جایی صفحه"), () => { handOn = !handOn; paper.style.touchAction = handOn ? "pan-y" : "none"; refreshTb(); });
  const undoBtn = tbtn("undo", Tr("برگردان"), undo), redoBtn = tbtn("redo", Tr("جلو"), redo);
  row1.append(el("i", "dt-sep"), handBtn, undoBtn, redoBtn);

  function setTool(t) {
    if (cur) cancelStroke();
    tool = t; handOn = false; paper.style.touchAction = "none";
    prefs.tool = t; savePrefs(prefs); refreshTb();
    if (api.haptic) api.haptic();
  }
  function refreshTb() {
    ORDER.forEach((t) => toolBtns[t].classList.toggle("on", !handOn && tool === t));
    handBtn.classList.toggle("on", handOn);
    undoBtn.disabled = !hist.length; redoBtn.disabled = !redoStack.length;
    row2.innerHTML = "";
    row2.hidden = handOn;
    if (handOn) return;
    if (tool !== "eraser") {
      PALETTE.forEach((c) => {
        const b = el("button", "dsw" + (prefs[tool].c === c ? " on" : "")); b.style.background = c === "ink" ? "var(--text)" : c;
        b.setAttribute("aria-label", c);
        b.onclick = () => { prefs[tool].c = c; savePrefs(prefs); refreshTb(); };
        row2.append(b);
      });
    } else {
      const b = el("button", "btn small ghost-btn", icon("trash") + "<span>" + Tr("پاک کردن صفحه") + "</span>");
      b.onclick = () => { if (clearAll() && api.toast) api.toast(Tr("صفحه پاک شد"), () => undo()); };
      row2.append(b);
    }
    const sz = el("button", "dsize"); sz.setAttribute("aria-label", Tr("اندازه"));
    const dot = el("i"); const d = [6, 11, 17][prefs[tool].s]; dot.style.width = dot.style.height = d + "px"; sz.append(dot);
    sz.onclick = () => { prefs[tool].s = (prefs[tool].s + 1) % 3; savePrefs(prefs); refreshTb(); };
    row2.append(sz);
  }
  refreshTb();

  return {
    toolbar: tb,
    hasStrokes: () => doc.s.length > 0,
    setPaper(kind) { paper.dataset.paper = kind; },
    clear: clearAll, undo,
    image: (kind) => exportImage(stringify(doc), kind),
    flush: () => { if (syncT) sync(); },
    destroy() {
      if (cur) cancelStroke();
      if (syncT) sync();
      ro.disconnect(); if (rq) cancelAnimationFrame(rq);
      paper.remove();
    },
  };
}
