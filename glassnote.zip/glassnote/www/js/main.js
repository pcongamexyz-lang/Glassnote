// راه‌اندازی برنامه
import { initRefraction } from "./refract.js";
import { $, el, txt, icon, toast } from "./utils.js";
import * as store from "./store.js";
import * as home from "./home.js";
import * as editor from "./editor.js";
import { closeTopSheet, hasSheet } from "./sheets.js";
import * as native from "./native.js";
import * as vault from "./crypto.js";
import { Tr, Trt } from "./i18n.js";

/* ---------- تم ---------- */
const mq = matchMedia("(prefers-color-scheme: dark)");
function applyTheme() {
  const s = store.state.settings, root = document.documentElement;
  const mode = s.theme === "system" ? (mq.matches ? "dark" : "light") : s.theme;
  root.dataset.mode = mode;
  root.style.setProperty("--accent-rgb", s.accent);
  root.style.setProperty("--fs", String(s.fontScale));
  root.style.setProperty("--gk", String(s.glass == null ? 1 : s.glass));
  root.style.setProperty("--lines", String(s.lines || 7));
  root.classList.toggle("calm", s.motion === false);
  window.__noHaptic = s.haptics === false;
  const bg = getComputedStyle(root).getPropertyValue("--bg").trim() || "#f5f6f8";
  native.setSystemBars(mode === "light", bg);
  try { window.GlassDock && window.GlassDock.setTheme(JSON.stringify({ dark: mode !== "light", accent: s.accent, bg })); } catch (e) {}
  const tc = document.querySelector('meta[name="theme-color"]');
  if (tc) tc.content = bg;
}
mq.addEventListener && mq.addEventListener("change", () => store.state.settings.theme === "system" && applyTheme());

/* ---------- قفل برنامه ---------- */
const lockEl = $("#lock");
let entry = "", locked = false;
function showLock() {
  const pin = store.state.settings.pin;
  if (!pin || locked) return;
  locked = true; entry = "";
  lockEl.hidden = false;
  lockEl.innerHTML = Trt`<div class="lock-in"><div class="lock-ic">${icon("lock")}</div><b>گلس‌نوت</b><p>رمز رو وارد کن</p><div class="dots" id="dots"></div><div class="pad" id="pad"></div></div>`;
  const pad = $("#pad");
  ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "del"].forEach((k) => {
    if (!k) { pad.append(el("span")); return; }
    const b = el("button", "key", k === "del" ? icon("backspace") : "");
    if (k !== "del") b.textContent = k;
    b.setAttribute("aria-label", k === "del" ? Tr("پاک کردن") : k);
    b.onclick = () => press(k);
    pad.append(b);
  });
  drawDots();
}
function drawDots(err) {
  const d = $("#dots");
  if (!d) return;
  const len = store.state.settings.pin ? store.state.settings.pin.len : 4;
  d.innerHTML = "";
  d.classList.toggle("shake", !!err);
  for (let i = 0; i < len; i++) d.append(el("i", i < entry.length ? "on" : ""));
}
async function press(k) {
  const pin = store.state.settings.pin;
  if (!pin) return;
  native.haptic("light");
  if (k === "del") entry = entry.slice(0, -1); else if (entry.length < pin.len) entry += k;
  drawDots();
  if (entry.length === pin.len) {
    let ok = false;
    try { ok = await vault.checkPin(entry, pin); } catch (e) {}
    if (ok) { locked = false; lockEl.hidden = true; lockEl.innerHTML = ""; entry = ""; native.haptic("success"); }
    else { native.haptic("error"); entry = ""; drawDots(true); setTimeout(() => drawDots(), 400); }
  }
}
function maybeLockOnLeave() {
  const s = store.state.settings;
  if (s.pin && s.lockOnExit && Date.now() > store.runtime.holdLockUntil) showLock();
}
native.onAppActive((active) => { if (!active) maybeLockOnLeave(); else checkDue(); });
document.addEventListener("visibilitychange", () => { if (document.hidden) maybeLockOnLeave(); else checkDue(); });

/* ---------- یادآورهای داخل برنامه ---------- */
function checkDue() {
  const now = Date.now();
  let changed = false;
  store.state.notes.forEach((n) => {
    const r = n.reminder;
    if (!r || n.trashedAt || r.at > now) return;
    const recent = now - r.at < 2 * 3600 * 1000;
    if (r.repeat === "none") {
      if (!r.fired) {
        r.fired = true; changed = true;
        if (recent && !locked) toast(Tr("یادآوری: ") + (n.lock ? Tr("یک یادداشت قفل‌شده") : (n.title || store.plain(n).slice(0, 40) || Tr("یادداشت"))), { action: Tr("باز کردن"), onAction: () => home.openNote(n.id) });
      }
    } else {
      const step = (r.repeat === "day" ? 1 : 7) * 86400000;
      while (r.at <= now) r.at += step;
      changed = true;
    }
  });
  if (changed) { store.save(); store.emit(); }
}

/* ---------- دکمه‌ی برگشت اندروید ---------- */
native.onBackButton(() => {
  if (locked) return;
  if (closeTopSheet()) return;
  if (editor.isOpen()) { editor.closeEditor(); return; }
  if (home.handleBack()) return;
  native.exitApp();
});

/* ---------- شروع ---------- */
native.initSystemBars();
/* شکست نور فعلاً خاموشه؛ فقط بلور */ // initRefraction();
store.load();
applyTheme();
store.subscribe(applyTheme);
home.init();
showLock();
native.initNotifications((id) => { if (!locked) home.openNote(id); });
checkDue();
setInterval(checkDue, 30000);

window.__gn = { store, home, editor }; // برای تست و عیب‌یابی
