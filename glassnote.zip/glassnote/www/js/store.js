// وضعیت برنامه، ذخیره‌سازی و جستجو
import { uid, debounce, normalize, toast } from "./utils.js";
import { Tr } from "./i18n.js";
import { htmlToText, htmlToMd } from "./html.js";

const KEY = "gn.data.v1", SKEY = "gn.settings.v1";
const TRASH_DAYS = 30;

export const COLORS = 8; // 0 = بدون رنگ، ۱ تا ۷ رنگ‌ها
export const ACCENTS = [
  ["112,98,244", Tr("آیریس")], ["20,166,160", Tr("فیروزه‌ای")], ["124,92,235", Tr("بنفش")],
  ["224,78,120", Tr("گل‌بهی")], ["232,130,40", Tr("نارنجی")], ["46,160,100", Tr("سبز")],
  ["229,72,77", Tr("قرمز")], ["232,184,32", Tr("زرد")], ["88,196,140", Tr("نعنایی")], ["88,86,214", Tr("نیلی")],
  ["191,90,242", Tr("ارغوانی")], ["52,170,220", Tr("آسمانی")], ["162,132,94", Tr("قهوه‌ای")], ["142,146,156", Tr("خاکستری")],
];

export const state = {
  notes: [],
  labels: [],
  settings: {
    theme: "system", accent: ACCENTS[0][0], fontScale: 1, layout: "grid", sort: "updated",
    pin: null, lockOnExit: true,
  },
};

// وضعیت لحظه‌ای که ذخیره نمی‌شه
export const runtime = { holdLockUntil: 0 };

const subs = new Set();
export const subscribe = (fn) => { subs.add(fn); return () => subs.delete(fn); };
export const emit = () => subs.forEach((f) => f());

/* ---------- ذخیره‌سازی ---------- */
// نسخه‌ی قابل ذخیره‌ی یادداشت؛ محتوای یادداشت قفل‌شده هرگز به‌صورت متن ساده ذخیره نمی‌شه
export function serialize(n) {
  const locked = !!n.lock;
  return {
    id: n.id, type: n.type,
    title: locked ? "" : n.title, body: locked ? "" : n.body, items: locked ? [] : n.items,
    color: n.color, labels: n.labels, pinned: n.pinned, archived: n.archived, trashedAt: n.trashedAt,
    created: n.created, updated: n.updated, reminder: n.reminder, lock: n.lock, paper: n.paper, fmt: n.fmt,
  };
}
function saveNow() {
  try {
    localStorage.setItem(KEY, JSON.stringify({ notes: state.notes.map(serialize), labels: state.labels }));
  } catch (e) {
    toast(Tr("حافظه پر شده؛ از یادداشت‌ها پشتیبان بگیر"));
  }
}
export const save = debounce(saveNow, 300);
export const flush = () => save.flush();
window.addEventListener("pagehide", saveNow);
document.addEventListener("visibilitychange", () => { if (document.hidden) saveNow(); });

export function saveSettings() {
  try { localStorage.setItem(SKEY, JSON.stringify(state.settings)); } catch (e) {}
  emit();
}

export function load() {
  try {
    const d = JSON.parse(localStorage.getItem(KEY) || "null");
    if (d) { state.notes = Array.isArray(d.notes) ? d.notes : []; state.labels = Array.isArray(d.labels) ? d.labels : []; }
  } catch (e) {}
  try { Object.assign(state.settings, JSON.parse(localStorage.getItem(SKEY) || "{}")); } catch (e) {}
  purgeTrash();
}

export function purgeTrash() {
  const limit = Date.now() - TRASH_DAYS * 86400000;
  const before = state.notes.length;
  state.notes = state.notes.filter((n) => !(n.trashedAt && n.trashedAt < limit));
  if (state.notes.length !== before) save();
}

/* ---------- یادداشت‌ها ---------- */
export const newItem = (text = "") => ({ id: uid(), text, done: false });

export function createNote(type = "text", extra = {}) {
  const n = {
    id: uid(), type, title: "", body: "", items: type === "list" ? [newItem()] : [],
    color: 0, labels: [], pinned: false, archived: false, trashedAt: null,
    created: Date.now(), updated: Date.now(), reminder: null, lock: null, paper: "plain", fmt: type === "text" ? "html" : undefined, ...extra,
  };
  state.notes.unshift(n);
  return n;
}
export const getNote = (id) => state.notes.find((n) => n.id === id);

export function commit(n, { silent = false, touch = true } = {}) {
  if (touch) n.updated = Date.now();
  save();
  if (!silent) emit();
}

export function removeNote(n) {
  state.notes = state.notes.filter((x) => x !== n);
  save(); emit();
}

// متن ساده‌ی یادداشت (برای پیش‌نمایش، جستجو و شمارش)؛ یادداشت‌های قالب‌دار HTML هستن
const pcache = new Map();
export function plain(n) {
  if (n.type === "draw") return "";
  if (n.type === "list") return n.items.map((i) => i.text).join("\n");
  const b = n.body || "";
  if (n.fmt !== "html" || !b) return b;
  let r = pcache.get(b);
  if (r === undefined) { r = htmlToText(b); if (pcache.size > 400) pcache.clear(); pcache.set(b, r); }
  return r;
}

export function isEmpty(n) {
  if (n.lock) return false;
  return !n.title.trim() && !plain(n).trim() && !n.items.some((i) => i.text.trim());
}

export function duplicate(n) {
  const c = createNote(n.type, {
    title: n.title ? n.title + Tr(" (کپی)") : "", body: n.body, items: n.items.map((i) => ({ ...i, id: uid() })),
    color: n.color, labels: [...n.labels], paper: n.paper, fmt: n.fmt,
  });
  commit(c);
  return c;
}

/* ---------- متن یادداشت ---------- */
export function noteText(n, md = false) {
  const parts = [];
  if (n.title.trim()) parts.push(n.title.trim());
  if (n.type === "list") parts.push(n.items.filter((i) => i.text.trim()).map((i) => `- [${i.done ? "x" : " "}] ${i.text}`).join("\n"));
  else if (n.type !== "draw") { const t = md && n.fmt === "html" ? htmlToMd(n.body) : plain(n); if (t.trim()) parts.push(t); }
  return parts.filter(Boolean).join("\n\n");
}
export function convertType(n) {
  if (n.type === "text") {
    const items = [];
    for (const l of plain(n).split("\n")) {
      if (!l.trim()) continue;
      const m = /^\s*[-*]\s+\[( |x|X)\]\s*(.*)$/.exec(l);
      const text = (m ? m[2] : l.replace(/^\s*([-*]|\d+[.)])\s+/, "")).trim();
      if (text) items.push({ id: uid(), text, done: !!m && m[1] !== " " });
    }
    n.items = items.length ? items : [newItem()];
    n.body = ""; n.fmt = undefined; n.type = "list";
  } else {
    n.body = n.items.filter((i) => i.text.trim()).map((i) => `- [${i.done ? "x" : " "}] ${i.text}`).join("\n");
    n.items = []; n.type = "text"; n.fmt = "md";
  }
}

export function preview(n) {
  if (n.type === "list") return n.items.filter((i) => i.text.trim());
  return plain(n);
}

/* ---------- جستجو و فیلتر ---------- */
export function query({ view = "notes", label = null, filter = null, search = "" } = {}) {
  const q = normalize(search).trim();
  let list = state.notes.filter((n) => {
    if (view === "trash") return !!n.trashedAt;
    if (n.trashedAt) return false;
    return view === "archive" ? n.archived : !n.archived;
  });
  if (label) list = list.filter((n) => n.labels.includes(label));
  if (filter === "reminder") list = list.filter((n) => n.reminder);
  if (filter === "list") list = list.filter((n) => n.type === "list");
  if (filter === "locked") list = list.filter((n) => n.lock);
  if (filter === "draw") list = list.filter((n) => n.type === "draw");
  if (q) {
    list = list.filter((n) => {
      if (n.lock) return false;
      const labelNames = n.labels.map((id) => (state.labels.find((l) => l.id === id) || {}).name || "").join(" ");
      return normalize([n.title, n.type === "draw" ? "" : plain(n), n.items.map((i) => i.text).join(" "), labelNames].join(" ")).includes(q);
    });
  }
  const s = state.settings.sort;
  const cmp = s === "title" ? (a, b) => (a.title || "~").localeCompare(b.title || "~", "fa")
    : s === "created" ? (a, b) => b.created - a.created : (a, b) => b.updated - a.updated;
  list.sort((a, b) => (view === "notes" ? (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) : 0) || cmp(a, b));
  return list;
}

export function counts() {
  const live = state.notes.filter((n) => !n.trashedAt);
  return {
    notes: live.filter((n) => !n.archived).length,
    archive: live.filter((n) => n.archived).length,
    trash: state.notes.length - live.length,
  };
}

/* ---------- برچسب‌ها ---------- */
export function addLabel(name) {
  name = name.trim();
  if (!name) return null;
  const ex = state.labels.find((l) => l.name === name);
  if (ex) return ex;
  const l = { id: uid(), name };
  state.labels.push(l); save(); emit();
  return l;
}
export function renameLabel(id, name) {
  const l = state.labels.find((x) => x.id === id);
  if (l && name.trim()) { l.name = name.trim(); save(); emit(); }
}
export function deleteLabel(id) {
  state.labels = state.labels.filter((l) => l.id !== id);
  state.notes.forEach((n) => { n.labels = n.labels.filter((x) => x !== id); });
  save(); emit();
}
export const labelName = (id) => (state.labels.find((l) => l.id === id) || {}).name || "";

/* ---------- پشتیبان ---------- */
export function exportBackup() {
  return JSON.stringify({
    app: "glassnote", v: 1, exportedAt: new Date().toISOString(),
    notes: state.notes.map(serialize), labels: state.labels,
  }, null, 2);
}
export function importBackup(text) {
  let d;
  try { d = JSON.parse(text); } catch (e) { throw new Error(Tr("فایل پشتیبان معتبر نیست")); }
  if (!d || d.app !== "glassnote" || !Array.isArray(d.notes)) throw new Error(Tr("این فایل، پشتیبان گلس‌نوت نیست"));
  let added = 0, updated = 0;
  (d.labels || []).forEach((l) => { if (l && l.id && l.name && !state.labels.some((x) => x.id === l.id)) state.labels.push({ id: l.id, name: String(l.name) }); });
  d.notes.forEach((raw) => {
    if (!raw || !raw.id) return;
    const n = { ...createBlank(), ...raw };
    n.items = Array.isArray(n.items) ? n.items : []; n.labels = Array.isArray(n.labels) ? n.labels : [];
    const ex = state.notes.find((x) => x.id === n.id);
    if (!ex) { state.notes.push(n); added++; }
    else if ((n.updated || 0) > (ex.updated || 0) && !ex._key) { Object.assign(ex, n); updated++; }
  });
  save(); emit();
  return { added, updated };
}
function createBlank() {
  return { id: "", type: "text", title: "", body: "", items: [], color: 0, labels: [], pinned: false, archived: false, trashedAt: null, created: Date.now(), updated: Date.now(), reminder: null, lock: null, paper: "plain" };
}

export function wipeTrash() {
  const ids = state.notes.filter((n) => n.trashedAt);
  state.notes = state.notes.filter((n) => !n.trashedAt);
  save(); emit();
  return ids;
}
