// شکست نور واقعی (لیکویید گلس) با backdrop-filter + فیلتر SVG
// روش: نقشه‌ی جابه‌جایی بر اساس شکل سطح شیشه (انحنای لبه) و قانون اسنل ساخته می‌شه و برای «اندازه‌ی دقیق هر المان» فیلتر جدا می‌سازیم
// (فیلتر پس‌زمینه خودش اندازه عوض نمی‌کنه، پس اندازه باید پیکسلی و دقیق باشه).
// فقط روی موتور Chromium کار می‌کنه؛ جاهای دیگه کلاس "refract" اضافه نمی‌شه و ظاهر معمولی می‌مونه.
const NS = "http://www.w3.org/2000/svg", XL = "http://www.w3.org/1999/xlink";
let defs = null, ok = false;
const cache = new Map();

export const refractionOn = () => ok;

export function initRefraction() {
  try {
    const ua = navigator.userAgent || "", m = /Chrome\/(\d+)/.exec(ua);
    if (!m || +m[1] < 90 || /Firefox|iPhone|iPad|Edg\/.*Mobile Safari.*Version\/\d+\.\d+ Mobile/.test(ua)) return;
    defs = document.getElementById("lg-defs");
    if (!defs) return;
    ok = true;
    document.documentElement.classList.add("refract");
  } catch (e) {}
}

const squircle = (x) => Math.pow(1 - Math.pow(1 - x, 4), 0.25); // پروفایل محدب نرم (مثل Apple)

// نقشه‌ی جابه‌جایی: کنار لبه بیشترین خم‌شدن، وسط صفر
function makeMap(w, h, bezel, ior) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const g = c.getContext("2d"), img = g.createImageData(w, h), d = img.data;
  const R = Math.min(w, h) / 2;
  // اندازه‌ی جابه‌جایی برای ۱۲۷ نقطه روی بزل (قانون اسنل، یک بار شکست)
  const N = 127, mag = new Float32Array(N + 1); let max = 0;
  for (let i = 0; i <= N; i++) {
    const x = i / N, dl = 0.001;
    const slope = (squircle(Math.min(1, x + dl)) - squircle(Math.max(0, x - dl))) / (Math.min(1, x + dl) - Math.max(0, x - dl));
    const th1 = Math.atan(Math.abs(slope));            // زاویه‌ی برخورد
    const th2 = Math.asin(Math.min(1, Math.sin(th1) / ior)); // زاویه‌ی شکست
    mag[i] = (1 - x) * (Math.tan(th1) - Math.tan(th2)) * (1 - squircle(x) * 0) ; // هرچه به لبه نزدیک‌تر، قوی‌تر
    mag[i] = Math.max(0, Math.tan(th1 - th2)) * Math.pow(1 - x, 1.1);
    if (mag[i] > max) max = mag[i];
  }
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const px = Math.abs(x + 0.5 - w / 2) - (w / 2 - R), py = Math.abs(y + 0.5 - h / 2) - (h / 2 - R);
    const sd = Math.hypot(Math.max(px, 0), Math.max(py, 0)) + Math.min(Math.max(px, py), 0) - R; // منفی = داخل
    const depth = -sd; let dx = 0, dy = 0;
    if (depth >= 0 && depth < bezel) {
      const k = mag[Math.min(N, Math.round((depth / bezel) * N))] / (max || 1);
      let nx = x + 0.5 - w / 2, ny = y + 0.5 - h / 2;
      if (px <= 0 && py > 0) nx = 0; else if (py <= 0 && px > 0) ny = 0;
      const n = Math.hypot(nx, ny) || 1;
      dx = -(nx / n) * k; dy = -(ny / n) * k; // به سمت داخل (محدب)
    }
    const i = (y * w + x) * 4;
    d[i] = 128 + dx * 127; d[i + 1] = 128 + dy * 127; d[i + 2] = 128; d[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return c.toDataURL("image/png");
}

// فیلتر دقیقِ این اندازه رو می‌سازه (یا از کش می‌خونه) و به المان می‌چسبونه
export function refractEl(elm, id, { strength = 1, bezelRatio = 0.55, extra = "saturate(1.25) brightness(1.06)" } = {}) {
  if (!ok || !elm) return;
  const w = Math.round(elm.offsetWidth), h = Math.round(elm.offsetHeight);
  if (w < 8 || h < 8) return;
  const key = `${id}:${w}x${h}:${strength}`;
  if (elm.dataset.rk === key) return;
  elm.dataset.rk = key;
  let f = document.getElementById(id);
  if (!f) { f = document.createElementNS(NS, "filter"); f.id = id; f.setAttribute("color-interpolation-filters", "sRGB"); defs.append(f); }
  const bezel = Math.max(6, Math.min(w, h) * bezelRatio);
  const mk = `${w}x${h}:${Math.round(bezel)}`;
  let url = cache.get(mk);
  if (!url) { url = makeMap(w, h, bezel, 1.5); cache.set(mk, url); if (cache.size > 40) cache.delete(cache.keys().next().value); }
  const scale = Math.round(Math.min(w, h) * 0.9 * strength);
  f.setAttribute("filterUnits", "userSpaceOnUse"); f.setAttribute("primitiveUnits", "userSpaceOnUse");
  f.setAttribute("x", "0"); f.setAttribute("y", "0"); f.setAttribute("width", String(w)); f.setAttribute("height", String(h));
  f.innerHTML = "";
  const im = document.createElementNS(NS, "feImage");
  im.setAttribute("href", url); im.setAttributeNS(XL, "href", url);
  im.setAttribute("x", "0"); im.setAttribute("y", "0"); im.setAttribute("width", String(w)); im.setAttribute("height", String(h));
  im.setAttribute("preserveAspectRatio", "none"); im.setAttribute("result", "m");
  const dm = document.createElementNS(NS, "feDisplacementMap");
  dm.setAttribute("in", "SourceGraphic"); dm.setAttribute("in2", "m"); dm.setAttribute("scale", String(scale));
  dm.setAttribute("xChannelSelector", "R"); dm.setAttribute("yChannelSelector", "G");
  f.append(im, dm);
  const v = `url(#${id}) ${extra}`;
  elm.style.webkitBackdropFilter = v; elm.style.backdropFilter = v;
}
