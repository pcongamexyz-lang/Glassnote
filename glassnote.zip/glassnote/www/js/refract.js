// شکست نور واقعی برای شیشه‌های کوچک (نشانگر داک، دسته‌ی اسلایدر، زبانه‌ی گزینه‌ها)
// نقشه‌ی جابه‌جایی را با canvas می‌سازیم: کنار لبه‌ها پس‌زمینه به سمت مرکز خم می‌شه، وسط شیشه دست‌نخورده می‌مونه.
// اگر مرورگر backdrop-filter با فیلتر SVG رو پشتیبانی نکنه، هیچ کلاسی اضافه نمی‌شه و ظاهر قبلی می‌مونه.
export function initRefraction() {
  try {
    const ua = navigator.userAgent || "";
    const chromium = /Chrome\/(\d+)/.exec(ua);
    if (!chromium || +chromium[1] < 90 || /Firefox|iPhone|iPad/.test(ua)) return;
    const W = 160, H = 80, R = 40, c = document.createElement("canvas");
    c.width = W; c.height = H;
    const g = c.getContext("2d"), img = g.createImageData(W, H), d = img.data;
    const band = 17; // پهنای ناحیه‌ی خم‌شدن کنار لبه (پیکسل)
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      // فاصله‌ی علامت‌دار تا مستطیل گرد
      const px = Math.abs(x + 0.5 - W / 2) - (W / 2 - R), py = Math.abs(y + 0.5 - H / 2) - (H / 2 - R);
      const ox = Math.max(px, 0), oy = Math.max(py, 0);
      const sd = Math.hypot(ox, oy) + Math.min(Math.max(px, py), 0) - R; // منفی داخل
      const depth = -sd; // فاصله از لبه به سمت داخل
      let dx = 0, dy = 0;
      if (depth >= 0 && depth < band) {
        const t = 1 - depth / band, f = t * t * t; // خم‌شدن شدید نزدیک لبه
        // جهت: به سمت مرکز
        let nx = (x + 0.5 - W / 2), ny = (y + 0.5 - H / 2);
        // برای ناحیه‌ی صاف لبه‌ها فقط عمود بر لبه
        if (px <= 0 && py > 0) nx = 0; else if (py <= 0 && px > 0) ny = 0;
        const n = Math.hypot(nx, ny) || 1;
        dx = -(nx / n) * f; dy = -(ny / n) * f;
      }
      const i = (y * W + x) * 4;
      d[i] = 128 + dx * 127; d[i + 1] = 128 + dy * 127; d[i + 2] = 128; d[i + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    const m = document.getElementById("lg-map");
    if (m) { const url = c.toDataURL("image/png"); m.setAttribute("href", url); m.setAttributeNS("http://www.w3.org/1999/xlink", "href", url); }
    document.documentElement.classList.add("refract");
  } catch (e) {}
}
