// پنجره‌های پایین‌کشو، تأیید، ورودی و منو
import { $, el, txt, icon } from "./utils.js";

const stack = [];
const root = () => $("#sheets");

export function openSheet({ title, build, onClose }) {
  const wrap = el("div", "sheet-wrap");
  const scrim = el("div", "scrim");
  const panel = el("div", "sheet glass");
  panel.append(el("div", "grab"));
  if (title) panel.append(txt("div", "sheet-title", title));
  const body = el("div", "sheet-body");
  panel.append(body);
  wrap.append(scrim, panel);
  root().append(wrap);
  requestAnimationFrame(() => wrap.classList.add("open"));

  const api = {
    el: body,
    close(result) {
      const i = stack.indexOf(api);
      if (i < 0) return;
      stack.splice(i, 1);
      wrap.classList.remove("open");
      setTimeout(() => wrap.remove(), 230);
      onClose && onClose(result);
    },
  };
  scrim.onclick = () => api.close();
  stack.push(api);
  build(body, api);
  return api;
}
export const hasSheet = () => stack.length > 0;
export function closeTopSheet() {
  const t = stack[stack.length - 1];
  if (!t) return false;
  t.close();
  return true;
}

export function confirmDialog({ title, message, ok = "تأیید", danger = false }) {
  return new Promise((res) => {
    let done = false;
    openSheet({
      title,
      onClose: () => { if (!done) res(false); },
      build(b, api) {
        if (message) b.append(txt("p", "sheet-msg", message));
        const row = el("div", "btn-col");
        const okb = txt("button", "btn " + (danger ? "danger" : "primary"), ok);
        const no = txt("button", "btn ghost-btn", "انصراف");
        okb.onclick = () => { done = true; res(true); api.close(); };
        no.onclick = () => api.close();
        row.append(okb, no);
        b.append(row);
      },
    });
  });
}

// fields: [{type, placeholder, value, inputmode, maxlength}]  →  آرایه‌ی مقادیر یا null
export function promptDialog({ title, message, fields, ok = "تأیید", validate }) {
  return new Promise((res) => {
    let done = false;
    openSheet({
      title,
      onClose: () => { if (!done) res(null); },
      build(b, api) {
        if (message) b.append(txt("p", "sheet-msg", message));
        const inputs = fields.map((f) => {
          const i = el("input", "field");
          i.type = f.type || "text"; i.placeholder = f.placeholder || ""; i.value = f.value || "";
          if (f.inputmode) i.inputMode = f.inputmode;
          if (f.maxlength) i.maxLength = f.maxlength;
          i.autocomplete = "off"; i.dir = f.type === "password" ? "ltr" : "auto";
          b.append(i);
          return i;
        });
        const err = txt("div", "form-err", "");
        b.append(err);
        const submit = () => {
          const vals = inputs.map((i) => i.value);
          const msg = validate ? validate(vals) : "";
          if (msg) { err.textContent = msg; return; }
          done = true; res(vals); api.close();
        };
        inputs.forEach((i, idx) => i.addEventListener("keydown", (e) => {
          if (e.key === "Enter") { e.preventDefault(); idx < inputs.length - 1 ? inputs[idx + 1].focus() : submit(); }
        }));
        const row = el("div", "btn-col");
        const okb = txt("button", "btn primary", ok), no = txt("button", "btn ghost-btn", "انصراف");
        okb.onclick = submit; no.onclick = () => api.close();
        row.append(okb, no); b.append(row);
        setTimeout(() => inputs[0] && inputs[0].focus(), 260);
      },
    });
  });
}

// items: [{icon, label, sub, danger, check, onClick, keepOpen}]
export function menuSheet({ title, items }) {
  return openSheet({
    title,
    build(b, api) {
      const box = el("div", "menu");
      items.filter(Boolean).forEach((it) => {
        const r = el("button", "menu-row" + (it.danger ? " danger" : ""),
          (it.icon ? `<span class="mi">${icon(it.icon)}</span>` : "") + `<span class="mt"><b></b><small></small></span>` + (it.check ? `<span class="mc">${icon("check")}</span>` : ""));
        r.querySelector("b").textContent = it.label;
        const sm = r.querySelector("small");
        if (it.sub) sm.textContent = it.sub; else sm.remove();
        r.onclick = () => {
          if (it.keepOpen) { it.onClick && it.onClick(api, r); return; }
          api.close();
          setTimeout(() => it.onClick && it.onClick(), 20);
        };
        box.append(r);
      });
      b.append(box);
    },
  });
}
