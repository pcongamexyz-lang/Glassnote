// صفحه‌ی تنظیمات
import { el, txt, icon, toast, fa } from "./utils.js";
import * as store from "./store.js";
import { openSheet, confirmDialog, promptDialog } from "./sheets.js";
import * as native from "./native.js";
import * as vault from "./crypto.js";

export const VERSION = "1.0.0";
const S = () => store.state.settings;
const set = (k, v) => { S()[k] = v; store.saveSettings(); };

function group(title, rows) {
  const g = el("div", "set-group");
  if (title) g.append(txt("div", "section-label", title));
  const box = el("div", "group");
  rows.filter(Boolean).forEach((r) => box.append(r));
  g.append(box);
  return g;
}
function row({ ic, label, sub, end, onClick }) {
  const stack = end && end.classList && end.classList.contains("seg") && end.children.length > 3;
  const r = el(onClick ? "button" : "div", "set-row" + (onClick ? " tap" : "") + (stack ? " stack" : ""), (ic ? `<span class="mi">${icon(ic)}</span>` : "") + `<span class="mt"><b></b><small></small></span>`);
  r.querySelector("b").textContent = label;
  const sm = r.querySelector("small");
  if (sub) sm.textContent = sub; else sm.remove();
  if (end) r.append(end);
  else if (onClick) r.append(el("span", "chev", icon("chev")));
  if (onClick) r.onclick = onClick;
  return r;
}
function seg(options, value, onPick) {
  const s = el("div", "seg");
  options.forEach(([v, l]) => {
    const b = txt("button", String(v) === String(value) ? "on" : "", l);
    b.onclick = () => onPick(v);
    s.append(b);
  });
  return s;
}
function toggle(on, onChange) {
  const t = el("button", "switch" + (on ? " on" : ""), "<i></i>");
  t.setAttribute("role", "switch"); t.setAttribute("aria-checked", String(on));
  t.onclick = (e) => { e.stopPropagation(); onChange(!on); };
  return t;
}

export function renderSettings(container) {
  const s = S();
  const wrap = el("div", "settings");
  container.append(wrap);

  const swatches = el("div", "swatches inline");
  store.ACCENTS.forEach(([rgb, name]) => {
    const b = el("button", "sw" + (s.accent === rgb ? " on" : ""), "");
    b.style.background = `rgb(${rgb})`; b.setAttribute("aria-label", name);
    b.onclick = () => set("accent", rgb);
    swatches.append(b);
  });

  wrap.append(group("ظاهر", [
    row({ ic: "moon", label: "حالت نمایش", end: seg([["system", "خودکار"], ["light", "روشن"], ["dark", "تیره"], ["black", "مشکی"]], s.theme, (v) => set("theme", v)) }),
    row({ ic: "palette", label: "رنگ تأکید", end: swatches }),
    row({ ic: "type", label: "اندازه‌ی متن", end: seg([[0.9, "کوچک"], [1, "معمولی"], [1.15, "بزرگ"], [1.3, "خیلی بزرگ"]], s.fontScale, (v) => set("fontScale", v)) }),
  ]));

  wrap.append(group("یادداشت‌ها", [
    row({ ic: "grid", label: "چیدمان", end: seg([["grid", "شبکه‌ای"], ["list", "لیستی"]], s.layout, (v) => set("layout", v)) }),
    row({ ic: "sort", label: "مرتب‌سازی", end: seg([["updated", "ویرایش"], ["created", "ساخت"], ["title", "عنوان"]], s.sort, (v) => set("sort", v)) }),
    row({ ic: "tag", label: "مدیریت برچسب‌ها", sub: store.state.labels.length ? `${fa(store.state.labels.length)} برچسب` : "هنوز برچسبی نساختی", onClick: openLabels }),
  ]));

  wrap.append(group("امنیت", [
    row({ ic: "key", label: "قفل برنامه با رمز", sub: s.pin ? "فعاله" : "با رمز عددی ۴ تا ۶ رقمی", end: toggle(!!s.pin, (on) => (on ? setPin() : removePin())) }),
    s.pin && row({ ic: "shield", label: "قفل شدن هنگام خروج از برنامه", end: toggle(!!s.lockOnExit, (on) => set("lockOnExit", on)) }),
  ]));

  wrap.append(group("اطلاعات", [
    row({ ic: "download", label: "گرفتن پشتیبان", sub: "همه‌ی یادداشت‌ها در یک فایل JSON", onClick: backup }),
    row({ ic: "upload", label: "بازیابی از پشتیبان", sub: "ادغام با یادداشت‌های فعلی", onClick: restore }),
  ]));

  wrap.append(group("درباره", [
    row({ ic: "info", label: "گلس‌نوت", sub: `نسخه‌ی ${fa(VERSION)} · همه‌ی داده‌ها فقط روی همین دستگاه ذخیره می‌شن` }),
  ]));
}

/* ---------- برچسب‌ها ---------- */
function openLabels() {
  openSheet({
    title: "برچسب‌ها",
    build(b) {
      const list = el("div", "menu");
      const draw = () => {
        list.innerHTML = "";
        if (!store.state.labels.length) list.append(txt("p", "sheet-msg", "هنوز برچسبی نداری."));
        store.state.labels.forEach((l) => {
          const r = el("div", "label-row");
          const inp = el("input", "field"); inp.value = l.name; inp.dir = "auto";
          inp.onchange = () => { store.renameLabel(l.id, inp.value); };
          const del = el("button", "icon-btn", icon("trash")); del.setAttribute("aria-label", "حذف برچسب");
          del.onclick = async () => { if (await confirmDialog({ title: `حذف «${l.name}»؟`, message: "از یادداشت‌ها برداشته می‌شه ولی خود یادداشت‌ها می‌مونن.", ok: "حذف", danger: true })) { store.deleteLabel(l.id); draw(); } };
          r.append(inp, del); list.append(r);
        });
      };
      draw(); b.append(list);
      const add = el("div", "add-row"), inp = el("input", "field"), btn = txt("button", "btn small", "افزودن");
      inp.placeholder = "برچسب جدید"; inp.dir = "auto";
      const doAdd = () => { if (store.addLabel(inp.value)) { inp.value = ""; draw(); } };
      btn.onclick = doAdd; inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); doAdd(); } });
      add.append(inp, btn); b.append(add);
    },
  });
}

/* ---------- PIN ---------- */
async function setPin() {
  const r = await promptDialog({
    title: "رمز برنامه", message: "یه رمز عددی ۴ تا ۶ رقمی انتخاب کن.",
    fields: [{ type: "password", placeholder: "رمز", inputmode: "numeric", maxlength: 6 }, { type: "password", placeholder: "تکرار رمز", inputmode: "numeric", maxlength: 6 }], ok: "فعال کن",
    validate: (v) => (!/^\d{4,6}$/.test(v[0]) ? "رمز باید ۴ تا ۶ رقم باشه" : v[0] !== v[1] ? "رمزها یکی نیستن" : ""),
  });
  if (!r) { store.saveSettings(); return; }
  try {
    const rec = await vault.makePin(r[0]);
    S().pin = { ...rec, len: r[0].length };
    store.saveSettings(); toast("قفل برنامه فعال شد");
  } catch (e) { toast(e.message || "فعال نشد"); }
}
async function removePin() {
  const r = await promptDialog({ title: "غیرفعال کردن قفل", message: "رمز فعلی رو وارد کن.", fields: [{ type: "password", placeholder: "رمز", inputmode: "numeric", maxlength: 6 }], ok: "غیرفعال کن" });
  if (!r) { store.saveSettings(); return; }
  if (await vault.checkPin(r[0], S().pin)) { S().pin = null; store.saveSettings(); toast("قفل برنامه غیرفعال شد"); }
  else { toast("رمز اشتباهه"); native.haptic("error"); store.saveSettings(); }
}

/* ---------- پشتیبان ---------- */
async function backup() {
  const name = `glassnote-backup-${new Date().toISOString().slice(0, 10)}.json`;
  const ok = await native.shareFile(name, store.exportBackup(), "application/json");
  if (ok) toast("پشتیبان آماده شد");
}
function restore() {
  const inp = document.createElement("input");
  inp.type = "file"; inp.accept = ".json,application/json";
  inp.onchange = async () => {
    const f = inp.files[0];
    if (!f) return;
    try {
      const r = store.importBackup(await f.text());
      toast(`${fa(r.added)} یادداشت جدید، ${fa(r.updated)} به‌روزرسانی`);
    } catch (e) { toast(e.message || "بازیابی نشد"); }
  };
  store.runtime.holdLockUntil = Date.now() + 60000;
  inp.click();
}
