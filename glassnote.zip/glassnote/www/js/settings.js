// صفحه‌ی تنظیمات
import { el, txt, icon, toast, fa } from "./utils.js";
import * as store from "./store.js";
import { openSheet, confirmDialog, promptDialog } from "./sheets.js";
import * as native from "./native.js";
import * as vault from "./crypto.js";
import { Tr, Trt } from "./i18n.js";

export const VERSION = "1.7.0";
const S = () => store.state.settings;
const set = (k, v) => { S()[k] = v; store.saveSettings(); };

function group(title, rows) {
  const g = el("div", "set-group");
  if (title) g.append(txt("div", "section-label", title));
  const box = el("div", "group");
  rows.filter(Boolean).forEach((r) => box.append(r));
  g.append(box);
  return g;
}
function row({ ic, label, sub, end, onClick }) {
  const stack = end && end.classList && end.classList.contains("seg") && end.children.length > 3;
  const r = el(onClick ? "button" : "div", "set-row" + (onClick ? " tap" : "") + (stack ? " stack" : ""), (ic ? `<span class="mi">${icon(ic)}</span>` : "") + `<span class="mt"><b></b><small></small></span>`);
  r.querySelector("b").textContent = label;
  const sm = r.querySelector("small");
  if (sub) sm.textContent = sub; else sm.remove();
  if (end) r.append(end);
  else if (onClick) r.append(el("span", "chev", icon("chev")));
  if (onClick) r.onclick = onClick;
  return r;
}
function seg(options, value, onPick) {
  const s = el("div", "seg");
  const idx = Math.max(0, options.findIndex(([v]) => String(v) === String(value)));
  s.style.setProperty("--n", options.length); s.style.setProperty("--i", idx);
  s.append(el("span", "seg-thumb"));
  options.forEach(([v, l], i) => {
    const b = txt("button", i === idx ? "on" : "", l);
    b.onclick = () => {
      if (i === idx) return;
      s.style.setProperty("--i", i); [...s.querySelectorAll("button")].forEach((x, k) => x.classList.toggle("on", k === i));
      setTimeout(() => onPick(v), 230); // اول انیمیشن، بعد اعمال
    };
    s.append(b);
  });
  return s;
}
function toggle(on, onChange) {
  const t = el("button", "switch" + (on ? " on" : ""), "<i></i>");
  t.setAttribute("role", "switch"); t.setAttribute("aria-checked", String(on));
  t.onclick = (e) => { e.stopPropagation(); t.classList.toggle("on", !on); setTimeout(() => onChange(!on), 230); };
  return t;
}

export function renderSettings(container) {
  const s = S();
  const wrap = el("div", "settings");
  container.append(wrap);

  const swatches = el("div", "swatches inline");
  store.ACCENTS.forEach(([rgb, name]) => {
    const b = el("button", "sw" + (s.accent === rgb ? " on" : ""), "");
    b.style.background = `rgb(${rgb})`; b.setAttribute("aria-label", name);
    b.onclick = () => set("accent", rgb);
    swatches.append(b);
  });

  wrap.append(group(Tr("ظاهر"), [
    row({ ic: "type", label: Tr("زبان"), end: seg([["auto", Tr("خودکار")], ["fa", "فارسی"], ["en", "English"]], s.lang || "auto", (v) => { set("lang", v); location.reload(); }) }),
    row({ ic: "moon", label: Tr("حالت نمایش"), end: seg([["system", Tr("خودکار")], ["light", Tr("روشن")], ["dark", Tr("تیره")], ["black", Tr("مشکی")]], s.theme, (v) => set("theme", v)) }),
    row({ ic: "palette", label: Tr("رنگ تأکید"), end: swatches }),
    row({ ic: "type", label: Tr("اندازه‌ی متن"), end: seg([[0.9, Tr("کوچک")], [1, Tr("معمولی")], [1.15, Tr("بزرگ")], [1.3, Tr("خیلی بزرگ")]], s.fontScale, (v) => set("fontScale", v)) }),
  ]));

  wrap.append(group(Tr("یادداشت‌ها"), [
    row({ ic: "grid", label: Tr("چیدمان"), end: seg([["grid", Tr("شبکه‌ای")], ["list", Tr("لیستی")]], s.layout, (v) => set("layout", v)) }),
    row({ ic: "sort", label: Tr("مرتب‌سازی"), end: seg([["updated", Tr("ویرایش")], ["created", Tr("ساخت")], ["title", Tr("عنوان")]], s.sort, (v) => set("sort", v)) }),
    row({ ic: "tag", label: Tr("مدیریت برچسب‌ها"), sub: store.state.labels.length ? Trt`${fa(store.state.labels.length)} برچسب` : Tr("هنوز برچسبی نساختی"), onClick: openLabels }),
  ]));

  wrap.append(group(Tr("امنیت"), [
    row({ ic: "key", label: Tr("قفل برنامه با رمز"), sub: s.pin ? Tr("فعاله") : Tr("با رمز عددی ۴ تا ۶ رقمی"), end: toggle(!!s.pin, (on) => (on ? setPin() : removePin())) }),
    s.pin && row({ ic: "shield", label: Tr("قفل شدن هنگام خروج از برنامه"), end: toggle(!!s.lockOnExit, (on) => set("lockOnExit", on)) }),
  ]));

  wrap.append(group(Tr("اطلاعات"), [
    row({ ic: "download", label: Tr("گرفتن پشتیبان"), sub: Tr("همه‌ی یادداشت‌ها در یک فایل JSON"), onClick: backup }),
    row({ ic: "upload", label: Tr("بازیابی از پشتیبان"), sub: Tr("ادغام با یادداشت‌های فعلی"), onClick: restore }),
  ]));

  wrap.append(group(Tr("درباره"), [
    row({ ic: "info", label: Tr("گلس‌نوت"), sub: Trt`نسخه‌ی ${fa(VERSION)} · همه‌ی داده‌ها فقط روی همین دستگاه ذخیره می‌شن` }),
  ]));
}

/* ---------- برچسب‌ها ---------- */
function openLabels() {
  openSheet({
    title: Tr("برچسب‌ها"),
    build(b) {
      const list = el("div", "menu");
      const draw = () => {
        list.innerHTML = "";
        if (!store.state.labels.length) list.append(txt("p", "sheet-msg", Tr("هنوز برچسبی نداری.")));
        store.state.labels.forEach((l) => {
          const r = el("div", "label-row");
          const inp = el("input", "field"); inp.value = l.name; inp.dir = "auto";
          inp.onchange = () => { store.renameLabel(l.id, inp.value); };
          const del = el("button", "icon-btn", icon("trash")); del.setAttribute("aria-label", Tr("حذف برچسب"));
          del.onclick = async () => { if (await confirmDialog({ title: Trt`حذف «${l.name}»؟`, message: Tr("از یادداشت‌ها برداشته می‌شه ولی خود یادداشت‌ها می‌مونن."), ok: Tr("حذف"), danger: true })) { store.deleteLabel(l.id); draw(); } };
          r.append(inp, del); list.append(r);
        });
      };
      draw(); b.append(list);
      const add = el("div", "add-row"), inp = el("input", "field"), btn = txt("button", "btn small", Tr("افزودن"));
      inp.placeholder = Tr("برچسب جدید"); inp.dir = "auto";
      const doAdd = () => { if (store.addLabel(inp.value)) { inp.value = ""; draw(); } };
      btn.onclick = doAdd; inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); doAdd(); } });
      add.append(inp, btn); b.append(add);
    },
  });
}

/* ---------- PIN ---------- */
async function setPin() {
  const r = await promptDialog({
    title: Tr("رمز برنامه"), message: Tr("یه رمز عددی ۴ تا ۶ رقمی انتخاب کن."),
    fields: [{ type: "password", placeholder: Tr("رمز"), inputmode: "numeric", maxlength: 6 }, { type: "password", placeholder: Tr("تکرار رمز"), inputmode: "numeric", maxlength: 6 }], ok: Tr("فعال کن"),
    validate: (v) => (!/^\d{4,6}$/.test(v[0]) ? Tr("رمز باید ۴ تا ۶ رقم باشه") : v[0] !== v[1] ? Tr("رمزها یکی نیستن") : ""),
  });
  if (!r) { store.saveSettings(); return; }
  try {
    const rec = await vault.makePin(r[0]);
    S().pin = { ...rec, len: r[0].length };
    store.saveSettings(); toast(Tr("قفل برنامه فعال شد"));
  } catch (e) { toast(e.message || Tr("فعال نشد")); }
}
async function removePin() {
  const r = await promptDialog({ title: Tr("غیرفعال کردن قفل"), message: Tr("رمز فعلی رو وارد کن."), fields: [{ type: "password", placeholder: Tr("رمز"), inputmode: "numeric", maxlength: 6 }], ok: Tr("غیرفعال کن") });
  if (!r) { store.saveSettings(); return; }
  if (await vault.checkPin(r[0], S().pin)) { S().pin = null; store.saveSettings(); toast(Tr("قفل برنامه غیرفعال شد")); }
  else { toast(Tr("رمز اشتباهه")); native.haptic("error"); store.saveSettings(); }
}

/* ---------- پشتیبان ---------- */
async function backup() {
  const name = `glassnote-backup-${new Date().toISOString().slice(0, 10)}.json`;
  const ok = await native.shareFile(name, store.exportBackup(), "application/json");
  if (ok) toast(Tr("پشتیبان آماده شد"));
}
function restore() {
  const inp = document.createElement("input");
  inp.type = "file"; inp.accept = ".json,application/json";
  inp.onchange = async () => {
    const f = inp.files[0];
    if (!f) return;
    try {
      const r = store.importBackup(await f.text());
      toast(Trt`${fa(r.added)} یادداشت جدید، ${fa(r.updated)} به‌روزرسانی`);
    } catch (e) { toast(e.message || Tr("بازیابی نشد")); }
  };
  store.runtime.holdLockUntil = Date.now() + 60000;
  inp.click();
}
