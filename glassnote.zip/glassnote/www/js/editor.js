// صفحه‌ی ویرایش یادداشت (متن و چک‌لیست)
import { $, el, txt, icon, toast, celebrate, fa, fmtWhen, fmtReminder, toLocalInput, fromLocalInput, toFaDigits, toEnDigits, fixArabicChars, fmtDateFa, fmtDateEn, fmtTime, debounce } from "./utils.js";
import * as store from "./store.js";
import { openSheet, confirmDialog, promptDialog, menuSheet } from "./sheets.js";
import * as native from "./native.js";
import * as vault from "./crypto.js";
import { Tr, Trt } from "./i18n.js";
import * as draw from "./draw.js";
import * as rich from "./rich.js";
import { mdToHtml } from "./html.js";

const root = $("#editor");
let n = null, focusItem = null, dctl = null, rctl = null;

export const isOpen = () => !!n;
export const current = () => n;

/* ---------- ذخیره ---------- */
async function persistNow(note) {
  if (!note) return;
  if (note.lock && note._key) {
    note.lock = await vault.encryptWith(note._key, note.lock.salt, { title: note.title, body: note.body, items: note.items });
  }
  store.commit(note, { silent: true });
}
const persistLater = debounce(() => persistNow(n), 350);
function edited() { if (!n) return; n.updated = Date.now(); persistLater(); updateMeta(); }

/* ---------- باز و بسته کردن ---------- */
export function openEditor(note, opts = {}) {
  n = note;
  build();
  root.hidden = false;
  requestAnimationFrame(() => root.classList.add("open"));
  if (opts.focus && note.type !== "draw") setTimeout(() => { if (n && n.type === "text" && rctl) rctl.focus(); else focusFirstItem(); }, 60);
}

function bodyFor(note) {
  if (note.lock) return Tr("یک یادداشت قفل‌شده");
  if (note.type === "draw") return note.title.trim().slice(0, 120) || Tr("نقاشی");
  const t = note.title.trim() || (note.type === "list" ? (note.items.find((i) => i.text.trim()) || {}).text : store.plain(note).trim().split("\n")[0]) || "";
  return t.slice(0, 120) || Tr("یادداشت");
}

export async function closeEditor() {
  if (!n) return;
  const note = n;
  if (dctl) { dctl.destroy(); dctl = null; }
  if (rctl) { rctl.destroy(); rctl = null; }
  persistLater.cancel();
  if (note.type === "list") {
    const keep = note.items.filter((i) => i.text.trim());
    note.items = keep.length ? keep : [];
  }
  await persistNow(note);
  if (store.isEmpty(note)) {
    native.cancelReminder(note);
    store.removeNote(note);
  } else if (note.reminder && !note.trashedAt) {
    native.scheduleReminder(note, bodyFor(note));
  }
  if (note.lock) { note.title = ""; note.body = ""; note.items = []; delete note._key; }
  n = null;
  root.classList.remove("open");
  setTimeout(() => { if (!n) { root.hidden = true; root.innerHTML = ""; } }, 220);
  store.emit();
}

/* ---------- ساخت صفحه ---------- */
function build() {
  root.dataset.color = n.color;
  root.classList.toggle("is-draw", n.type === "draw");
  root.classList.toggle("is-rich", n.type === "text");
  root.innerHTML = Trt`
    <header class="bar glass">
      <button class="icon-btn" id="edBack" aria-label="بازگشت">${icon("back")}</button>
      <span class="grow"></span>
      <button class="icon-btn" id="edPin" aria-label="سنجاق">${icon("pin")}</button>
      <button class="icon-btn" id="edBell" aria-label="یادآور">${icon("bell")}</button>
      <button class="icon-btn" id="edView" aria-label="پیش‌نمایش">${icon("eye")}</button>
      <button class="icon-btn" id="edMore" aria-label="بیشتر">${icon("more")}</button>
    </header>
    <div class="ed-scroll">
      <input class="ed-title" id="edTitle" placeholder="عنوان" dir="auto" autocomplete="off" enterkeyhint="next">
      <div class="ed-meta" id="edMeta"></div>
      <div class="chips ed-chips" id="edChips"></div>
      <div id="edBody"></div>
    </div>
    <div class="ed-tools glass" id="edTools"></div>`;
  $("#edBack").onclick = closeEditor;
  $("#edPin").onclick = togglePin;
  $("#edBell").onclick = openReminder;
  $("#edMore").onclick = openMore;
  const title = $("#edTitle");
  title.value = n.title;
  title.oninput = () => { n.title = title.value; edited(); };
  title.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); n.type === "text" ? rctl && rctl.focus() : focusFirstItem(); }
  });
  renderBody();
  renderChrome();
}

function renderChrome() {
  $("#edPin").classList.toggle("active", n.pinned);
  $("#edBell").classList.toggle("active", !!n.reminder);
  $("#edView").hidden = true;
  root.dataset.color = n.color;
  renderChips();
  renderTools();
  updateMeta();
}

function updateMeta() {
  const m = $("#edMeta");
  if (!m || !n) return;
  let extra = "";
  if (n.type === "text") {
    const words = (store.plain(n).trim().match(/\S+/g) || []).length;
    extra = words ? Trt`${fa(words)} کلمه · ${fa(Math.max(1, Math.round(words / 200)))} دقیقه مطالعه` : "";
  } else {
    const total = n.items.filter((i) => i.text.trim()).length, done = n.items.filter((i) => i.done && i.text.trim()).length;
    extra = total ? Trt`${fa(done)} از ${fa(total)} انجام شد` : "";
  }
  m.textContent = [fmtWhen(n.updated), extra].filter(Boolean).join(" · ");
}

function renderChips() {
  const box = $("#edChips");
  box.innerHTML = "";
  n.labels.forEach((id) => {
    const name = store.labelName(id);
    if (!name) return;
    const c = el("button", "chip small", icon("tag")); c.append(txt("span", "", name)); c.onclick = openAppearance; box.append(c);
  });
  if (n.reminder) {
    const over = n.reminder.at < Date.now() && n.reminder.repeat === "none";
    const c = el("button", "chip small" + (over ? " warn" : ""), icon("bell"));
    c.append(txt("span", "", fmtReminder(n.reminder.at) + (n.reminder.repeat === "day" ? Tr(" · روزانه") : n.reminder.repeat === "week" ? Tr(" · هفتگی") : "")));
    c.onclick = openReminder; box.append(c);
  }
  if (n.lock) { const c = el("span", "chip small", icon("lock")); c.append(txt("span", "", Tr("قفل‌شده"))); box.append(c); }
  box.hidden = !box.children.length;
}

function renderBody() {
  const wrap = $("#edBody");
  wrap.innerHTML = "";
  if (dctl) { dctl.destroy(); dctl = null; }
  if (rctl) { rctl.destroy(); rctl = null; }
  if (n.type === "draw") {
    dctl = draw.mount(wrap, n, { scroller: root, onChange: (body) => { n.body = body; edited(); }, haptic: () => native.haptic("light"), toast: (m, undo) => toast(m, { action: Tr("بازگردانی"), onAction: undo }) });
  } else if (n.type === "text") {
    const initial = n.fmt === "html" ? n.body : mdToHtml(n.body);
    rctl = rich.mount(wrap, { body: initial }, { onChange: (html) => { n.body = html; n.fmt = "html"; edited(); }, haptic: () => native.haptic("light") });
  } else renderList();
}

/* ---------- نوار ابزار پایین ---------- */
function renderTools() {
  const t = $("#edTools");
  t.innerHTML = "";
  t.hidden = false;
  t.classList.toggle("draw", n.type === "draw");
  if (n.type === "draw") { t.append(dctl.toolbar); return; }
  t.classList.toggle("rich", n.type === "text");
  if (n.type === "text") {
    t.append(rctl.toolbar);
  } else {
    const btns = [
      ["plus", Tr("مورد جدید"), () => { const it = store.newItem(); n.items.push(it); focusItem = it.id; renderList(); edited(); }],
      ["trash", Tr("حذف انجام‌شده"), () => { n.items = n.items.filter((i) => !i.done); if (!n.items.length) n.items.push(store.newItem()); renderList(); edited(); }],
      ["text", Tr("تبدیل به متن"), () => convert()],
    ];
    btns.forEach(([ic, label, fn]) => {
      const b = el("button", "tb wide", icon(ic) + `<span>${label}</span>`); b.onclick = fn; t.append(b);
    });
  }
}

/* ---------- چک‌لیست ---------- */
function focusFirstItem() { const i = root.querySelector(".li-t"); if (i) i.focus(); }
function renderList() {
  const wrap = $("#edBody");
  wrap.innerHTML = "";
  const open = n.items.filter((i) => !i.done), done = n.items.filter((i) => i.done);
  const box = el("div", "li-box");
  open.forEach((it) => box.append(itemRow(it)));
  const add = el("button", "li-add", icon("plus") + Tr("<span>افزودن مورد</span>"));
  add.onclick = () => { const it = store.newItem(); n.items.push(it); focusItem = it.id; renderList(); edited(); };
  box.append(add);
  wrap.append(box);
  if (done.length) {
    const d = el("div", "li-done");
    d.append(txt("div", "li-done-h", Trt`${fa(done.length)} مورد انجام‌شده`));
    done.forEach((it) => d.append(itemRow(it)));
    wrap.append(d);
  }
  if (focusItem) { const inp = wrap.querySelector(`[data-id="${focusItem}"] .li-t`); if (inp) inp.focus(); focusItem = null; }
}
function itemRow(it) {
  const row = el("div", "li" + (it.done ? " done" : ""));
  row.dataset.id = it.id;
  const cb = el("button", "cb", it.done ? icon("check") : ""); cb.setAttribute("aria-label", Tr("انجام شد"));
  const inp = el("input", "li-t"); inp.value = it.text; inp.dir = "auto"; inp.placeholder = Tr("مورد"); inp.enterKeyHint = "next"; inp.autocomplete = "off";
  const x = el("button", "li-x", icon("x")); x.setAttribute("aria-label", Tr("حذف"));
  cb.onclick = () => {
    it.done = !it.done;
    if (it.done) {
      native.haptic("light");
      if (n.items.some((i) => i.text.trim()) && n.items.every((i) => i.done || !i.text.trim())) { celebrate(cb); native.haptic("success"); }
    }
    renderList(); edited();
  };
  x.onclick = () => removeItem(it);
  inp.oninput = () => { it.text = inp.value; edited(); };
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const idx = n.items.indexOf(it), ni = store.newItem();
      n.items.splice(idx + 1, 0, ni); focusItem = ni.id; renderList(); edited();
    } else if (e.key === "Backspace" && !inp.value && n.items.length > 1) {
      e.preventDefault(); removeItem(it, true);
    }
  });
  row.append(cb, inp, x);
  return row;
}
function removeItem(it, focusPrev) {
  const idx = n.items.indexOf(it);
  n.items.splice(idx, 1);
  if (!n.items.length) n.items.push(store.newItem());
  if (focusPrev) { const p = n.items[Math.max(0, idx - 1)]; focusItem = p && p.id; }
  renderList(); edited();
}

function convert() {
  if (rctl) { rctl.flush(); rctl.destroy(false); rctl = null; }
  store.convertType(n);
  renderBody(); renderChrome(); edited();
  toast(n.type === "list" ? Tr("به چک‌لیست تبدیل شد") : Tr("به متن تبدیل شد"));
}

/* ---------- سنجاق ---------- */
function togglePin() {
  n.pinned = !n.pinned;
  store.commit(n, { silent: true, touch: false });
  renderChrome();
  native.haptic("light");
  toast(n.pinned ? Tr("سنجاق شد") : Tr("سنجاق برداشته شد"));
}

/* ---------- یادآور ---------- */
function atHour(daysAhead, h, m = 0) { const d = new Date(); d.setDate(d.getDate() + daysAhead); d.setHours(h, m, 0, 0); return d.getTime(); }
function openReminder() {
  let at = n.reminder ? n.reminder.at : atHour(0, 20) > Date.now() ? atHour(0, 20) : atHour(1, 9);
  let repeat = n.reminder ? n.reminder.repeat : "none";
  openSheet({
    title: Tr("یادآور"),
    build(b, api) {
      const quick = el("div", "quick");
      const opts = [];
      if (atHour(0, 20) > Date.now()) opts.push([Tr("امشب ۲۰:۰۰"), atHour(0, 20)]);
      opts.push([Tr("فردا ۰۹:۰۰"), atHour(1, 9)]);
      const fri = new Date(); fri.setDate(fri.getDate() + ((5 - fri.getDay() + 7) % 7 || 7)); fri.setHours(9, 0, 0, 0);
      opts.push([Tr("جمعه ۰۹:۰۰"), fri.getTime()], [Tr("هفته‌ی بعد"), atHour(7, 9)]);
      const input = el("input", "field"); input.type = "datetime-local"; input.value = toLocalInput(at); input.dir = "ltr";
      input.onchange = () => { const v = fromLocalInput(input.value); if (v) at = v; };
      opts.forEach(([l, t]) => { const q = txt("button", "chip", l); q.onclick = () => { at = t; input.value = toLocalInput(t); }; quick.append(q); });
      b.append(quick, input);
      const seg = el("div", "seg full");
      [["none", Tr("یک‌بار")], ["day", Tr("هر روز")], ["week", Tr("هر هفته")]].forEach(([v, l]) => {
        const s = txt("button", v === repeat ? "on" : "", l);
        s.onclick = () => { repeat = v; [...seg.children].forEach((c) => c.classList.toggle("on", c === s)); };
        seg.append(s);
      });
      b.append(seg);
      const col = el("div", "btn-col");
      const save = txt("button", "btn primary", Tr("ثبت یادآور"));
      save.onclick = async () => {
        const v = fromLocalInput(input.value) || at;
        if (v <= Date.now() && repeat === "none") { toast(Tr("زمان باید در آینده باشه")); return; }
        n.reminder = { at: v, repeat, fired: false };
        store.commit(n, { silent: true });
        api.close(); renderChrome();
        const ok = await native.ensureNotifPermission();
        if (!ok) toast(Tr("اجازه‌ی اعلان داده نشده؛ یادآور فقط داخل برنامه کار می‌کنه"));
        else { await native.scheduleReminder(n, bodyFor(n)); toast(Tr("یادآور تنظیم شد")); }
      };
      col.append(save);
      if (n.reminder) {
        const rm = txt("button", "btn ghost-btn", Tr("حذف یادآور"));
        rm.onclick = () => { native.cancelReminder(n); n.reminder = null; store.commit(n, { silent: true }); api.close(); renderChrome(); };
        col.append(rm);
      }
      b.append(col);
    },
  });
}

/* ---------- رنگ و برچسب ---------- */
function openAppearance() {
  openSheet({
    title: Tr("رنگ و برچسب"),
    onClose: () => { if (n) renderChips(); },
    build(b) {
      const sw = el("div", "swatches");
      for (let c = 0; c < store.COLORS; c++) {
        const s = el("button", "sw" + (n.color === c ? " on" : "") + (c === 0 ? " none" : ""), c === 0 ? icon("x") : "");
        if (c) s.style.background = `var(--c${c})`;
        s.setAttribute("aria-label", c ? Tr("رنگ ") + fa(c) : Tr("بدون رنگ"));
        s.onclick = () => { n.color = c; store.commit(n, { silent: true }); [...sw.children].forEach((x, i) => x.classList.toggle("on", i === c)); root.dataset.color = c; };
        sw.append(s);
      }
      b.append(sw);
      const list = el("div", "menu");
      const drawLabels = () => {
        list.innerHTML = "";
        store.state.labels.forEach((l) => {
          const on = n.labels.includes(l.id);
          const r = el("button", "menu-row", `<span class="mi">${icon("tag")}</span><span class="mt"><b></b></span><span class="mc">${on ? icon("check") : ""}</span>`);
          r.querySelector("b").textContent = l.name;
          r.onclick = () => { n.labels = on ? n.labels.filter((x) => x !== l.id) : [...n.labels, l.id]; store.commit(n, { silent: true }); drawLabels(); };
          list.append(r);
        });
      };
      drawLabels();
      b.append(list);
      const row = el("div", "add-row");
      const inp = el("input", "field"); inp.placeholder = Tr("برچسب جدید"); inp.dir = "auto";
      const add = txt("button", "btn small", Tr("افزودن"));
      const doAdd = () => { const l = store.addLabel(inp.value); if (l) { if (!n.labels.includes(l.id)) n.labels.push(l.id); store.commit(n, { silent: true }); inp.value = ""; drawLabels(); } };
      add.onclick = doAdd; inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); doAdd(); } });
      row.append(inp, add); b.append(row);
    },
  });
}

/* ---------- منوی بیشتر ---------- */
function openMore() {
  menuSheet({
    title: Tr("گزینه‌ها"),
    items: [
      { icon: "palette", label: Tr("رنگ و برچسب"), onClick: openAppearance },
      n.type === "draw" && { icon: "grid", label: Tr("کاغذ"), sub: paperName(n.paper), onClick: openPaper },
      n.type === "draw" && { icon: "image", label: Tr("اشتراک‌گذاری تصویر"), onClick: shareDrawing },
      n.type === "draw" && { icon: "trash", label: Tr("پاک کردن صفحه"), onClick: () => { if (dctl && dctl.clear()) toast(Tr("صفحه پاک شد"), { action: Tr("بازگردانی"), onAction: () => dctl && dctl.undo() }); } },
      n.type === "text" && { icon: "wand", label: Tr("ابزارهای متن"), sub: Tr("تاریخ، ارقام، مرتب‌سازی، جایگزینی…"), onClick: () => rctl && rctl.openTools() },
      n.type === "list" && { icon: "restore", label: Tr("برداشتن همه‌ی تیک‌ها"), onClick: () => { n.items.forEach((i) => (i.done = false)); renderList(); edited(); } },
      n.type !== "draw" && { icon: n.type === "text" ? "checklist" : "text", label: n.type === "text" ? Tr("تبدیل به چک‌لیست") : Tr("تبدیل به متن"), onClick: convert },
      n.lock ? { icon: "unlock", label: Tr("برداشتن قفل"), onClick: removeLock } : { icon: "lock", label: Tr("قفل با رمز"), sub: Tr("محتوا رمزگذاری می‌شه"), onClick: lockNote },
      n.type !== "draw" && { icon: "copy", label: Tr("کپی متن"), onClick: async () => toast((await native.copyText(store.noteText(n))) ? Tr("کپی شد") : Tr("کپی نشد")) },
      n.type !== "draw" && { icon: "share", label: Tr("اشتراک‌گذاری"), onClick: async () => { const r = await native.shareText(n.title || Tr("یادداشت"), store.noteText(n)); if (r === "copied") toast(Tr("متن کپی شد")); } },
      n.type !== "draw" && { icon: "download", label: Tr("خروجی Markdown"), onClick: () => native.shareFile((n.title.trim() || "note").replace(/[\\/:*?"<>|]/g, "_").slice(0, 40) + ".md", store.noteText(n, true), "text/markdown") },
      !n.lock && { icon: "dup", label: Tr("ساخت نسخه‌ی کپی"), onClick: async () => { const note = n; await closeEditor(); store.duplicate(note); toast(Tr("نسخه‌ی کپی ساخته شد")); } },
      { icon: "archive", label: n.archived ? Tr("خروج از بایگانی") : Tr("بایگانی"), onClick: () => setFlag("archived", !n.archived, n.archived ? Tr("از بایگانی بیرون اومد") : Tr("بایگانی شد")) },
      { icon: "trash", label: Tr("انتقال به سطل زباله"), danger: true, onClick: toTrash },
    ],
  });
}

const PAPER_NAMES = () => ({ plain: Tr("ساده"), grid: Tr("شطرنجی"), lines: Tr("خط‌دار"), dots: Tr("نقطه‌ای") });
const paperName = (p) => PAPER_NAMES()[p || "plain"];
function openPaper() {
  const set = (p) => () => { n.paper = p; if (dctl) dctl.setPaper(p); store.commit(n, { silent: true }); };
  menuSheet({ title: Tr("کاغذ"), items: draw.PAPERS.map((p) => ({ icon: "grid", label: paperName(p), check: (n.paper || "plain") === p, onClick: set(p) })) });
}
async function shareDrawing() {
  if (!dctl || !dctl.hasStrokes()) { toast(Tr("هنوز چیزی نکشیدی")); return; }
  const name = (n.title.trim() || "drawing").replace(/[\\/:*?"<>|]/g, "_").slice(0, 40) + ".png";
  const ok = await native.shareImage(name, dctl.image(n.paper));
  if (ok) toast(Tr("تصویر آماده شد"));
}

async function setFlag(key, val, msg) {
  const note = n, prev = note[key];
  note[key] = val; if (key === "archived" && val) note.pinned = false;
  await closeEditor();
  store.commit(note);
  toast(msg, { action: Tr("بازگردانی"), onAction: () => { note[key] = prev; store.commit(note); } });
}
async function toTrash() {
  const note = n;
  if (store.isEmpty(note)) { await closeEditor(); return; }
  await closeEditor();
  note.trashedAt = Date.now(); note.pinned = false;
  native.cancelReminder(note);
  store.commit(note);
  toast(Tr("به سطل زباله رفت"), { action: Tr("بازگردانی"), onAction: () => { note.trashedAt = null; store.commit(note); if (note.reminder) native.scheduleReminder(note, bodyFor(note)); } });
}

/* ---------- قفل یادداشت ---------- */
async function lockNote() {
  const r = await promptDialog({
    title: Tr("قفل یادداشت"), message: Tr("یه رمز انتخاب کن. اگه فراموشش کنی هیچ راهی برای بازیابی محتوا نیست."),
    fields: [{ type: "password", placeholder: Tr("رمز (حداقل ۴ کاراکتر)") }, { type: "password", placeholder: Tr("تکرار رمز") }], ok: Tr("قفل کن"),
    validate: (v) => (v[0].length < 4 ? Tr("رمز باید حداقل ۴ کاراکتر باشه") : v[0] !== v[1] ? Tr("رمزها یکی نیستن") : ""),
  });
  if (!r) return;
  try {
    const { key, salt } = await vault.newLock(r[0]);
    n._key = key;
    n.lock = { salt };
    await closeEditor();
    toast(Tr("یادداشت قفل شد"));
  } catch (e) { n.lock = null; toast(e.message || Tr("قفل نشد")); }
}
async function removeLock() {
  if (!await confirmDialog({ title: Tr("برداشتن قفل؟"), message: Tr("یادداشت دوباره بدون رمز ذخیره می‌شه."), ok: Tr("برداشتن قفل") })) return;
  n.lock = null; delete n._key;
  store.commit(n, { silent: true });
  renderChrome();
  toast(Tr("قفل برداشته شد"));
}
