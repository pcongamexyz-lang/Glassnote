// ابزارهای کوچک و مشترک
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];

export function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html != null) e.innerHTML = html;
  return e;
}
export function txt(tag, cls, t) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  e.textContent = t;
  return e;
}
export const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

export const uid = () => "n" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

// عدد ۳۱ بیتی مثبت از یک رشته (برای شناسه‌ی اعلان‌ها)
export function hash32(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619);
  return (h >>> 1) || 1;
}

export function debounce(fn, ms) {
  let t;
  const d = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
  d.flush = (...a) => { clearTimeout(t); fn(...a); };
  d.cancel = () => clearTimeout(t);
  return d;
}

/* ---------- ارقام و نرمال‌سازی ---------- */
const FA = "۰۱۲۳۴۵۶۷۸۹", AR = "٠١٢٣٤٥٦٧٨٩";
export const toFaDigits = (s) => String(s).replace(/\d/g, (d) => FA[d]);
export const toEnDigits = (s) => String(s).replace(/[۰-۹]/g, (d) => FA.indexOf(d)).replace(/[٠-٩]/g, (d) => AR.indexOf(d));
export const fixArabicChars = (s) => String(s).replace(/ي/g, "ی").replace(/ى/g, "ی").replace(/ك/g, "ک").replace(/ۀ/g, "ه").replace(/ة/g, "ه");
export function normalize(s) {
  return fixArabicChars(toEnDigits(String(s || "").toLowerCase())).replace(/[ً-ٰٟ‌‍]/g, "");
}
export const fa = (n) => toFaDigits(String(n));

/* ---------- تاریخ (شمسی) ---------- */
const tf = new Intl.DateTimeFormat("fa-IR", { hour: "2-digit", minute: "2-digit", hour12: false });
const df = new Intl.DateTimeFormat("fa-IR", { day: "numeric", month: "long" });
const dfy = new Intl.DateTimeFormat("fa-IR", { year: "numeric", month: "long", day: "numeric" });
const dfull = new Intl.DateTimeFormat("fa-IR", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
const same = (a, b) => a.toDateString() === b.toDateString();

export function fmtWhen(ts) {
  const d = new Date(ts), n = new Date(), y = new Date(n);
  y.setDate(n.getDate() - 1);
  if (same(d, n)) return "امروز " + tf.format(d);
  if (same(d, y)) return "دیروز " + tf.format(d);
  return (d.getFullYear() === n.getFullYear() ? df : dfy).format(d);
}
export function fmtReminder(ts) {
  const d = new Date(ts), n = new Date(), t = new Date(n);
  t.setDate(n.getDate() + 1);
  if (same(d, n)) return "امروز " + tf.format(d);
  if (same(d, t)) return "فردا " + tf.format(d);
  return df.format(d) + "، " + tf.format(d);
}
export const fmtTime = (d = new Date()) => tf.format(d);
export const fmtDateFa = (d = new Date()) => dfull.format(d);
export const fmtDateEn = (d = new Date()) => d.toLocaleDateString("en-CA"); // 2026-10-22

// مقدار input[type=datetime-local] از timestamp و برعکس
export function toLocalInput(ts) {
  const d = new Date(ts), p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
export const fromLocalInput = (v) => { const t = new Date(v).getTime(); return Number.isFinite(t) ? t : null; };

/* ---------- آیکون‌ها ---------- */
const I = {
  search: '<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4-4"/>',
  grid: '<rect x="4" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6"/>',
  list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  note: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>',
  archive: '<rect x="3" y="4" width="18" height="5" rx="1.5"/><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9M10 13h4"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/>',
  settings: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
  pin: '<path d="M9 4h6l-1 6 3 3v2H7v-2l3-3zM12 15v6"/>',
  bell: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4zM10 21h4"/>',
  more: '<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>',
  back: '<path d="M4 12h16m0 0-6-6m6 6-6 6"/>',
  chev: '<path d="m15 6-6 6 6 6"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  palette: '<path d="M12 3a9 9 0 1 0 0 18c1.2 0 2-.8 2-1.8 0-.5-.2-.9-.5-1.2a1.7 1.7 0 0 1 1.2-2.9H17a4 4 0 0 0 4-4C21 6.5 17 3 12 3z"/><circle cx="8" cy="11" r="1"/><circle cx="11" cy="7.5" r="1"/><circle cx="15.5" cy="8.5" r="1"/>',
  tag: '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.2"/>',
  lock: '<rect x="5" y="11" width="14" height="9.5" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  unlock: '<rect x="5" y="11" width="14" height="9.5" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 7.5-2"/>',
  share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="m8.2 10.8 7.6-3.6M8.2 13.2l7.6 3.6"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6.5A2.5 2.5 0 0 1 7.5 4H16"/>',
  checklist: '<path d="m4 7 1.5 1.5L8 6M4 17l1.5 1.5L8 16M11 7h9M11 17h9M11 12h9"/>',
  text: '<path d="M4 6h16M8 10h12M4 14h16M8 18h12"/>',
  bold: '<path d="M7 5h6a3.5 3.5 0 0 1 0 7H7zM7 12h7a3.5 3.5 0 0 1 0 7H7z"/>',
  italic: '<path d="M10 5h8M6 19h8M14 5l-4 14"/>',
  heading: '<path d="M6 5v14M18 5v14M6 12h12"/>',
  quote: '<path d="M5 6v12M9 8h10M9 12h10M9 16h7"/>',
  calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
  redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  wand: '<path d="m5 19 9-9M13 4l.8 2 2 .8-2 .8L13 10l-.8-2.4-2-.8 2-.8zM18 12l.6 1.4 1.4.6-1.4.6L18 16l-.6-1.4-1.4-.6 1.4-.6z"/>',
  restore: '<path d="M4 12a8 8 0 1 1 3 6.2"/><path d="M4 5v5h5"/>',
  sort: '<path d="M7 5v14m0 0-3-3m3 3 3-3M17 19V5m0 0-3 3m3-3 3 3"/>',
  download: '<path d="M12 4v12m0 0 5-5m-5 5-5-5M4 20h16"/>',
  upload: '<path d="M12 16V4m0 0L7 9m5-5 5 5M4 16v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3"/>',
  shield: '<path d="M12 3 5 6v5.5c0 4.4 3 7.6 7 9.5 4-1.9 7-5.1 7-9.5V6z"/><path d="m9 12 2.2 2.2L15.2 10"/>',
  moon: '<path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/>',
  type: '<path d="M5 19 12 5l7 14M8 14h8"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  sel: '<rect x="4" y="4" width="16" height="16" rx="4"/><path d="m8 12 3 3 5-6"/>',
  repeat: '<path d="M4 11V9a3 3 0 0 1 3-3h11l-3-3M20 13v2a3 3 0 0 1-3 3H6l3 3"/>',
  dup: '<rect x="8" y="8" width="12" height="12" rx="2.5"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  swap: '<path d="M7 7h12l-3-3M17 17H5l3 3"/>',
  key: '<circle cx="8" cy="14" r="4"/><path d="m11 11 9-8M16 6l3 3"/>',
  backspace: '<path d="M21 5H9l-6 7 6 7h12a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1z"/><path d="m12 9 5 5m0-5-5 5"/>',
};
export const icon = (n, cls) => `<svg class="ic ${cls || ""}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${I[n] || I.note}</svg>`;

/* ---------- توست ---------- */
let toastT;
export function toast(msg, opt = {}) {
  const e = $("#toast");
  e.innerHTML = "";
  e.append(txt("span", "", msg));
  if (opt.action) {
    const b = txt("button", "toast-act", opt.action);
    b.onclick = () => { e.classList.remove("show"); opt.onAction && opt.onAction(); };
    e.append(b);
  }
  e.classList.add("show");
  clearTimeout(toastT);
  toastT = setTimeout(() => e.classList.remove("show"), opt.action ? 5000 : 2400);
}
