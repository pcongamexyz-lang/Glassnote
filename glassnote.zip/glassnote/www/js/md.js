// رندر مارک‌داون ساده و امن (اول همه‌چیز escape می‌شه)
import { esc } from "./utils.js";

function inline(s) {
  return s
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
    .replace(/(^|[^*])\*(?!\s)([^*]+?)\*(?!\*)/g, "$1<i>$2</i>")
    .replace(/~~(.+?)~~/g, "<s>$1</s>")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}

export function renderMarkdown(src) {
  const lines = esc(src || "").split("\n");
  let out = "", list = null, quote = false, code = false, para = [];
  const flushPara = () => { if (para.length) { out += `<p dir="auto">${para.map(inline).join("<br>")}</p>`; para = []; } };
  const closeList = () => { if (list) { out += `</${list}>`; list = null; } };
  const closeQuote = () => { if (quote) { out += "</blockquote>"; quote = false; } };
  const closeAll = () => { flushPara(); closeList(); closeQuote(); };

  for (const raw of lines) {
    if (/^```/.test(raw)) {
      if (code) { out += "</code></pre>"; code = false; } else { closeAll(); out += '<pre dir="ltr"><code>'; code = true; }
      continue;
    }
    if (code) { out += raw + "\n"; continue; }
    let m;
    if (!raw.trim()) { closeAll(); continue; }
    if ((m = /^(#{1,3})\s+(.*)$/.exec(raw))) { closeAll(); out += `<h${m[1].length} dir="auto">${inline(m[2])}</h${m[1].length}>`; continue; }
    if (/^(-{3,}|\*{3,})$/.test(raw.trim())) { closeAll(); out += "<hr>"; continue; }
    if ((m = /^&gt;\s?(.*)$/.exec(raw))) { flushPara(); closeList(); if (!quote) { out += '<blockquote dir="auto">'; quote = true; } out += inline(m[1]) + "<br>"; continue; }
    if ((m = /^\s*[-*]\s+\[( |x|X)\]\s+(.*)$/.exec(raw))) {
      flushPara(); closeQuote();
      if (list !== "ul") { closeList(); out += '<ul class="tasks">'; list = "ul"; }
      const done = m[1] !== " ";
      out += `<li dir="auto" class="${done ? "done" : ""}"><span class="box">${done ? "✓" : ""}</span>${inline(m[2])}</li>`;
      continue;
    }
    if ((m = /^\s*[-*]\s+(.*)$/.exec(raw))) {
      flushPara(); closeQuote();
      if (list !== "ul") { closeList(); out += "<ul>"; list = "ul"; }
      out += `<li dir="auto">${inline(m[1])}</li>`; continue;
    }
    if ((m = /^\s*\d+[.)]\s+(.*)$/.exec(raw))) {
      flushPara(); closeQuote();
      if (list !== "ol") { closeList(); out += "<ol>"; list = "ol"; }
      out += `<li dir="auto">${inline(m[1])}</li>`; continue;
    }
    closeList(); closeQuote(); para.push(raw);
  }
  if (code) out += "</code></pre>";
  closeAll();
  return out;
}
